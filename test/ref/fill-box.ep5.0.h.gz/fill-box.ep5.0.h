Fill box(0,1,0,0) =
	0
	;

Fill box(0,1,0,-1) =
	0
	;

Fill box(0,1,-1,0) =
	0
	;

Fill box(-1,1,0,0) =
	0
	;

Fill box(0,1,0,-2) =
	0
	;

Fill box(0,1,-1,-1) =
	0
	;

Fill box(0,1,-2,0) =
	0
	;

Fill box(-1,1,0,-1) =
	0
	;

Fill box(-1,1,-1,0) =
	0
	;

Fill box(-2,1,0,0) =
	0
	;

Fill box(0,2,0,0) =
	0
	;

Fill box(0,2,0,-1) =
	0
	;

Fill box(0,2,-1,0) =
	0
	;

Fill box(-1,2,0,0) =
	0
	;

Fill box(0,2,0,-2) =
	0
	;

Fill box(0,2,-1,-1) =
	0
	;

Fill box(0,2,-2,0) =
	0
	;

Fill box(-1,2,0,-1) =
	0
	;

Fill box(-1,2,-1,0) =
	0
	;

Fill box(-2,2,0,0) =
	0
	;

Fill box(0,3,0,0) =
	0
	;

Fill box(0,3,0,-1) =
	0
	;

Fill box(0,3,-1,0) =
	0
	;

Fill box(-1,3,0,0) =
	0
	;

Fill box(0,3,0,-2) =
	0
	;

Fill box(0,3,-1,-1) =
	0
	;

Fill box(0,3,-2,0) =
	0
	;

Fill box(-1,3,0,-1) =
	0
	;

Fill box(-1,3,-1,0) =
	0
	;

Fill box(-2,3,0,0) =
	0
	;

Fill box(0,0,0,1) =
	0
	;

Fill box(0,0,-1,1) =
	0
	;

Fill box(0,-1,0,1) =
	0
	;

Fill box(-1,0,0,1) =
	0
	;

Fill box(0,0,-2,1) =
	0
	;

Fill box(0,-1,-1,1) =
	0
	;

Fill box(0,-2,0,1) =
	0
	;

Fill box(-1,0,-1,1) =
	0
	;

Fill box(-1,-1,0,1) =
	0
	;

Fill box(-2,0,0,1) =
	0
	;

Fill box(0,0,0,2) =
	0
	;

Fill box(0,0,-1,2) =
	0
	;

Fill box(0,-1,0,2) =
	0
	;

Fill box(-1,0,0,2) =
	0
	;

Fill box(0,0,-2,2) =
	0
	;

Fill box(0,-1,-1,2) =
	0
	;

Fill box(0,-2,0,2) =
	0
	;

Fill box(-1,0,-1,2) =
	0
	;

Fill box(-1,-1,0,2) =
	0
	;

Fill box(-2,0,0,2) =
	0
	;

Fill box(0,0,0,3) =
	0
	;

Fill box(0,0,-1,3) =
	0
	;

Fill box(0,-1,0,3) =
	0
	;

Fill box(-1,0,0,3) =
	0
	;

Fill box(0,0,-2,3) =
	0
	;

Fill box(0,-1,-1,3) =
	0
	;

Fill box(0,-2,0,3) =
	0
	;

Fill box(-1,0,-1,3) =
	0
	;

Fill box(-1,-1,0,3) =
	0
	;

Fill box(-2,0,0,3) =
	0
	;

Fill box(1,0,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1*den(4)
	+ mibox(1,0,0,0) * ep^3 * 1*den(8)
	+ mibox(1,0,0,0) * ep^4 * 1*den(16)
	+ mibox(1,0,0,0) * ep^5 * 1*den(32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(8)
	+ mibox(1,0,0,0) * ep^3 * num(s)*den(16)
	+ mibox(1,0,0,0) * ep^4 * num(s)*den(32)
	+ mibox(1,0,0,0) * ep^5 * num(s)*den(64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(s)*den(8)
	+ mibox(1,0,0,0) * ep^4 * num(s)*den(16)
	+ mibox(1,0,0,0) * ep^5 * num(s)*den(32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-2)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(s+t-2)*den(8)
	+ mibox(1,0,0,0) * ep^3 * num(s+t-2)*den(16)
	+ mibox(1,0,0,0) * ep^4 * num(s+t-2)*den(32)
	+ mibox(1,0,0,0) * ep^5 * num(s+t-2)*den(64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(8)
	+ mibox(1,0,0,0) * ep^3 * num(s)*den(16)
	+ mibox(1,0,0,0) * ep^4 * num(s)*den(32)
	+ mibox(1,0,0,0) * ep^5 * num(s)*den(64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1*den(4)
	+ mibox(1,0,0,0) * ep^3 * 1*den(8)
	+ mibox(1,0,0,0) * ep^4 * 1*den(16)
	+ mibox(1,0,0,0) * ep^5 * 1*den(32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,0,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s-2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-6*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+8)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t-10)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^3 * num(4)
	+ mibox(1,0,0,0) * ep^4 * num(8)
	+ mibox(1,0,0,0) * ep^5 * num(16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(52*s^2+104*s*t-424*s+52*t^2-424*t+864)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(320*s^2+640*s*t-2576*s+320*t^2-2576*t+5184)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(1936*s^2+3872*s*t-15520*s+1936*t^2-15520*t+31104)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(11648*s^2+23296*s*t-93248*s+11648*t^2-93248*t+186624)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)
	+ mibox(1,0,0,0) * ep^3 * num(6)
	+ mibox(1,0,0,0) * ep^4 * num(-12)
	+ mibox(1,0,0,0) * ep^5 * num(24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(4*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(16*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * num(-s+2)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s+4)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s)
	+ mibox(1,0,0,0) * ep^4 * num(4*s)
	+ mibox(1,0,0,0) * ep^5 * num(8*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^2+8*s*t-32*s+4*t^2-32*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(8*s^2+16*s*t-64*s+8*t^2-64*t+128)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^2+32*s*t-128*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+40*s-6*t^2+40*t-64)
	+ mibox(1,0,0,0) * ep^3 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+160*s-24*t^2+160*t-256)
	+ mibox(1,0,0,0) * ep^5 * num(-64*s-64*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2+s*t-6*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^2+2*s*t-12*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^2+4*s*t-24*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^2+8*s*t-48*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^2+4*s)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,0,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^3 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3)
	+ mibox(1,0,0,0) * ep^5 * num(-6)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,0,0) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3)
	+ mibox(1,0,0,0) * ep^4 * num(-6)
	+ mibox(1,0,0,0) * ep^5 * num(12)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,0,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * num(11)*den(18)
	+ mibox(1,0,0,0) * ep^3 * num(-38)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(238)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-1448)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s-3*t+14)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s+3*t-12)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s-3*t+12)
	+ mibox(1,0,0,0) * ep^5 * num(6*s+6*t-24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * num(-19*s-19*t+49)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(119*s+119*t-314)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(-724*s-724*t+1924)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(4364*s+4364*t-11624)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s-6)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s+6)
	+ mibox(1,0,0,0) * ep^4 * num(6*s-12)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s+24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+6*s*t-22*s+3*t^2-22*t+42)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2+12*s*t-44*s+6*t^2-44*t+80)
	+ mibox(1,0,0,0) * ep^5 * num(8*s+8*t-32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+44*s-6*t^2+44*t-80)
	+ mibox(1,0,0,0) * ep^3 * num(6*s^2+12*s*t-56*s+6*t^2-56*t+128)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+176*s-24*t^2+176*t-320)
	+ mibox(1,0,0,0) * ep^5 * num(24*s^2+48*s*t-224*s+24*t^2-224*t+512)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * num(46*s^2+92*s*t-260*s+46*t^2-260*t+322)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(-200*s^2-400*s*t+1276*s-200*t^2+1276*t-1796)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(1696*s^2+3392*s*t-9680*s+1696*t^2-9680*t+12232)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-7280*s^2-14560*s*t+46576*s-7280*t^2+46576*t-65936)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-14*s-4*t+16)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2+3*s*t-16*s-4*t+16)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2+3*s*t-16*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2+6*s*t-32*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2-3*s*t+15*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(-12*s^2-12*s*t+60*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-11*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2-3*s*t+14*s)
	+ mibox(1,0,0,0) * ep^4 * num(12*s^2+12*s*t-44*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2-12*s*t+56*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2-3*s+2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s+8)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2-12*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2+8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2-8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(4*s)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2-16*s)
	+ mibox(1,0,0,0) * ep^5 * num(16*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1*den(4)
	+ mibox(1,0,0,0) * ep^3 * 1*den(8)
	+ mibox(1,0,0,0) * ep^4 * 1*den(16)
	+ mibox(1,0,0,0) * ep^5 * 1*den(32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-2)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(s+t-2)*den(8)
	+ mibox(1,0,0,0) * ep^3 * num(s+t-2)*den(16)
	+ mibox(1,0,0,0) * ep^4 * num(s+t-2)*den(32)
	+ mibox(1,0,0,0) * ep^5 * num(s+t-2)*den(64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1*den(4)
	+ mibox(1,0,0,0) * ep^3 * 1*den(8)
	+ mibox(1,0,0,0) * ep^4 * 1*den(16)
	+ mibox(1,0,0,0) * ep^5 * 1*den(32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(8)
	+ mibox(1,0,0,0) * ep^3 * num(s)*den(16)
	+ mibox(1,0,0,0) * ep^4 * num(s)*den(32)
	+ mibox(1,0,0,0) * ep^5 * num(s)*den(64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(8)
	+ mibox(1,0,0,0) * ep^3 * num(s)*den(16)
	+ mibox(1,0,0,0) * ep^4 * num(s)*den(32)
	+ mibox(1,0,0,0) * ep^5 * num(s)*den(64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(s)*den(8)
	+ mibox(1,0,0,0) * ep^4 * num(s)*den(16)
	+ mibox(1,0,0,0) * ep^5 * num(s)*den(32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,2,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,3,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,3,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s-2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,3,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+8)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t-10)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-6*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,1,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-8*s+16)*den(3)
	+ mibox(1,0,1,0) * ep^1 * num(s^2-8*s+16)*den(18)
	+ mibox(1,0,1,0) * ep^2 * num(s^2-8*s+16)*den(27)
	+ mibox(1,0,1,0) * ep^3 * num(2*s^2-16*s+32)*den(81)
	+ mibox(1,0,1,0) * ep^4 * num(4*s^2-32*s+64)*den(243)
	+ mibox(1,0,1,0) * ep^5 * num(8*s^2-64*s+128)*den(729)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s+14)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s+4)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s+8)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s+16)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s+32)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s+64)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-s*t-8*s+4*t+16)*den(6)
	+ mibox(1,0,1,0) * ep^1 * num(-s^2-2*s*t+8*s+8*t-16)*den(18)
	+ mibox(1,0,1,0) * ep^2 * num(-s^2-2*s*t+8*s+8*t-16)*den(27)
	+ mibox(1,0,1,0) * ep^3 * num(-2*s^2-4*s*t+16*s+16*t-32)*den(81)
	+ mibox(1,0,1,0) * ep^4 * num(-4*s^2-8*s*t+32*s+32*t-64)*den(243)
	+ mibox(1,0,1,0) * ep^5 * num(-8*s^2-16*s*t+64*s+64*t-128)*den(729)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s+t+10)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(s+2*t-4)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(2*s+4*t-8)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(4*s+8*t-16)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(8*s+16*t-32)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(16*s+32*t-64)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-8*s+16)*den(3)
	+ mibox(1,0,1,0) * ep^1 * num(s^2-8*s+16)*den(18)
	+ mibox(1,0,1,0) * ep^2 * num(s^2-8*s+16)*den(27)
	+ mibox(1,0,1,0) * ep^3 * num(2*s^2-16*s+32)*den(81)
	+ mibox(1,0,1,0) * ep^4 * num(4*s^2-32*s+64)*den(243)
	+ mibox(1,0,1,0) * ep^5 * num(8*s^2-64*s+128)*den(729)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s+14)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s+4)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s+8)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s+16)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s+32)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s+64)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	;

Fill box(1,0,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	;

Fill box(2,-1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	;

Fill box(1,-1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	;

Fill box(2,0,1,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,2,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+t+4)*den(2)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+t+4)*den(2)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+8*s-12)*den(2*s^3-16*s^2+32*s)
	+ mibox(1,0,0,0) * ep^2 * num(s^2-8*s+8)*den(2*s^3-16*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s+4)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * num(4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s-4)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+12)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^2 * num(-8)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+8*s-12)*den(2*s^3-16*s^2+32*s)
	+ mibox(1,0,0,0) * ep^2 * num(s^2-8*s+8)*den(2*s^3-16*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * num(s-2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^1 * num(s+4)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * num(-2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-6)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^2 * num(4)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,3,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * num(s-2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * num(s-2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^1 * num(s+4)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * num(-2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-6)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^2 * num(4)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * num(s-2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,1,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * 1*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * 1*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,2,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s-2)*den(s)
	+ mibox(1,0,1,0) * ep^2 * 1
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(4)*den(s)
	+ mibox(1,0,0,0) * ep^2 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,3,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * 1*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * 1*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-s*t-4*s+2*t)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s^2+s*t+10*s-8)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * 1*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s+2*t+8)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * 1*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-4*s-2*t)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^1 * num(-s^2+s*t+2*s+8)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * 1
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*t)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^1 * num(2*s-2*t-8)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,3,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-s*t-4*s+2*t)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s^2+s*t+10*s-8)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * 1*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s+2*t+8)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * 1*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * 1*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * 1*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s-2)*den(s)
	+ mibox(1,0,1,0) * ep^2 * 1
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(4)*den(s)
	+ mibox(1,0,0,0) * ep^2 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * 1*den(2)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * 1*den(s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^3 * num(4)
	+ mibox(1,0,0,0) * ep^4 * num(8)
	+ mibox(1,0,0,0) * ep^5 * num(16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(52*s^2+104*s*t-424*s+52*t^2-424*t+864)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(320*s^2+640*s*t-2576*s+320*t^2-2576*t+5184)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(1936*s^2+3872*s*t-15520*s+1936*t^2-15520*t+31104)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(11648*s^2+23296*s*t-93248*s+11648*t^2-93248*t+186624)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)
	+ mibox(1,0,0,0) * ep^3 * num(6)
	+ mibox(1,0,0,0) * ep^4 * num(-12)
	+ mibox(1,0,0,0) * ep^5 * num(24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(4*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(16*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s)
	+ mibox(1,0,0,0) * ep^4 * num(4*s)
	+ mibox(1,0,0,0) * ep^5 * num(8*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * num(-s+2)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s+4)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+40*s-6*t^2+40*t-64)
	+ mibox(1,0,0,0) * ep^3 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+160*s-24*t^2+160*t-256)
	+ mibox(1,0,0,0) * ep^5 * num(-64*s-64*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,2,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^2+8*s*t-32*s+4*t^2-32*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(8*s^2+16*s*t-64*s+8*t^2-64*t+128)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^2+32*s*t-128*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2+s*t-6*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^2+2*s*t-12*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^2+4*s*t-24*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^2+8*s*t-48*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^2+4*s)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,3,1,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * num(11)*den(18)
	+ mibox(1,0,0,0) * ep^3 * num(-38)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(238)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-1448)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,2,0) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3)
	+ mibox(1,0,0,0) * ep^4 * num(-6)
	+ mibox(1,0,0,0) * ep^5 * num(12)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,3,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^3 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3)
	+ mibox(1,0,0,0) * ep^5 * num(-6)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,3,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * num(-19*s-19*t+49)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(119*s+119*t-314)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(-724*s-724*t+1924)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(4364*s+4364*t-11624)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s-3*t+14)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s+3*t-12)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s-3*t+12)
	+ mibox(1,0,0,0) * ep^5 * num(6*s+6*t-24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,3,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s-6)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s+6)
	+ mibox(1,0,0,0) * ep^4 * num(6*s-12)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s+24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,3,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * num(46*s^2+92*s*t-260*s+46*t^2-260*t+322)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(-200*s^2-400*s*t+1276*s-200*t^2+1276*t-1796)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(1696*s^2+3392*s*t-9680*s+1696*t^2-9680*t+12232)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-7280*s^2-14560*s*t+46576*s-7280*t^2+46576*t-65936)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,2,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+44*s-6*t^2+44*t-80)
	+ mibox(1,0,0,0) * ep^3 * num(6*s^2+12*s*t-56*s+6*t^2-56*t+128)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+176*s-24*t^2+176*t-320)
	+ mibox(1,0,0,0) * ep^5 * num(24*s^2+48*s*t-224*s+24*t^2-224*t+512)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,3,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+6*s*t-22*s+3*t^2-22*t+42)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2+12*s*t-44*s+6*t^2-44*t+80)
	+ mibox(1,0,0,0) * ep^5 * num(8*s+8*t-32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,3,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-11*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2-3*s*t+14*s)
	+ mibox(1,0,0,0) * ep^4 * num(12*s^2+12*s*t-44*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2-12*s*t+56*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2-3*s*t+15*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(-12*s^2-12*s*t+60*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-14*s-4*t+16)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2+3*s*t-16*s-4*t+16)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2+3*s*t-16*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2+6*s*t-32*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,3,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2-8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(4*s)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2-16*s)
	+ mibox(1,0,0,0) * ep^5 * num(16*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,2,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2+8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2-3*s+2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s+8)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2-12*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,1,0) =
	+ mibox(1,0,1,0) * ep^-1 * 1*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,1,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-t+4)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(2*s+2*t-8)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * num(4*s+4*t-16)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(8*s+8*t-32)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(16*s+16*t-64)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(32*s+32*t-128)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+2*s*t-8*s+t^2-8*t+16)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-s^2+2*s*t+8*s+2*t^2-8*t-16)*den(2*s-8)
	+ mibox(1,0,1,0) * ep^1 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^3 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^4 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^5 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-2*s*t+8*s-t^2+8*t-16)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+17*s-2*t^2+16*t-36)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^2-8*s*t+32*s-4*t^2+32*t-64)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * num(-8*s^2-16*s*t+64*s-8*t^2+64*t-128)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(-16*s^2-32*s*t+128*s-16*t^2+128*t-256)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(-32*s^2-64*s*t+256*s-32*t^2+256*t-512)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(-64*s^2-128*s*t+512*s-64*t^2+512*t-1024)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(6)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(24)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * num(-6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^3 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^4 * num(-6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^5 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(4*s-12)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(-10*s+36)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(22*s-84)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(-46*s+180)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(6)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(24)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,1,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,1,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-2*t+4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(4*s+6*t-16)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * num(6*s+6*t-24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^4 * num(6*s+6*t-24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+2*t-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(4*s^2+4*s*t-28*s-12*t+48)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-10*s^2-10*s*t+76*s+36*t-144)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(22*s^2+22*s*t-172*s-84*t+336)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(-46*s^2-46*s*t+364*s+180*t-720)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(94*s^2+94*s*t-748*s-372*t+1488)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,2,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-4*s^3-8*s^2*t+52*s^2-4*s*t^2+76*s*t-224*s+24*t^2-176*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^3+8*s^2*t-40*s^2+4*s*t^2-40*s*t+128*s+32*t-128)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(-16*s^3-32*s^2*t+208*s^2-16*s*t^2+304*s*t-896*s+96*t^2-704*t+1280)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^3+32*s^2*t-160*s^2+16*s*t^2-160*s*t+512*s+128*t-512)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-12*s*t+40*s-6*t^2+48*t-80)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+6*s*t-20*s+3*t^2-20*t+32)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-6*s^3-12*s^2*t+68*s^2-6*s*t^2+80*s*t-256*s+12*t^2-128*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(18*s^3+36*s^2*t-212*s^2+18*s*t^2-296*s*t+832*s-84*t^2+608*t-1088)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(-30*s^3-60*s^2*t+356*s^2-30*s*t^2+440*s*t-1408*s+84*t^2-800*t+1856)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(78*s^3+156*s^2*t-932*s^2+78*s*t^2-1304*s*t+3712*s-372*t^2+2720*t-4928)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(-126*s^3-252*s^2*t+1508*s^2-126*s*t^2+1880*s*t-6016*s+372*t^2-3488*t+8000)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,2,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-4*s^3-8*s^2*t+52*s^2-4*s*t^2+76*s*t-224*s+24*t^2-176*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^3+8*s^2*t-40*s^2+4*s*t^2-40*s*t+128*s+32*t-128)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(-16*s^3-32*s^2*t+208*s^2-16*s*t^2+304*s*t-896*s+96*t^2-704*t+1280)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^3+32*s^2*t-160*s^2+16*s*t^2-160*s*t+512*s+128*t-512)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-4*s-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(s^3-12*s^2+40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-2*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * num(-5*s^2+76*s-296)*den(18*s^3-216*s^2+864*s-1152)
	+ mibox(1,0,0,0) * ep^3 * num(5*s^2-94*s+404)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-10*s^2+242*s-1132)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(20*s^2-646*s+3236)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(4*s-4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-14*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-4*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-4*s-8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2+16*s-8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^2-16*s+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-2*s^2+16*s-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(2*s^2-16*s+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,1,0) =
	+ mibox(1,0,1,0) * ep^0 * 1*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-3)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * num(-9)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,1,0) * ep^3 * num(33)*den(8*s^3-96*s^2+384*s-512)
	+ mibox(1,0,1,0) * ep^4 * num(-81)*den(16*s^3-192*s^2+768*s-1024)
	+ mibox(1,0,1,0) * ep^5 * num(177)*den(32*s^3-384*s^2+1536*s-2048)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+14*s-34)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * num(13*s^2-194*s+694)*den(72*s^3-864*s^2+3456*s-4608)
	+ mibox(1,0,0,0) * ep^3 * num(-79*s^2+1334*s-5314)*den(432*s^3-5184*s^2+20736*s-27648)
	+ mibox(1,0,0,0) * ep^4 * num(397*s^2-7874*s+34054)*den(2592*s^3-31104*s^2+124416*s-165888)
	+ mibox(1,0,0,0) * ep^5 * num(-1831*s^2+44294*s-205714)*den(15552*s^3-186624*s^2+746496*s-995328)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * num(-5*s^2+76*s-296)*den(18*s^3-216*s^2+864*s-1152)
	+ mibox(1,0,0,0) * ep^3 * num(5*s^2-94*s+404)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-10*s^2+242*s-1132)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(20*s^2-646*s+3236)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-4*s-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(s^3-12*s^2+40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-2*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(2*s^2-2*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(6*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^4+3*s^3*t-46*s^3-36*s^2*t+224*s^2+104*s*t-384*s-48*t+128)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^4-3*s^3*t+48*s^3+36*s^2*t-244*s^2-100*s*t+424*s+24*t-96)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^4+3*s^3*t-48*s^3-36*s^2*t+242*s^2+98*s*t-404*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s^4-6*s^3*t+96*s^3+72*s^2*t-482*s^2-194*s*t+788*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * num(-11*s^3-11*s^2*t+177*s^2+160*s*t-816*s-392*t+1136)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(76*s^3+76*s^2*t-1290*s^2-1148*s*t+6456*s+3160*t-10048)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-476*s^3-476*s^2*t+8304*s^2+7372*s*t-42936*s-21224*t+69344)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(2896*s^3+2896*s^2*t-51276*s^2-45524*s*t+269256*s+133816*t-441952)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(2*s^2+4*s*t-8*s-4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-8*s^2-10*s*t+36*s+12*t-16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(10*s^2+6*s*t-52*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s^2-6*s*t+36*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(6*s^2+6*s*t-36*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s^2-6*s*t+36*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+8*s+4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s^2+4*s*t-12*s-16*t+16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(-4*s^3-4*s^2*t+24*s^2+8*s*t-16*s+24*t-64)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^3 * num(10*s^3+10*s^2*t-72*s^2-32*s*t+104*s-24*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-22*s^3-22*s^2*t+168*s^2+80*s*t-296*s+24*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(46*s^3+46*s^2*t-360*s^2-176*s*t+680*s-24*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s+3*t-4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-9*s-21*t+36)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * num(33*s+57*t-132)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,1,0) * ep^3 * num(-81*s-129*t+324)*den(8*s^3-96*s^2+384*s-512)
	+ mibox(1,0,1,0) * ep^4 * num(177*s+273*t-708)*den(16*s^3-192*s^2+768*s-1024)
	+ mibox(1,0,1,0) * ep^5 * num(-369*s-561*t+1476)*den(32*s^3-384*s^2+1536*s-2048)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-3*t+4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+14*s^2+14*s*t-50*s-10*t+40)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,0,0) * ep^2 * num(25*s^3+25*s^2*t-366*s^2-362*s*t+1590*s+814*t-2104)*den(24*s^3-288*s^2+1152*s-1536)
	+ mibox(1,0,0,0) * ep^3 * num(-379*s^3-379*s^2*t+5754*s^2+5678*s*t-26850*s-15082*t+39592)*den(144*s^3-1728*s^2+6912*s-9216)
	+ mibox(1,0,0,0) * ep^4 * num(4945*s^3+4945*s^2*t-76782*s^2-76010*s*t+370470*s+215038*t-569848)*den(864*s^3-10368*s^2+41472*s-55296)
	+ mibox(1,0,0,0) * ep^5 * num(-61171*s^3-61171*s^2*t+962634*s^2+956414*s*t-4724850*s-2786170*t+7412200)*den(5184*s^3-62208*s^2+248832*s-331776)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * num(-11*s^3-11*s^2*t+177*s^2+160*s*t-816*s-392*t+1136)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(76*s^3+76*s^2*t-1290*s^2-1148*s*t+6456*s+3160*t-10048)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-476*s^3-476*s^2*t+8304*s^2+7372*s*t-42936*s-21224*t+69344)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(2896*s^3+2896*s^2*t-51276*s^2-45524*s*t+269256*s+133816*t-441952)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,3,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(2*s^2-2*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(6*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^4+3*s^3*t-46*s^3-36*s^2*t+224*s^2+104*s*t-384*s-48*t+128)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^4-3*s^3*t+48*s^3+36*s^2*t-244*s^2-100*s*t+424*s+24*t-96)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^4+3*s^3*t-48*s^3-36*s^2*t+242*s^2+98*s*t-404*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s^4-6*s^3*t+96*s^3+72*s^2*t-482*s^2-194*s*t+788*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * num(-s^3+2*s^2-12*s*t+32*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^5-6*s^4*t+60*s^4-3*s^3*t^2+96*s^3*t-434*s^3+36*s^2*t^2-488*s^2*t+1380*s^2-100*s*t^2+848*s*t-1728*s+24*t^2-192*t+320)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+434*s^3-36*s^2*t^2+484*s^2*t-1372*s^2+98*s*t^2-808*s*t+1664*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^5-12*s^4*t+120*s^4-6*s^3*t^2+192*s^3*t-866*s^3+72*s^2*t^2-964*s^2*t+2716*s^2-194*s*t^2+1576*s*t-3200*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1730*s^3-144*s^2*t^2+1924*s^2*t-5404*s^2+386*s*t^2-3112*s*t+6272*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * num(38*s^4+76*s^3*t-770*s^3+38*s^2*t^2-1344*s^2*t+5484*s^2-574*s*t^2+6888*s*t-16640*s+1580*t^2-10912*t+18368)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(-238*s^4-476*s^3*t+4942*s^3-238*s^2*t^2+8628*s^2*t-36132*s^2+3686*s*t^2-45528*s*t+112768*s-10612*t^2+74528*t-128320)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(1448*s^4+2896*s^3*t-30458*s^3+1448*s^2*t^2-53220*s^2*t+225516*s^2-22762*s*t^2+284808*s*t-712832*s+66908*t^2-473056*t+821696)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-8728*s^4-17456*s^3*t+184846*s^3-8728*s^2*t^2+323196*s^2*t-1377348*s^2+138350*s*t^2-1741848*s*t+4380544*s-410836*t^2+2913440*t-5080384)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,2,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-8*s^3-18*s^2*t+66*s^2-10*s*t^2+88*s*t-144*s+12*t^2-64*t+32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(11*s^3+16*s^2*t-96*s^2+6*s*t^2-88*s*t+240*s-12*t^2+96*t-128)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-8*s^3-12*s^2*t+76*s^2-6*s*t^2+72*s*t-224*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^3+12*s^2*t-60*s^2+6*s*t^2-72*s*t+192*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^3-12*s^2*t+60*s^2-6*s*t^2+72*s*t-192*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^3+12*s^2*t-60*s^2+6*s*t^2-72*s*t+192*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^3-6*s^2*t+16*s^2-4*s*t^2+28*s*t-32*s+4*t^2-16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-6*s^3+s^2*t^2-2*s^2*t-2*s^2+4*s*t^2-44*s*t+48*s-16*t^2+80*t-32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^4-8*s^3*t+40*s^3-4*s^2*t^2+48*s^2*t-118*s^2+8*s*t^2-24*s*t+48*s+24*t^2-160*t+160)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(10*s^4+20*s^3*t-112*s^3+10*s^2*t^2-144*s^2*t+396*s^2-32*s*t^2+208*s*t-352*s-24*t^2+192*t-320)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^3 * num(-22*s^4-44*s^3*t+256*s^3-22*s^2*t^2+336*s^2*t-968*s^2+80*s*t^2-592*s*t+1088*s+24*t^2-192*t+384)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(46*s^4+92*s^3*t-544*s^3+46*s^2*t^2-720*s^2*t+2120*s^2-176*s*t^2+1360*s*t-2624*s-24*t^2+192*t-384)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(-94*s^4-188*s^3*t+1120*s^3-94*s^2*t^2+1488*s^2*t-4424*s^2+368*s*t^2-2896*s*t+5696*s+24*t^2-192*t+384)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+6*s*t-8*s+6*t^2-24*t+16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-24*s*t+40*s-21*t^2+96*t-80)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(21*s^2+78*s*t-168*s+57*t^2-312*t+336)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * num(-57*s^2-186*s*t+456*s-129*t^2+744*t-912)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,1,0) * ep^3 * num(129*s^2+402*s*t-1032*s+273*t^2-1608*t+2064)*den(8*s^3-96*s^2+384*s-512)
	+ mibox(1,0,1,0) * ep^4 * num(-273*s^2-834*s*t+2184*s-561*t^2+3336*t-4368)*den(16*s^3-192*s^2+768*s-1024)
	+ mibox(1,0,1,0) * ep^5 * num(561*s^2+1698*s*t-4488*s+1137*t^2-6792*t+8976)*den(32*s^3-384*s^2+1536*s-2048)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-6*s*t+8*s-6*t^2+24*t-16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+16*s^3-s^2*t^2+30*s^2*t-88*s^2+14*s*t^2-108*s*t+192*s-10*t^2+80*t-128)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(25*s^4+50*s^3*t-418*s^3+25*s^2*t^2-780*s^2*t+2526*s^2-362*s*t^2+3516*s*t-6544*s+814*t^2-4784*t+6112)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * num(-379*s^4-758*s^3*t+6550*s^3-379*s^2*t^2+12228*s^2*t-41514*s^2+5678*s*t^2-59172*s*t+114736*s-15082*t^2+89552*t-116896)*den(72*s^3-864*s^2+3456*s-4608)
	+ mibox(1,0,0,0) * ep^3 * num(4945*s^4+9890*s^3*t-87058*s^3+4945*s^2*t^2-163068*s^2*t+565278*s^2-76010*s*t^2+815244*s*t-1609360*s+215038*t^2-1284848*t+1698784)*den(432*s^3-5184*s^2+20736*s-27648)
	+ mibox(1,0,0,0) * ep^4 * num(-61171*s^4-122342*s^3*t+1088086*s^3-61171*s^2*t^2+2044500*s^2*t-7154970*s^2+956414*s*t^2-10393188*s*t+20671408*s-2786170*t^2+16690640*t-22183840)*den(2592*s^3-31104*s^2+124416*s-165888)
	+ mibox(1,0,0,0) * ep^5 * num(742105*s^4+1484210*s^3*t-13274818*s^3+742105*s^2*t^2-24998460*s^2*t+87873486*s^2-11723642*s*t^2+128194476*s*t-255775504*s+34652014*t^2-207791984*t+276735712)*den(15552*s^3-186624*s^2+746496*s-995328)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,2,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * num(38*s^4+76*s^3*t-770*s^3+38*s^2*t^2-1344*s^2*t+5484*s^2-574*s*t^2+6888*s*t-16640*s+1580*t^2-10912*t+18368)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(-238*s^4-476*s^3*t+4942*s^3-238*s^2*t^2+8628*s^2*t-36132*s^2+3686*s*t^2-45528*s*t+112768*s-10612*t^2+74528*t-128320)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(1448*s^4+2896*s^3*t-30458*s^3+1448*s^2*t^2-53220*s^2*t+225516*s^2-22762*s*t^2+284808*s*t-712832*s+66908*t^2-473056*t+821696)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-8728*s^4-17456*s^3*t+184846*s^3-8728*s^2*t^2+323196*s^2*t-1377348*s^2+138350*s*t^2-1741848*s*t+4380544*s-410836*t^2+2913440*t-5080384)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,3,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * num(-s^3+2*s^2-12*s*t+32*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^5-6*s^4*t+60*s^4-3*s^3*t^2+96*s^3*t-434*s^3+36*s^2*t^2-488*s^2*t+1380*s^2-100*s*t^2+848*s*t-1728*s+24*t^2-192*t+320)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+434*s^3-36*s^2*t^2+484*s^2*t-1372*s^2+98*s*t^2-808*s*t+1664*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^5-12*s^4*t+120*s^4-6*s^3*t^2+192*s^3*t-866*s^3+72*s^2*t^2-964*s^2*t+2716*s^2-194*s*t^2+1576*s*t-3200*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1730*s^3-144*s^2*t^2+1924*s^2*t-5404*s^2+386*s*t^2-3112*s*t+6272*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,0,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^3 * num(4)
	+ mibox(1,0,0,0) * ep^4 * num(8)
	+ mibox(1,0,0,0) * ep^5 * num(16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(52*s^2+104*s*t-424*s+52*t^2-424*t+864)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(320*s^2+640*s*t-2576*s+320*t^2-2576*t+5184)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(1936*s^2+3872*s*t-15520*s+1936*t^2-15520*t+31104)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(11648*s^2+23296*s*t-93248*s+11648*t^2-93248*t+186624)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,0,1) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)
	+ mibox(1,0,0,0) * ep^3 * num(6)
	+ mibox(1,0,0,0) * ep^4 * num(-12)
	+ mibox(1,0,0,0) * ep^5 * num(24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * num(-s+2)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s+4)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s)
	+ mibox(1,0,0,0) * ep^4 * num(4*s)
	+ mibox(1,0,0,0) * ep^5 * num(8*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(4*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(16*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^2+4*s)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2+s*t-6*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^2+2*s*t-12*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^2+4*s*t-24*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^2+8*s*t-48*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^2+8*s*t-32*s+4*t^2-32*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(8*s^2+16*s*t-64*s+8*t^2-64*t+128)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^2+32*s*t-128*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+40*s-6*t^2+40*t-64)
	+ mibox(1,0,0,0) * ep^3 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+160*s-24*t^2+160*t-256)
	+ mibox(1,0,0,0) * ep^5 * num(-64*s-64*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,0,1) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^3 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3)
	+ mibox(1,0,0,0) * ep^5 * num(-6)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,0,2) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3)
	+ mibox(1,0,0,0) * ep^4 * num(-6)
	+ mibox(1,0,0,0) * ep^5 * num(12)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,0,3) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * num(11)*den(18)
	+ mibox(1,0,0,0) * ep^3 * num(-38)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(238)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-1448)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s-6)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s+6)
	+ mibox(1,0,0,0) * ep^4 * num(6*s-12)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s+24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s-3*t+14)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s+3*t-12)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s-3*t+12)
	+ mibox(1,0,0,0) * ep^5 * num(6*s+6*t-24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,0,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * num(-19*s-19*t+49)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(119*s+119*t-314)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(-724*s-724*t+1924)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(4364*s+4364*t-11624)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,-2,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2-3*s+2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s+8)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2-12*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,-2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2+8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,-2,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2-8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(4*s)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2-16*s)
	+ mibox(1,0,0,0) * ep^5 * num(16*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-14*s-4*t+16)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2+3*s*t-16*s-4*t+16)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2+3*s*t-16*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2+6*s*t-32*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2-3*s*t+15*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(-12*s^2-12*s*t+60*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,-1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-11*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2-3*s*t+14*s)
	+ mibox(1,0,0,0) * ep^4 * num(12*s^2+12*s*t-44*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2-12*s*t+56*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-2,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+6*s*t-22*s+3*t^2-22*t+42)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2+12*s*t-44*s+6*t^2-44*t+80)
	+ mibox(1,0,0,0) * ep^5 * num(8*s+8*t-32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+44*s-6*t^2+44*t-80)
	+ mibox(1,0,0,0) * ep^3 * num(6*s^2+12*s*t-56*s+6*t^2-56*t+128)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+176*s-24*t^2+176*t-320)
	+ mibox(1,0,0,0) * ep^5 * num(24*s^2+48*s*t-224*s+24*t^2-224*t+512)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,0,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * num(46*s^2+92*s*t-260*s+46*t^2-260*t+322)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(-200*s^2-400*s*t+1276*s-200*t^2+1276*t-1796)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(1696*s^2+3392*s*t-9680*s+1696*t^2-9680*t+12232)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-7280*s^2-14560*s*t+46576*s-7280*t^2+46576*t-65936)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,-2,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s^2+2*s*t-7*s+t^2-7*t+12)*den(3)
	+ mibox(0,1,0,1) * ep^1 * num(s^2+2*s*t-4*s+t^2-4*t)*den(18)
	+ mibox(0,1,0,1) * ep^2 * num(s^2+2*s*t-4*s+t^2-4*t)*den(27)
	+ mibox(0,1,0,1) * ep^3 * num(2*s^2+4*s*t-8*s+2*t^2-8*t)*den(81)
	+ mibox(0,1,0,1) * ep^4 * num(4*s^2+8*s*t-16*s+4*t^2-16*t)*den(243)
	+ mibox(0,1,0,1) * ep^5 * num(8*s^2+16*s*t-32*s+8*t^2-32*t)*den(729)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s^2+3*s*t-10*s+2*t^2-14*t+24)*den(6)
	+ mibox(0,1,0,1) * ep^1 * num(-s^2+4*s+t^2-4*t)*den(18)
	+ mibox(0,1,0,1) * ep^2 * num(-s^2+4*s+t^2-4*t)*den(27)
	+ mibox(0,1,0,1) * ep^3 * num(-2*s^2+8*s+2*t^2-8*t)*den(81)
	+ mibox(0,1,0,1) * ep^4 * num(-4*s^2+16*s+4*t^2-16*t)*den(243)
	+ mibox(0,1,0,1) * ep^5 * num(-8*s^2+32*s+8*t^2-32*t)*den(729)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-2,1,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s^2+2*s*t-7*s+t^2-7*t+12)*den(3)
	+ mibox(0,1,0,1) * ep^1 * num(s^2+2*s*t-4*s+t^2-4*t)*den(18)
	+ mibox(0,1,0,1) * ep^2 * num(s^2+2*s*t-4*s+t^2-4*t)*den(27)
	+ mibox(0,1,0,1) * ep^3 * num(2*s^2+4*s*t-8*s+2*t^2-8*t)*den(81)
	+ mibox(0,1,0,1) * ep^4 * num(4*s^2+8*s*t-16*s+4*t^2-16*t)*den(243)
	+ mibox(0,1,0,1) * ep^5 * num(8*s^2+16*s*t-32*s+8*t^2-32*t)*den(729)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,2,0,1) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,0,2) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,2,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,-1,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,2,0,1) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,0,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,2,-2,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,-2,2) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,2,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,-1,2) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-2,2,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-2,1,0,2) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,3,0,1) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,2,0,2) =
	+ mibox(0,1,0,1) * ep^0 * num(-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,0,3) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,3,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,2,-1,2) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * num(2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,-1,3) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,3,0,1) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,2,0,2) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * num(2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,0,3) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,3,-2,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,2,-2,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-2*t+6)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * 1
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,-2,3) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,3,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,2,-1,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-s-2*t+6)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * 1
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,-1,3) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-2,3,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-2,2,0,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-2*t+6)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * 1
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(-2,1,0,3) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * 1*den(2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(1,1,-1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2+s*t-4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^2 * num(4*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^3 * num(8*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^4 * num(16*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^5 * num(32*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^4+2*s^3*t-8*s^3+s^2*t^2-6*s^2*t+16*s^2+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^3 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^4 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^5 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^3+s^2*t+12*s^2+5*s*t^2-16*s*t+t^3-4*t^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^3 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^4 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^5 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(3*s^3+3*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(4*s^3+4*s^2*t-16*s^2+16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(8*s^3+8*s^2*t-32*s^2+32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(16*s^3+16*s^2*t-64*s^2+64*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(32*s^3+32*s^2*t-128*s^2+128*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,0,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-1)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(1,2,0,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * num(3)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,0,2) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * num(3)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-s^2-s*t+4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s)*den(s+t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s+t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s+t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^3+2*s^2*t+8*s^2+4*s*t^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t-4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^3-3*s^2*t+4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3-2*s^2*t+16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^3-4*s^2*t+32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^3-8*s^2*t+64*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^3-16*s^2*t+128*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(s^3+s^2*t+4*s^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^3+2*s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^3+4*s^2*t+16*s^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^3+8*s^2*t+32*s^2-32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(s^3+s^2*t+4*s^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^3+2*s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^3+4*s^2*t+16*s^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^3+8*s^2*t+32*s^2-32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,0,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t-2)*den(2*s+2*t-8)
	+ mibox(1,1,0,1) * ep^2 * 1*den(2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^3 * num(3)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,0,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * num(-1)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,0,2) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * num(-1)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,0,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * num(5*s+5*t-38)*den(36*s^2+72*s*t-288*s+36*t^2-288*t+576)
	+ mibox(1,0,0,0) * ep^3 * num(-5)*den(54*s+54*t-216)
	+ mibox(1,0,0,0) * ep^4 * num(5)*den(81*s+81*t-324)
	+ mibox(1,0,0,0) * ep^5 * num(-10)*den(243*s+243*t-972)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,0,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t+2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * num(4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(-7)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^3 * num(12)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(-24)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(48)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,0,3) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * num(5*s+5*t-38)*den(36*s^2+72*s*t-288*s+36*t^2-288*t+576)
	+ mibox(1,0,0,0) * ep^3 * num(-5)*den(54*s+54*t-216)
	+ mibox(1,0,0,0) * ep^4 * num(5)*den(81*s+81*t-324)
	+ mibox(1,0,0,0) * ep^5 * num(-10)*den(243*s+243*t-972)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,-1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*t)*den(2*s+2*t)
	+ mibox(1,1,0,1) * ep^2 * num(s^2+s*t-4*s)*den(2*s+2*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-s^2-s*t+4*t)*den(2*s^2+4*s*t-8*s+2*t^2-8*t)
	+ mibox(0,1,0,1) * ep^2 * num(-s)*den(s+t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,-1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+5*s+3*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^3 * num(3*s-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s+12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(12*s-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+5*s+3*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^3 * num(3*s-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s+12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(12*s-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,-1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * num(-2*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(3*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(4*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^2-2*s*t+6*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s+4*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-1,3) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * num(-2*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(3*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2-4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-8*s^2*t-8*s^2-6*s*t^2+24*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(s^4+2*s^3*t-8*s^3+s^2*t^2-8*s^2*t+16*s^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-s^3-s^2*t-4*s^2+12*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-s^3-s^2*t+4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+4*s^2-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(s^3+s^2*t-2*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^3-s^2*t+4*s^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,-2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^3-s^2*t+4*s^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-3*s^2+2*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^4-6*s^3*t+10*s^3-3*s^2*t^2+22*s^2*t+8*s^2+12*s*t^2)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s^2+12*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,-2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3-8*s^2-2*s*t^2+4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-10*s^3+s^2*t^2-10*s^2*t+24*s^2-8*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+11*s^2-6*s*t-t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-6*s^2+4*s*t+2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+4*s^2-2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,-2,3) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-3*s^2+2*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^4-6*s^3*t+10*s^3-3*s^2*t^2+22*s^2*t+8*s^2+12*s*t^2)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s^2+12*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,1,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * num(2)
	+ mibox(1,0,0,0) * ep^3 * num(4)
	+ mibox(1,0,0,0) * ep^4 * num(8)
	+ mibox(1,0,0,0) * ep^5 * num(16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(52*s^2+104*s*t-424*s+52*t^2-424*t+864)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(320*s^2+640*s*t-2576*s+320*t^2-2576*t+5184)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(1936*s^2+3872*s*t-15520*s+1936*t^2-15520*t+31104)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(11648*s^2+23296*s*t-93248*s+11648*t^2-93248*t+186624)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2+8*s)*den(27)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2+16*s)*den(81)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2+32*s)*den(243)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2+64*s)*den(729)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,2,1) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)
	+ mibox(1,0,0,0) * ep^3 * num(6)
	+ mibox(1,0,0,0) * ep^4 * num(-12)
	+ mibox(1,0,0,0) * ep^5 * num(24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s-2*t+8)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(4*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(16*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,2,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * num(-s+2)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s+4)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s)
	+ mibox(1,0,0,0) * ep^4 * num(4*s)
	+ mibox(1,0,0,0) * ep^5 * num(8*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^2+8*s*t-32*s+4*t^2-32*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(8*s^2+16*s*t-64*s+8*t^2-64*t+128)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^2+32*s*t-128*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+40*s-6*t^2+40*t-64)
	+ mibox(1,0,0,0) * ep^3 * num(-16*s-16*t+64)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+160*s-24*t^2+160*t-256)
	+ mibox(1,0,0,0) * ep^5 * num(-64*s-64*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2+s*t-6*s-2*t+8)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^2+2*s*t-12*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^2+4*s*t-24*s-8*t+32)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^2+8*s*t-48*s-16*t+64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+8*s)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^2-4*s*t+16*s)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^2-8*s*t+32*s)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^2-16*s*t+64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^2+4*s)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-4*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-8*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,3,1) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * 1
	+ mibox(1,0,0,0) * ep^3 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3)
	+ mibox(1,0,0,0) * ep^5 * num(-6)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,2,2) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3)
	+ mibox(1,0,0,0) * ep^4 * num(-6)
	+ mibox(1,0,0,0) * ep^5 * num(12)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,0,1,3) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * num(11)*den(18)
	+ mibox(1,0,0,0) * ep^3 * num(-38)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(238)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-1448)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s-3*t+14)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s+3*t-12)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s-3*t+12)
	+ mibox(1,0,0,0) * ep^5 * num(6*s+6*t-24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-1,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * num(-19*s-19*t+49)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(119*s+119*t-314)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(-724*s-724*t+1924)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(4364*s+4364*t-11624)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s-6)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s+6)
	+ mibox(1,0,0,0) * ep^4 * num(6*s-12)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s+24)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,0,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+6*s*t-22*s+3*t^2-22*t+42)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2+12*s*t-44*s+6*t^2-44*t+80)
	+ mibox(1,0,0,0) * ep^5 * num(8*s+8*t-32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(-6*s^2-12*s*t+44*s-6*t^2+44*t-80)
	+ mibox(1,0,0,0) * ep^3 * num(6*s^2+12*s*t-56*s+6*t^2-56*t+128)
	+ mibox(1,0,0,0) * ep^4 * num(-24*s^2-48*s*t+176*s-24*t^2+176*t-320)
	+ mibox(1,0,0,0) * ep^5 * num(24*s^2+48*s*t-224*s+24*t^2-224*t+512)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,-2,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * num(46*s^2+92*s*t-260*s+46*t^2-260*t+322)*den(9)
	+ mibox(1,0,0,0) * ep^3 * num(-200*s^2-400*s*t+1276*s-200*t^2+1276*t-1796)*den(27)
	+ mibox(1,0,0,0) * ep^4 * num(1696*s^2+3392*s*t-9680*s+1696*t^2-9680*t+12232)*den(81)
	+ mibox(1,0,0,0) * ep^5 * num(-7280*s^2-14560*s*t+46576*s-7280*t^2+46576*t-65936)*den(243)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-14*s-4*t+16)*den(4)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2+3*s*t-16*s-4*t+16)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2+3*s*t-16*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2+6*s*t-32*s-8*t+32)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2-3*s*t+15*s+4*t-14)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-4*t+20)
	+ mibox(1,0,0,0) * ep^4 * num(-12*s^2-12*s*t+60*s+16*t-56)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-16*t+80)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,-1,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-11*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2-3*s*t+14*s)
	+ mibox(1,0,0,0) * ep^4 * num(12*s^2+12*s*t-44*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2-12*s*t+56*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,3,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * num(s^2-3*s+2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s+8)*den(2)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^2-12*s+8)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^2+8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^2+8*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^2+16*s)
	+ mibox(1,0,0,0) * ep^5 * num(-12*s^2+32*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,0,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2-8*s)*den(2)
	+ mibox(1,0,0,0) * ep^3 * num(4*s)
	+ mibox(1,0,0,0) * ep^4 * num(6*s^2-16*s)
	+ mibox(1,0,0,0) * ep^5 * num(16*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * 1*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-t+4)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(2*s+2*t-8)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * num(4*s+4*t-16)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(8*s+8*t-32)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(16*s+16*t-64)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(32*s+32*t-128)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+2*s*t-8*s+t^2-8*t+16)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-s^2+2*s*t+8*s+2*t^2-8*t-16)*den(2*s-8)
	+ mibox(1,0,1,0) * ep^1 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^3 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^4 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^5 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-2*s*t+8*s-t^2+8*t-16)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+17*s-2*t^2+16*t-36)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^2-8*s*t+32*s-4*t^2+32*t-64)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * num(-8*s^2-16*s*t+64*s-8*t^2+64*t-128)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(-16*s^2-32*s*t+128*s-16*t^2+128*t-256)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(-32*s^2-64*s*t+256*s-32*t^2+256*t-512)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(-64*s^2-128*s*t+512*s-64*t^2+512*t-1024)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,1,1) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(6)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(24)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,2,1) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(6)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(24)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,1,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * num(-6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^3 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^4 * num(-6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^5 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(4*s-12)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(-10*s+36)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(22*s-84)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(-46*s+180)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,2,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * num(3*s+3*t-12)*den(s-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6*s-6*t+24)*den(s-4)
	+ mibox(1,0,0,0) * ep^4 * num(12*s+12*t-48)*den(s-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24*s-24*t+96)*den(s-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,1,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-2*t+4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(4*s+6*t-16)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * num(6*s+6*t-24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^4 * num(6*s+6*t-24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+2*t-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(4*s^2+4*s*t-28*s-12*t+48)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-10*s^2-10*s*t+76*s+36*t-144)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(22*s^2+22*s*t-172*s-84*t+336)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(-46*s^2-46*s*t+364*s+180*t-720)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(94*s^2+94*s*t-748*s-372*t+1488)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-4*s^3-8*s^2*t+52*s^2-4*s*t^2+76*s*t-224*s+24*t^2-176*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^3+8*s^2*t-40*s^2+4*s*t^2-40*s*t+128*s+32*t-128)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(-16*s^3-32*s^2*t+208*s^2-16*s*t^2+304*s*t-896*s+96*t^2-704*t+1280)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^3+32*s^2*t-160*s^2+16*s*t^2-160*s*t+512*s+128*t-512)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,2,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(-4*s^3-8*s^2*t+52*s^2-4*s*t^2+76*s*t-224*s+24*t^2-176*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(4*s^3+8*s^2*t-40*s^2+4*s*t^2-40*s*t+128*s+32*t-128)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(-16*s^3-32*s^2*t+208*s^2-16*s*t^2+304*s*t-896*s+96*t^2-704*t+1280)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(16*s^3+32*s^2*t-160*s^2+16*s*t^2-160*s*t+512*s+128*t-512)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,1,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-12*s*t+40*s-6*t^2+48*t-80)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+6*s*t-20*s+3*t^2-20*t+32)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-6*s^3-12*s^2*t+68*s^2-6*s*t^2+80*s*t-256*s+12*t^2-128*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * num(18*s^3+36*s^2*t-212*s^2+18*s*t^2-296*s*t+832*s-84*t^2+608*t-1088)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^3 * num(-30*s^3-60*s^2*t+356*s^2-30*s*t^2+440*s*t-1408*s+84*t^2-800*t+1856)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^4 * num(78*s^3+156*s^2*t-932*s^2+78*s*t^2-1304*s*t+3712*s-372*t^2+2720*t-4928)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^5 * num(-126*s^3-252*s^2*t+1508*s^2-126*s*t^2+1880*s*t-6016*s+372*t^2-3488*t+8000)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,0,1,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-4*s-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(s^3-12*s^2+40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-2*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,2,1) =
	+ mibox(1,0,1,0) * ep^0 * num(4*s-4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-14*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-4*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-4*s-8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2+16*s-8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^2-16*s+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-2*s^2+16*s-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(2*s^2-16*s+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,0,1,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * num(-5*s^2+76*s-296)*den(18*s^3-216*s^2+864*s-1152)
	+ mibox(1,0,0,0) * ep^3 * num(5*s^2-94*s+404)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-10*s^2+242*s-1132)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(20*s^2-646*s+3236)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,3,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-4*s-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(s^3-12*s^2+40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-2*s+12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(2*s-12)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,2,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-6)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * num(-5*s^2+76*s-296)*den(18*s^3-216*s^2+864*s-1152)
	+ mibox(1,0,0,0) * ep^3 * num(5*s^2-94*s+404)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-10*s^2+242*s-1132)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(20*s^2-646*s+3236)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,0,1,3) =
	+ mibox(1,0,1,0) * ep^0 * 1*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-3)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * num(-9)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,1,0) * ep^3 * num(33)*den(8*s^3-96*s^2+384*s-512)
	+ mibox(1,0,1,0) * ep^4 * num(-81)*den(16*s^3-192*s^2+768*s-1024)
	+ mibox(1,0,1,0) * ep^5 * num(177)*den(32*s^3-384*s^2+1536*s-2048)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+14*s-34)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * num(13*s^2-194*s+694)*den(72*s^3-864*s^2+3456*s-4608)
	+ mibox(1,0,0,0) * ep^3 * num(-79*s^2+1334*s-5314)*den(432*s^3-5184*s^2+20736*s-27648)
	+ mibox(1,0,0,0) * ep^4 * num(397*s^2-7874*s+34054)*den(2592*s^3-31104*s^2+124416*s-165888)
	+ mibox(1,0,0,0) * ep^5 * num(-1831*s^2+44294*s-205714)*den(15552*s^3-186624*s^2+746496*s-995328)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-1,1,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(2*s^2-2*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(6*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^4+3*s^3*t-46*s^3-36*s^2*t+224*s^2+104*s*t-384*s-48*t+128)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^4-3*s^3*t+48*s^3+36*s^2*t-244*s^2-100*s*t+424*s+24*t-96)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^4+3*s^3*t-48*s^3-36*s^2*t+242*s^2+98*s*t-404*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s^4-6*s^3*t+96*s^3+72*s^2*t-482*s^2-194*s*t+788*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,2,1) =
	+ mibox(1,0,1,0) * ep^0 * num(2*s^2+4*s*t-8*s-4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-8*s^2-10*s*t+36*s+12*t-16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(10*s^2+6*s*t-52*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s^2-6*s*t+36*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(6*s^2+6*s*t-36*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s^2-6*s*t+36*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+8*s+4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s^2+4*s*t-12*s-16*t+16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(-4*s^3-4*s^2*t+24*s^2+8*s*t-16*s+24*t-64)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^3 * num(10*s^3+10*s^2*t-72*s^2-32*s*t+104*s-24*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-22*s^3-22*s^2*t+168*s^2+80*s*t-296*s+24*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(46*s^3+46*s^2*t-360*s^2-176*s*t+680*s-24*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-1,1,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * num(-11*s^3-11*s^2*t+177*s^2+160*s*t-816*s-392*t+1136)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(76*s^3+76*s^2*t-1290*s^2-1148*s*t+6456*s+3160*t-10048)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-476*s^3-476*s^2*t+8304*s^2+7372*s*t-42936*s-21224*t+69344)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(2896*s^3+2896*s^2*t-51276*s^2-45524*s*t+269256*s+133816*t-441952)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,3,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(2*s^2-2*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(6*s+6*t-24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(-6*s-6*t+24)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^4+3*s^3*t-46*s^3-36*s^2*t+224*s^2+104*s*t-384*s-48*t+128)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s^4-3*s^3*t+48*s^3+36*s^2*t-244*s^2-100*s*t+424*s+24*t-96)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^4 * num(3*s^4+3*s^3*t-48*s^3-36*s^2*t+242*s^2+98*s*t-404*s-12*t+48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s^4-6*s^3*t+96*s^3+72*s^2*t-482*s^2-194*s*t+788*s+12*t-48)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,2,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(-12*s-12*t+48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(12*s+12*t-48)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * num(-11*s^3-11*s^2*t+177*s^2+160*s*t-816*s-392*t+1136)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(76*s^3+76*s^2*t-1290*s^2-1148*s*t+6456*s+3160*t-10048)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(-476*s^3-476*s^2*t+8304*s^2+7372*s*t-42936*s-21224*t+69344)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(2896*s^3+2896*s^2*t-51276*s^2-45524*s*t+269256*s+133816*t-441952)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-1,1,3) =
	+ mibox(1,0,1,0) * ep^0 * num(s+3*t-4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-9*s-21*t+36)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * num(33*s+57*t-132)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,1,0) * ep^3 * num(-81*s-129*t+324)*den(8*s^3-96*s^2+384*s-512)
	+ mibox(1,0,1,0) * ep^4 * num(177*s+273*t-708)*den(16*s^3-192*s^2+768*s-1024)
	+ mibox(1,0,1,0) * ep^5 * num(-369*s-561*t+1476)*den(32*s^3-384*s^2+1536*s-2048)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-3*t+4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+14*s^2+14*s*t-50*s-10*t+40)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,0,0) * ep^2 * num(25*s^3+25*s^2*t-366*s^2-362*s*t+1590*s+814*t-2104)*den(24*s^3-288*s^2+1152*s-1536)
	+ mibox(1,0,0,0) * ep^3 * num(-379*s^3-379*s^2*t+5754*s^2+5678*s*t-26850*s-15082*t+39592)*den(144*s^3-1728*s^2+6912*s-9216)
	+ mibox(1,0,0,0) * ep^4 * num(4945*s^3+4945*s^2*t-76782*s^2-76010*s*t+370470*s+215038*t-569848)*den(864*s^3-10368*s^2+41472*s-55296)
	+ mibox(1,0,0,0) * ep^5 * num(-61171*s^3-61171*s^2*t+962634*s^2+956414*s*t-4724850*s-2786170*t+7412200)*den(5184*s^3-62208*s^2+248832*s-331776)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,-2,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * num(-s^3+2*s^2-12*s*t+32*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^5-6*s^4*t+60*s^4-3*s^3*t^2+96*s^3*t-434*s^3+36*s^2*t^2-488*s^2*t+1380*s^2-100*s*t^2+848*s*t-1728*s+24*t^2-192*t+320)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+434*s^3-36*s^2*t^2+484*s^2*t-1372*s^2+98*s*t^2-808*s*t+1664*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^5-12*s^4*t+120*s^4-6*s^3*t^2+192*s^3*t-866*s^3+72*s^2*t^2-964*s^2*t+2716*s^2-194*s*t^2+1576*s*t-3200*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1730*s^3-144*s^2*t^2+1924*s^2*t-5404*s^2+386*s*t^2-3112*s*t+6272*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,2,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-8*s^3-18*s^2*t+66*s^2-10*s*t^2+88*s*t-144*s+12*t^2-64*t+32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(11*s^3+16*s^2*t-96*s^2+6*s*t^2-88*s*t+240*s-12*t^2+96*t-128)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * num(-8*s^3-12*s^2*t+76*s^2-6*s*t^2+72*s*t-224*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^3+12*s^2*t-60*s^2+6*s*t^2-72*s*t+192*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^3-12*s^2*t+60*s^2-6*s*t^2+72*s*t-192*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^3+12*s^2*t-60*s^2+6*s*t^2-72*s*t+192*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^3-6*s^2*t+16*s^2-4*s*t^2+28*s*t-32*s+4*t^2-16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-6*s^3+s^2*t^2-2*s^2*t-2*s^2+4*s*t^2-44*s*t+48*s-16*t^2+80*t-32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^4-8*s^3*t+40*s^3-4*s^2*t^2+48*s^2*t-118*s^2+8*s*t^2-24*s*t+48*s+24*t^2-160*t+160)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(10*s^4+20*s^3*t-112*s^3+10*s^2*t^2-144*s^2*t+396*s^2-32*s*t^2+208*s*t-352*s-24*t^2+192*t-320)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^3 * num(-22*s^4-44*s^3*t+256*s^3-22*s^2*t^2+336*s^2*t-968*s^2+80*s*t^2-592*s*t+1088*s+24*t^2-192*t+384)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(46*s^4+92*s^3*t-544*s^3+46*s^2*t^2-720*s^2*t+2120*s^2-176*s*t^2+1360*s*t-2624*s-24*t^2+192*t-384)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(-94*s^4-188*s^3*t+1120*s^3-94*s^2*t^2+1488*s^2*t-4424*s^2+368*s*t^2-2896*s*t+5696*s+24*t^2-192*t+384)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,-2,1,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * num(38*s^4+76*s^3*t-770*s^3+38*s^2*t^2-1344*s^2*t+5484*s^2-574*s*t^2+6888*s*t-16640*s+1580*t^2-10912*t+18368)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(-238*s^4-476*s^3*t+4942*s^3-238*s^2*t^2+8628*s^2*t-36132*s^2+3686*s*t^2-45528*s*t+112768*s-10612*t^2+74528*t-128320)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(1448*s^4+2896*s^3*t-30458*s^3+1448*s^2*t^2-53220*s^2*t+225516*s^2-22762*s*t^2+284808*s*t-712832*s+66908*t^2-473056*t+821696)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-8728*s^4-17456*s^3*t+184846*s^3-8728*s^2*t^2+323196*s^2*t-1377348*s^2+138350*s*t^2-1741848*s*t+4380544*s-410836*t^2+2913440*t-5080384)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,3,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * num(-s^3+2*s^2-12*s*t+32*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^3 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^4 * num(-6*s^2-12*s*t+48*s-6*t^2+48*t-96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^5 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^5-6*s^4*t+60*s^4-3*s^3*t^2+96*s^3*t-434*s^3+36*s^2*t^2-488*s^2*t+1380*s^2-100*s*t^2+848*s*t-1728*s+24*t^2-192*t+320)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+434*s^3-36*s^2*t^2+484*s^2*t-1372*s^2+98*s*t^2-808*s*t+1664*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^5-12*s^4*t+120*s^4-6*s^3*t^2+192*s^3*t-866*s^3+72*s^2*t^2-964*s^2*t+2716*s^2-194*s*t^2+1576*s*t-3200*s+12*t^2-96*t+192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1730*s^3-144*s^2*t^2+1924*s^2*t-5404*s^2+386*s*t^2-3112*s*t+6272*s-12*t^2+96*t-192)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,2,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^3 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^4 * num(18*s^2+36*s*t-144*s+18*t^2-144*t+288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^5 * num(-18*s^2-36*s*t+144*s-18*t^2+144*t-288)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * num(38*s^4+76*s^3*t-770*s^3+38*s^2*t^2-1344*s^2*t+5484*s^2-574*s*t^2+6888*s*t-16640*s+1580*t^2-10912*t+18368)*den(9*s^3-108*s^2+432*s-576)
	+ mibox(1,0,0,0) * ep^3 * num(-238*s^4-476*s^3*t+4942*s^3-238*s^2*t^2+8628*s^2*t-36132*s^2+3686*s*t^2-45528*s*t+112768*s-10612*t^2+74528*t-128320)*den(27*s^3-324*s^2+1296*s-1728)
	+ mibox(1,0,0,0) * ep^4 * num(1448*s^4+2896*s^3*t-30458*s^3+1448*s^2*t^2-53220*s^2*t+225516*s^2-22762*s*t^2+284808*s*t-712832*s+66908*t^2-473056*t+821696)*den(81*s^3-972*s^2+3888*s-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-8728*s^4-17456*s^3*t+184846*s^3-8728*s^2*t^2+323196*s^2*t-1377348*s^2+138350*s*t^2-1741848*s*t+4380544*s-410836*t^2+2913440*t-5080384)*den(243*s^3-2916*s^2+11664*s-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,-2,1,3) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+6*s*t-8*s+6*t^2-24*t+16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-24*s*t+40*s-21*t^2+96*t-80)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(21*s^2+78*s*t-168*s+57*t^2-312*t+336)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * num(-57*s^2-186*s*t+456*s-129*t^2+744*t-912)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,1,0) * ep^3 * num(129*s^2+402*s*t-1032*s+273*t^2-1608*t+2064)*den(8*s^3-96*s^2+384*s-512)
	+ mibox(1,0,1,0) * ep^4 * num(-273*s^2-834*s*t+2184*s-561*t^2+3336*t-4368)*den(16*s^3-192*s^2+768*s-1024)
	+ mibox(1,0,1,0) * ep^5 * num(561*s^2+1698*s*t-4488*s+1137*t^2-6792*t+8976)*den(32*s^3-384*s^2+1536*s-2048)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-6*s*t+8*s-6*t^2+24*t-16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+16*s^3-s^2*t^2+30*s^2*t-88*s^2+14*s*t^2-108*s*t+192*s-10*t^2+80*t-128)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(25*s^4+50*s^3*t-418*s^3+25*s^2*t^2-780*s^2*t+2526*s^2-362*s*t^2+3516*s*t-6544*s+814*t^2-4784*t+6112)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * num(-379*s^4-758*s^3*t+6550*s^3-379*s^2*t^2+12228*s^2*t-41514*s^2+5678*s*t^2-59172*s*t+114736*s-15082*t^2+89552*t-116896)*den(72*s^3-864*s^2+3456*s-4608)
	+ mibox(1,0,0,0) * ep^3 * num(4945*s^4+9890*s^3*t-87058*s^3+4945*s^2*t^2-163068*s^2*t+565278*s^2-76010*s*t^2+815244*s*t-1609360*s+215038*t^2-1284848*t+1698784)*den(432*s^3-5184*s^2+20736*s-27648)
	+ mibox(1,0,0,0) * ep^4 * num(-61171*s^4-122342*s^3*t+1088086*s^3-61171*s^2*t^2+2044500*s^2*t-7154970*s^2+956414*s*t^2-10393188*s*t+20671408*s-2786170*t^2+16690640*t-22183840)*den(2592*s^3-31104*s^2+124416*s-165888)
	+ mibox(1,0,0,0) * ep^5 * num(742105*s^4+1484210*s^3*t-13274818*s^3+742105*s^2*t^2-24998460*s^2*t+87873486*s^2-11723642*s*t^2+128194476*s*t-255775504*s+34652014*t^2-207791984*t+276735712)*den(15552*s^3-186624*s^2+746496*s-995328)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,1,1) =
	+ mibox(1,1,0,1) * ep^0 * 1
	+ mibox(1,1,0,1) * ep^6 * warnep
	;

Fill box(-1,1,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2+s*t-4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^2 * num(4*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^3 * num(8*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^4 * num(16*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^5 * num(32*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^4+2*s^3*t-8*s^3+s^2*t^2-6*s^2*t+16*s^2+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^3 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^4 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^5 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^3+s^2*t+12*s^2+5*s*t^2-16*s*t+t^3-4*t^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^3 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^4 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^5 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(3*s^3+3*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(4*s^3+4*s^2*t-16*s^2+16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(8*s^3+8*s^2*t-32*s^2+32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(16*s^3+16*s^2*t-64*s^2+64*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(32*s^3+32*s^2*t-128*s^2+128*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * num(3)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,2,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-1)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	;

Fill box(0,1,1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * num(3)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^3 * num(-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-s^2-s*t+4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s)*den(s+t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s+t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s+t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,2,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(s^3+s^2*t+4*s^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^3+2*s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^3+4*s^2*t+16*s^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^3+8*s^2*t+32*s^2-32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^3+2*s^2*t+8*s^2+4*s*t^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t-4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^3-3*s^2*t+4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3-2*s^2*t+16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(-4*s^3-4*s^2*t+32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(-8*s^3-8*s^2*t+64*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(-16*s^3-16*s^2*t+128*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(s^3+s^2*t+4*s^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^3 * num(2*s^3+2*s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^4 * num(4*s^3+4*s^2*t+16*s^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^5 * num(8*s^3+8*s^2*t+32*s^2-32*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,3,1,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * num(5*s+5*t-38)*den(36*s^2+72*s*t-288*s+36*t^2-288*t+576)
	+ mibox(1,0,0,0) * ep^3 * num(-5)*den(54*s+54*t-216)
	+ mibox(1,0,0,0) * ep^4 * num(5)*den(81*s+81*t-324)
	+ mibox(1,0,0,0) * ep^5 * num(-10)*den(243*s+243*t-972)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,2,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * num(-1)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,2,1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t+2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * num(4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(-7)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^3 * num(12)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(-24)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(48)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,3,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t-2)*den(2*s+2*t-8)
	+ mibox(1,1,0,1) * ep^2 * 1*den(2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * num(-3)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^3 * num(3)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,2,2) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * num(-1)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(0,1,1,3) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * num(5*s+5*t-38)*den(36*s^2+72*s*t-288*s+36*t^2-288*t+576)
	+ mibox(1,0,0,0) * ep^3 * num(-5)*den(54*s+54*t-216)
	+ mibox(1,0,0,0) * ep^4 * num(5)*den(81*s+81*t-324)
	+ mibox(1,0,0,0) * ep^5 * num(-10)*den(243*s+243*t-972)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,3,1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * num(-2*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(3*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,2,1) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+5*s+3*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^3 * num(3*s-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s+12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(12*s-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,2,1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(4*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^2-2*s*t+6*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s+4*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,3,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*t)*den(2*s+2*t)
	+ mibox(1,1,0,1) * ep^2 * num(s^2+s*t-4*s)*den(2*s+2*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-s^2-s*t+4*t)*den(2*s^2+4*s*t-8*s+2*t^2-8*t)
	+ mibox(0,1,0,1) * ep^2 * num(-s)*den(s+t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,2,2) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^2-2*s*t+5*s+3*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^3 * num(3*s-6)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s+12)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(12*s-24)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-1,1,1,3) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * num(-2*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * num(3*s^2+3*s*t-2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^3 * num(-3*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(3*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(-6*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,3,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-3*s^2+2*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^4-6*s^3*t+10*s^3-3*s^2*t^2+22*s^2*t+8*s^2+12*s*t^2)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s^2+12*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,2,2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^3-s^2*t+4*s^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,2,1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3-8*s^2-2*s*t^2+4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-10*s^3+s^2*t^2-10*s^2*t+24*s^2-8*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+11*s^2-6*s*t-t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-6*s^2+4*s*t+2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+4*s^2-2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,3,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2-4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-8*s^2*t-8*s^2-6*s*t^2+24*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(s^4+2*s^3*t-8*s^3+s^2*t^2-8*s^2*t+16*s^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-s^3-s^2*t-4*s^2+12*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-s^3-s^2*t+4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+4*s^2-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(s^3+s^2*t-2*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-4*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-s^3-s^2*t+4*s^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(-2,1,1,3) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * num(2*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * num(-3*s^2+2*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * num(-3*s^4-6*s^3*t+10*s^3-3*s^2*t^2+22*s^2*t+8*s^2+12*s*t^2)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^2-12*s)*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^4 * num(-3*s^2+12*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^5 * num(6*s^2-24*s)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,1,1) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s-4)
	+ mibox(1,1,1,1) * ep^1 * num(2)*den(s-4)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(-s-t)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^3 * num(-12)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(24)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(-48)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,1,1) =
	+ mibox(1,1,1,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^2 * num(6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^3 * num(-6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^4 * num(6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^5 * num(-6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(2*s-12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s+12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^4 * num(2*s-12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^5 * num(-2*s+12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,2,1) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s-4)
	+ mibox(1,1,1,1) * ep^1 * num(2)*den(s-4)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(-s-t)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^3 * num(-12)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^4 * num(24)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^5 * num(-48)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,1,2) =
	+ mibox(1,1,1,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^2 * num(6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^3 * num(-6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^4 * num(6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^5 * num(-6)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * num(2*s-12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^3 * num(-2*s+12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^4 * num(2*s-12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^5 * num(-2*s+12)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(3,1,1,1) =
	+ mibox(1,1,1,1) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^1 * num(3*s^2+3*s*t-12*s+4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^2 * num(2)*den(s^2-8*s+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(s^3+s^2*t-8*s^2-8*s*t+4*s+4*t)*den(2*s^4+2*s^3*t-24*s^3-16*s^2*t+96*s^2+32*s*t-128*s)
	+ mibox(1,1,0,1) * ep^2 * num(s^3+s^2*t-8*s^2-8*s*t+8*s+8*t)*den(2*s^4+2*s^3*t-24*s^3-16*s^2*t+96*s^2+32*s*t-128*s)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-10*s^2-8*s*t+24*s+4*t)*den(2*s^5+4*s^4*t-32*s^4+2*s^3*t^2-48*s^3*t+192*s^3-16*s^2*t^2+192*s^2*t-512*s^2+32*s*t^2-256*s*t+512*s)
	+ mibox(0,1,0,1) * ep^1 * num(-s+8)*den(2*s^3+2*s^2*t-24*s^2-16*s*t+96*s+32*t-128)
	+ mibox(0,1,0,1) * ep^2 * num(-s^3-s^2*t+8*s^2+8*s*t-16*s-8*t)*den(s^5+2*s^4*t-16*s^4+s^3*t^2-24*s^3*t+96*s^3-8*s^2*t^2+96*s^2*t-256*s^2+16*s*t^2-128*s*t+256*s)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^1 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^2 * num(12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^3 * num(-12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^4 * num(12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^5 * num(-12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-8*s+2)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3+24*s^2-64*s-8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^3-36*s^2+92*s+24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^3+72*s^2-188*s-24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s^3-144*s^2+380*s+24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,2,1,1) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * num(-4)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * num(16)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3-2*s^2*t-30*s^2+34*s*t+264*s-176*t-448)*den(9*s^5+18*s^4*t-180*s^4+9*s^3*t^2-288*s^3*t+1440*s^3-108*s^2*t^2+1728*s^2*t-5760*s^2+432*s*t^2-4608*s*t+11520*s-576*t^2+4608*t-9216)
	+ mibox(1,0,0,0) * ep^3 * num(-5*s-5*t+344)*den(27*s^3+54*s^2*t-324*s^2+27*s*t^2-432*s*t+1296*s-108*t^2+864*t-1728)
	+ mibox(1,0,0,0) * ep^4 * num(10*s+10*t-1984)*den(81*s^3+162*s^2*t-972*s^2+81*s*t^2-1296*s*t+3888*s-324*t^2+2592*t-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-20*s-20*t+11744)*den(243*s^3+486*s^2*t-2916*s^2+243*s*t^2-3888*s*t+11664*s-972*t^2+7776*t-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,2,1) =
	+ mibox(1,1,1,1) * ep^0 * num(2*s^2+4*s*t-8*s-4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^1 * num(6*s^2+10*s*t-24*s-8*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^2 * num(4)*den(s^2-8*s+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^2-2*s*t-4*s-4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,0,1) * ep^2 * num(-8*s-8*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-2*s^2-2*s*t+8*s-4*t)*den(s^5+2*s^4*t-16*s^4+s^3*t^2-24*s^3*t+96*s^3-8*s^2*t^2+96*s^2*t-256*s^2+16*s*t^2-128*s*t+256*s)
	+ mibox(0,1,0,1) * ep^1 * num(4)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(0,1,0,1) * ep^2 * num(16*t)*den(s^5+2*s^4*t-16*s^4+s^3*t^2-24*s^3*t+96*s^3-8*s^2*t^2+96*s^2*t-256*s^2+16*s*t^2-128*s*t+256*s)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4*s+8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^1 * num(4*s-8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^2 * num(12*s-24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^3 * num(-12*s+24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^4 * num(12*s-24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^5 * num(-12*s+24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s-8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^1 * num(-6*s-4)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(16*s^2-72*s+16)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^3 * num(-28*s^2+128*s-48)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^4 * num(52*s^2-224*s+48)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^5 * num(-100*s^2+416*s-48)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(2,1,1,2) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * num(-4)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * num(16)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3-2*s^2*t-30*s^2+34*s*t+264*s-176*t-448)*den(9*s^5+18*s^4*t-180*s^4+9*s^3*t^2-288*s^3*t+1440*s^3-108*s^2*t^2+1728*s^2*t-5760*s^2+432*s*t^2-4608*s*t+11520*s-576*t^2+4608*t-9216)
	+ mibox(1,0,0,0) * ep^3 * num(-5*s-5*t+344)*den(27*s^3+54*s^2*t-324*s^2+27*s*t^2-432*s*t+1296*s-108*t^2+864*t-1728)
	+ mibox(1,0,0,0) * ep^4 * num(10*s+10*t-1984)*den(81*s^3+162*s^2*t-972*s^2+81*s*t^2-1296*s*t+3888*s-324*t^2+2592*t-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-20*s-20*t+11744)*den(243*s^3+486*s^2*t-2916*s^2+243*s*t^2-3888*s*t+11664*s-972*t^2+7776*t-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,3,1,1) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(3*s+t-12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(2*s^4+2*s^3*t-32*s^3-24*s^2*t+192*s^2+96*s*t-512*s-128*t+512)
	+ mibox(1,0,1,0) * ep^2 * num(-47*s-15*t+188)*den(4*s^5+8*s^4*t-80*s^4+4*s^3*t^2-128*s^3*t+640*s^3-48*s^2*t^2+768*s^2*t-2560*s^2+192*s*t^2-2048*s*t+5120*s-256*t^2+2048*t-4096)
	+ mibox(1,0,1,0) * ep^3 * num(15)*den(8*s^4+8*s^3*t-128*s^3-96*s^2*t+768*s^2+384*s*t-2048*s-512*t+2048)
	+ mibox(1,0,1,0) * ep^4 * num(-15)*den(16*s^4+16*s^3*t-256*s^3-192*s^2*t+1536*s^2+768*s*t-4096*s-1024*t+4096)
	+ mibox(1,0,1,0) * ep^5 * num(15)*den(32*s^4+32*s^3*t-512*s^3-384*s^2*t+3072*s^2+1536*s*t-8192*s-2048*t+8192)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-3*s-t+12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+30*s^2+14*s*t-222*s-46*t+472)*den(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1920*s^3-144*s^2*t^2+2304*s^2*t-7680*s^2+576*s*t^2-6144*s*t+15360*s-768*t^2+6144*t-12288)
	+ mibox(1,0,0,0) * ep^2 * num(7*s^3+7*s^2*t-210*s^2-110*s*t+1794*s+490*t-4264)*den(72*s^5+144*s^4*t-1440*s^4+72*s^3*t^2-2304*s^3*t+11520*s^3-864*s^2*t^2+13824*s^2*t-46080*s^2+3456*s*t^2-36864*s*t+92160*s-4608*t^2+36864*t-73728)
	+ mibox(1,0,0,0) * ep^3 * num(-s^2+170*s-1150)*den(432*s^4+432*s^3*t-6912*s^3-5184*s^2*t+41472*s^2+20736*s*t-110592*s-27648*t+110592)
	+ mibox(1,0,0,0) * ep^4 * num(-77*s^2+130*s+2170)*den(2592*s^4+2592*s^3*t-41472*s^3-31104*s^2*t+248832*s^2+124416*s*t-663552*s-165888*t+663552)
	+ mibox(1,0,0,0) * ep^5 * num(551*s^2-2950*s-1390)*den(15552*s^4+15552*s^3*t-248832*s^3-186624*s^2*t+1492992*s^2+746496*s*t-3981312*s-995328*t+3981312)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,2,1) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * num(-4)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * num(16)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3-2*s^2*t-30*s^2+34*s*t+264*s-176*t-448)*den(9*s^5+18*s^4*t-180*s^4+9*s^3*t^2-288*s^3*t+1440*s^3-108*s^2*t^2+1728*s^2*t-5760*s^2+432*s*t^2-4608*s*t+11520*s-576*t^2+4608*t-9216)
	+ mibox(1,0,0,0) * ep^3 * num(-5*s-5*t+344)*den(27*s^3+54*s^2*t-324*s^2+27*s*t^2-432*s*t+1296*s-108*t^2+864*t-1728)
	+ mibox(1,0,0,0) * ep^4 * num(10*s+10*t-1984)*den(81*s^3+162*s^2*t-972*s^2+81*s*t^2-1296*s*t+3888*s-324*t^2+2592*t-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-20*s-20*t+11744)*den(243*s^3+486*s^2*t-2916*s^2+243*s*t^2-3888*s*t+11664*s-972*t^2+7776*t-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,2,1,2) =
	+ mibox(1,1,1,1) * ep^0 * num(2*s-2*t-8)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,1,1) * ep^1 * num(6*s-4*t-24)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,1,1) * ep^2 * num(4)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-4)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(8)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^2 * num(-28)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^3 * num(12)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^4 * num(-12)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^5 * num(12)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-8)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(8*s-36)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^2 * num(-18*s+88)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^3 * num(28*s-120)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^4 * num(-52*s+216)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^5 * num(100*s-408)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,3,1) =
	+ mibox(1,1,1,1) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^1 * num(3*s^2+3*s*t-12*s+4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^2 * num(2)*den(s^2-8*s+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(s^3+s^2*t-8*s^2-8*s*t+4*s+4*t)*den(2*s^4+2*s^3*t-24*s^3-16*s^2*t+96*s^2+32*s*t-128*s)
	+ mibox(1,1,0,1) * ep^2 * num(s^3+s^2*t-8*s^2-8*s*t+8*s+8*t)*den(2*s^4+2*s^3*t-24*s^3-16*s^2*t+96*s^2+32*s*t-128*s)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-10*s^2-8*s*t+24*s+4*t)*den(2*s^5+4*s^4*t-32*s^4+2*s^3*t^2-48*s^3*t+192*s^3-16*s^2*t^2+192*s^2*t-512*s^2+32*s*t^2-256*s*t+512*s)
	+ mibox(0,1,0,1) * ep^1 * num(-s+8)*den(2*s^3+2*s^2*t-24*s^2-16*s*t+96*s+32*t-128)
	+ mibox(0,1,0,1) * ep^2 * num(-s^3-s^2*t+8*s^2+8*s*t-16*s-8*t)*den(s^5+2*s^4*t-16*s^4+s^3*t^2-24*s^3*t+96*s^3-8*s^2*t^2+96*s^2*t-256*s^2+16*s*t^2-128*s*t+256*s)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^1 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^2 * num(12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^3 * num(-12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^4 * num(12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^5 * num(-12)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-8*s+2)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3+24*s^2-64*s-8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^3 * num(3*s^3-36*s^2+92*s+24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^4 * num(-6*s^3+72*s^2-188*s-24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^5 * num(12*s^3-144*s^2+380*s+24)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,2,2) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * num(-4)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^6 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * num(-4)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * num(16)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * num(-2*s^3-2*s^2*t-30*s^2+34*s*t+264*s-176*t-448)*den(9*s^5+18*s^4*t-180*s^4+9*s^3*t^2-288*s^3*t+1440*s^3-108*s^2*t^2+1728*s^2*t-5760*s^2+432*s*t^2-4608*s*t+11520*s-576*t^2+4608*t-9216)
	+ mibox(1,0,0,0) * ep^3 * num(-5*s-5*t+344)*den(27*s^3+54*s^2*t-324*s^2+27*s*t^2-432*s*t+1296*s-108*t^2+864*t-1728)
	+ mibox(1,0,0,0) * ep^4 * num(10*s+10*t-1984)*den(81*s^3+162*s^2*t-972*s^2+81*s*t^2-1296*s*t+3888*s-324*t^2+2592*t-5184)
	+ mibox(1,0,0,0) * ep^5 * num(-20*s-20*t+11744)*den(243*s^3+486*s^2*t-2916*s^2+243*s*t^2-3888*s*t+11664*s-972*t^2+7776*t-15552)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

Fill box(1,1,1,3) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^2 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^6 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(3*s+t-12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(2*s^4+2*s^3*t-32*s^3-24*s^2*t+192*s^2+96*s*t-512*s-128*t+512)
	+ mibox(1,0,1,0) * ep^2 * num(-47*s-15*t+188)*den(4*s^5+8*s^4*t-80*s^4+4*s^3*t^2-128*s^3*t+640*s^3-48*s^2*t^2+768*s^2*t-2560*s^2+192*s*t^2-2048*s*t+5120*s-256*t^2+2048*t-4096)
	+ mibox(1,0,1,0) * ep^3 * num(15)*den(8*s^4+8*s^3*t-128*s^3-96*s^2*t+768*s^2+384*s*t-2048*s-512*t+2048)
	+ mibox(1,0,1,0) * ep^4 * num(-15)*den(16*s^4+16*s^3*t-256*s^3-192*s^2*t+1536*s^2+768*s*t-4096*s-1024*t+4096)
	+ mibox(1,0,1,0) * ep^5 * num(15)*den(32*s^4+32*s^3*t-512*s^3-384*s^2*t+3072*s^2+1536*s*t-8192*s-2048*t+8192)
	+ mibox(1,0,1,0) * ep^6 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-3*s-t+12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+30*s^2+14*s*t-222*s-46*t+472)*den(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1920*s^3-144*s^2*t^2+2304*s^2*t-7680*s^2+576*s*t^2-6144*s*t+15360*s-768*t^2+6144*t-12288)
	+ mibox(1,0,0,0) * ep^2 * num(7*s^3+7*s^2*t-210*s^2-110*s*t+1794*s+490*t-4264)*den(72*s^5+144*s^4*t-1440*s^4+72*s^3*t^2-2304*s^3*t+11520*s^3-864*s^2*t^2+13824*s^2*t-46080*s^2+3456*s*t^2-36864*s*t+92160*s-4608*t^2+36864*t-73728)
	+ mibox(1,0,0,0) * ep^3 * num(-s^2+170*s-1150)*den(432*s^4+432*s^3*t-6912*s^3-5184*s^2*t+41472*s^2+20736*s*t-110592*s-27648*t+110592)
	+ mibox(1,0,0,0) * ep^4 * num(-77*s^2+130*s+2170)*den(2592*s^4+2592*s^3*t-41472*s^3-31104*s^2*t+248832*s^2+124416*s*t-663552*s-165888*t+663552)
	+ mibox(1,0,0,0) * ep^5 * num(551*s^2-2950*s-1390)*den(15552*s^4+15552*s^3*t-248832*s^3-186624*s^2*t+1492992*s^2+746496*s*t-3981312*s-995328*t+3981312)
	+ mibox(1,0,0,0) * ep^6 * warnep
	;

