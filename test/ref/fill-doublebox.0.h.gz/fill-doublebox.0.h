Fill db1(2,2,2,1,1,1,1,-1,-1) =
	+ midb1(0,0,0,0,1,1,1,0,0) * numep(+num(12*s)+num(-30*s-54*t)*ep+num(-294*s-3*t)*ep^2+num(648*s+804*t)*ep^3+num(2046*s+75*t)*ep^4+num(-3930*s-3270*t)*ep^5+num(-3636*s-576*t)*ep^6+num(4752*s+3672*t)*ep^7+num(2592*s+1296*t)*ep^8)*den(-1)*denep(2*ep+1)*den(t)^2/ep^2*denep(ep+1)^2*den(s)^4
	+ midb1(0,0,1,1,1,1,0,0,0) * numep(+num(-15*s-6*t)+num(-18*s)*ep+num(186*s+63*t)*ep^2+num(237*s+24*t)*ep^3+num(-429*s-69*t)*ep^4+num(-675*s-216*t)*ep^5+num(-270*s-108*t)*ep^6)*den(-1)*den(t)/ep*denep(ep+1)^2*den(s)^4
	+ midb1(0,0,1,1,1,1,1,0,0) * numep(+num(30)+num(126)*ep+num(6)*ep^2+num(-456)*ep^3+num(-510)*ep^4+num(-180)*ep^5)*den(t)*den(s)^2*denep(ep+1)^2
	+ midb1(0,1,1,0,0,1,0,0,0) * numep(+num(-60*s-84*t)+num(-24*s-240*t)*ep+num(921*s+1359*t)*ep^2+num(387*s+3141*t)*ep^3+num(-4026*s-6024*t)*ep^4+num(-1857*s-9855*t)*ep^5+num(5505*s+4791*t)*ep^6+num(2934*s+9054*t)*ep^7+num(-1188*s+5238*t)*ep^8+num(-648*s+1620*t)*ep^9)*den(t)*denep(ep+2)*denep(2*ep+1)/ep^2*denep(ep+1)^2*den(s)^5
	+ midb1(0,1,1,0,1,1,1,0,0) * numep(+num(-30*s^2-48*s*t-18*t^2)*ep+num(-132*s^2-186*s*t-54*t^2)*ep^2+num(-120*s^2-78*s*t+42*t^2)*ep^3+num(30*s^2+168*s*t+138*t^2)*ep^4+num(36*s^2+72*s*t+36*t^2)*ep^5)*den(t)*denep(ep+1)^2*den(s)^4
	+ midb1(1,0,0,1,0,1,0,0,0) * numep(+num(36*s-12*t)+num(72*s-36*t)*ep+num(-519*s+45*t)*ep^2+num(-1077*s+462*t)*ep^3+num(1872*s+1104*t)*ep^4+num(4407*s-1404*t)*ep^5+num(-705*s-5415*t)*ep^6+num(-4842*s+1278*t)*ep^7+num(-3132*s+5238*t)*ep^8+num(-648*s+1620*t)*ep^9)*den(t)*denep(ep+2)*denep(2*ep+1)/ep^2*denep(ep+1)^2*den(s)^5
	+ midb1(1,0,0,1,1,1,1,0,0) * numep(+num(18*s^2+36*s*t+18*t^2)*ep+num(108*s^2+216*s*t+108*t^2)*ep^2+num(204*s^2+408*s*t+204*t^2)*ep^3+num(138*s^2+276*s*t+138*t^2)*ep^4+num(36*s^2+72*s*t+36*t^2)*ep^5)*den(t)*denep(ep+1)^2*den(s)^4
	+ midb1(1,1,0,0,0,1,1,0,0) * numep(+num(-21*s+6*t)+num(-48*s+48*t)*ep+num(237*s-39*t)*ep^2+num(612*s-585*t)*ep^3+num(-288*s-330*t)*ep^4+num(-1572*s+1299*t)*ep^5+num(-1296*s+1755*t)*ep^6+num(-432*s+702*t)*ep^7)*den(t)/ep*denep(2*ep+1)*denep(ep+1)^2*den(s)^4
	+ midb1(1,1,0,0,1,1,1,0,0) * numep(+num(-42)+num(-138)*ep+num(84)*ep^2+num(480)*ep^3+num(408)*ep^4+num(144)*ep^5)*den(t)*den(s)^2*denep(ep+1)^2
	+ midb1(1,1,1,1,0,0,0,0,0) * numep(+num(8*s)+num(14*s+8*t)*ep+num(-64*s-12*t)*ep^2+num(-80*s-40*t)*ep^3+num(112*s+48*t)*ep^4+num(128*s+32*t)*ep^5)/ep*denep(ep+1)*den(s)^5
	+ midb1(1,1,1,1,1,1,1,0,0) * numep(+num(-2*s+t)+num(-13*s)*ep+num(-27*s-6*t)*ep^2+num(-18*s-4*t)*ep^3)*den(s)^2
	+ midb1(1,1,1,1,1,1,2,0,0) * numep(+num(-2*t)+num(-5*t)*ep+num(-3*t)*ep^2)*den(s)
	;

Fill db1(1,1,1,1,1,1,1,-2,-2) =
	+ midb1(0,0,0,0,1,1,1,0,0) * numep(+num(36*s^4+126*s^3*t+162*s^2*t^2+90*s*t^3+18*t^4)+num(-324*s^4-1131*s^3*t-1409*s^2*t^2-721*s*t^3-103*t^4)*ep+num(1053*s^4+3663*s^3*t+4463*s^2*t^2+2157*s*t^3+264*t^4)*ep^2+num(-1458*s^4-5049*s^3*t-6045*s^2*t^2-2799*s*t^3-313*t^4)*ep^3+num(729*s^4+2511*s^3*t+2961*s^2*t^2+1321*s*t^3+134*t^4)*ep^4)*den(2)*denep(2*ep-1)*den(t)^2*den(s+t)^2/ep^3
	+ midb1(0,0,1,1,1,1,0,0,0) * numep(+num(72*s^2+88*s*t+26*t^2)+num(-468*s^2-592*s*t-143*t^2)*ep+num(486*s^2+798*s*t+122*t^2)*ep^2+num(2349*s^2+2106*s*t+495*t^2)*ep^3+num(-5832*s^2-5886*s*t-896*t^2)*ep^4+num(3645*s^2+3726*s*t+324*t^2)*ep^5)*den(-4)*den(t)*denep(2*ep-1)*denep(2*ep+1)*denep(3*ep-2)/ep^2
	+ midb1(0,0,1,1,1,1,1,0,0) * numep(+num(-72*s^3-52*s^2*t-8*s*t^2)+num(468*s^3+340*s^2*t+28*s*t^2)*ep+num(-486*s^3-393*s^2*t+8*s*t^2-4*t^3)*ep^2+num(-2349*s^3-1458*s^2*t-112*s*t^2+8*t^3)*ep^3+num(5832*s^3+3699*s^2*t+96*s*t^2+16*t^3)*ep^4+num(-3645*s^3-2268*s^2*t-32*t^3)*ep^5)*den(-2)*den(t)/ep*denep(2*ep-1)*denep(2*ep+1)*denep(3*ep-2)*denep(3*ep-1)
	+ midb1(0,1,1,0,0,1,0,0,0) * numep(+num(108*s^4+138*s^3*t-114*s^2*t^2-210*s*t^3-66*t^4)+num(-612*s^4-997*s^3*t+173*s^2*t^2+889*s*t^3+283*t^4)*ep+num(63*s^4+1491*s^3*t+3291*s^2*t^2+2385*s*t^3+482*t^4)*ep^2+num(4572*s^4+4497*s^3*t-8477*s^2*t^2-12077*s*t^3-3435*t^4)*ep^3+num(-5589*s^4-16791*s^3*t-16911*s^2*t^2-5797*s*t^3-96*t^4)*ep^4+num(-6966*s^4+19684*s^3*t+78144*s^2*t^2+69228*s*t^3+17366*t^4)*ep^5+num(14580*s^4-9506*s^3*t-87268*s^2*t^2-87730*s*t^3-24260*t^4)*ep^6+num(-5832*s^4+1556*s^3*t+29680*s^2*t^2+31428*s*t^3+9072*t^4)*ep^7)*den(-4)*den(t)*den(s)*denep(2*ep-3)*denep(2*ep-1)*den(s+t)^2*denep(2*ep+1)^2/ep^3
	+ midb1(0,1,1,0,1,1,1,0,0) * numep(+num(-36*s^5-154*s^4*t-260*s^3*t^2-216*s^2*t^3-92*s*t^4-10*t^5)+num(324*s^5+1383*s^4*t+2310*s^3*t^2+1872*s^2*t^3+744*s*t^4+87*t^5)*ep+num(-1053*s^5-4482*s^4*t-7424*s^3*t^2-5906*s^2*t^3-2237*s*t^4-270*t^5)*ep^2+num(1458*s^5+6183*s^4*t+10164*s^3*t^2+7962*s^2*t^3+2910*s*t^4+351*t^5)*ep^3+num(-729*s^5-3078*s^4*t-5022*s^3*t^2-3880*s^2*t^3-1377*s*t^4-162*t^5)*ep^4)*den(2)*den(t)*denep(3*ep-2)*denep(3*ep-1)*den(s+t)^2*denep(2*ep-1)^2
	+ midb1(1,0,0,1,0,1,0,0,0) * numep(+num(108*s^4+138*s^3*t-114*s^2*t^2-210*s*t^3-66*t^4)+num(-612*s^4-997*s^3*t+173*s^2*t^2+889*s*t^3+283*t^4)*ep+num(63*s^4+1491*s^3*t+3291*s^2*t^2+2385*s*t^3+482*t^4)*ep^2+num(4572*s^4+4497*s^3*t-8477*s^2*t^2-12077*s*t^3-3435*t^4)*ep^3+num(-5589*s^4-16791*s^3*t-16911*s^2*t^2-5797*s*t^3-96*t^4)*ep^4+num(-6966*s^4+19684*s^3*t+78144*s^2*t^2+69228*s*t^3+17366*t^4)*ep^5+num(14580*s^4-9506*s^3*t-87268*s^2*t^2-87730*s*t^3-24260*t^4)*ep^6+num(-5832*s^4+1556*s^3*t+29680*s^2*t^2+31428*s*t^3+9072*t^4)*ep^7)*den(-4)*den(t)*den(s)*denep(2*ep-3)*denep(2*ep-1)*den(s+t)^2*denep(2*ep+1)^2/ep^3
	+ midb1(1,0,0,1,1,1,1,0,0) * numep(+num(-36*s^5-154*s^4*t-260*s^3*t^2-216*s^2*t^3-92*s*t^4-10*t^5)+num(324*s^5+1383*s^4*t+2310*s^3*t^2+1872*s^2*t^3+744*s*t^4+87*t^5)*ep+num(-1053*s^5-4482*s^4*t-7424*s^3*t^2-5906*s^2*t^3-2237*s*t^4-270*t^5)*ep^2+num(1458*s^5+6183*s^4*t+10164*s^3*t^2+7962*s^2*t^3+2910*s*t^4+351*t^5)*ep^3+num(-729*s^5-3078*s^4*t-5022*s^3*t^2-3880*s^2*t^3-1377*s*t^4-162*t^5)*ep^4)*den(2)*den(t)*denep(3*ep-2)*denep(3*ep-1)*den(s+t)^2*denep(2*ep-1)^2
	+ midb1(1,1,0,0,0,1,1,0,0) * numep(+num(52*s*t+26*t^2)+num(-72*s^2-172*s*t-29*t^2)*ep+num(360*s^2-553*s*t-411*t^2)*ep^2+num(198*s^2+1597*s*t+314*t^2)*ep^3+num(-2916*s^2+3054*s*t+2588*t^2)*ep^4+num(1782*s^2-6966*s*t-2265*t^2)*ep^5+num(5832*s^2-3753*s*t-3979*t^2)*ep^6+num(-5832*s^2+8181*s*t+3564*t^2)*ep^7)*den(-4)*den(t)*denep(ep+1)*denep(2*ep-1)*denep(3*ep-2)/ep^2*denep(2*ep+1)^2
	+ midb1(1,1,0,0,1,1,1,0,0) * numep(+num(-8*s^2*t-4*s*t^2)+num(36*s^3+82*s^2*t+18*s*t^2)*ep+num(-324*s^3-321*s^2*t-18*s*t^2-2*t^3)*ep^2+num(1053*s^3+594*s^2*t-16*s*t^2+6*t^3)*ep^3+num(-1458*s^3-513*s^2*t+24*s*t^2)*ep^4+num(729*s^3+162*s^2*t-8*t^3)*ep^5)*den(-1)*den(t)/ep*denep(ep+1)*denep(2*ep-1)*denep(3*ep-2)*denep(3*ep-1)
	+ midb1(1,1,1,1,0,0,0,0,0) * numep(+num(36*s^3+18*s^2*t+6*t^3)+num(-76*s^3-47*s^2*t+12*s*t^2+8*t^3)*ep+num(-288*s^3-106*s^2*t+28*s*t^2-8*t^3)*ep^2+num(696*s^3+412*s^2*t)*ep^3+num(-320*s^3-216*s^2*t-16*s*t^2)*ep^4)*den(2)*denep(2*ep-3)*denep(2*ep+1)*den(s)^2/ep^2
	+ midb1(1,1,1,1,1,1,1,0,0) * numep(+num(-6*s^4-3*s^3*t)+num(9*s^4-2*s^2*t^2)*ep+num(54*s^4+45*s^3*t+6*s^2*t^2)*ep^2+num(-81*s^4-54*s^3*t-4*s^2*t^2)*ep^3)*den(-4)/ep*denep(2*ep-1)^2
	+ midb1(1,1,1,1,1,1,2,0,0) * numep(+num(6*s^4*t+3*s^3*t^2)+num(-21*s^4*t-10*s^3*t^2)*ep+num(-s^3*t^2)*ep^2+num(27*s^4*t+12*s^3*t^2)*ep^3)*den(4)/ep*denep(2*ep+1)*denep(2*ep-1)^2
	;

Fill db1(1,1,1,1,1,1,1,-1,-2) =
	+ midb1(0,0,0,0,1,1,1,0,0) * numep(+num(18*s^2+36*s*t+18*t^2)+num(-135*s^2-282*s*t-139*t^2)*ep+num(324*s^2+702*s*t+358*t^2)*ep^2+num(-243*s^2-540*s*t-285*t^2)*ep^3)*den(-2)*den(s+t)*den(t)^2/ep^3
	+ midb1(0,0,1,1,1,1,0,0,0) * numep(+num(18*s^2+13*s*t)+num(-63*s^2-64*s*t)*ep+num(-108*s^2-33*s*t-8*t^2)*ep^2+num(405*s^2+324*s*t-16*t^2)*ep^3)*den(-4)*den(t)*den(s)*denep(2*ep+1)/ep^2
	+ midb1(0,0,1,1,1,1,1,0,0) * numep(+num(-18*s^2-4*s*t)+num(63*s^2+28*s*t-4*t^2)*ep+num(108*s^2+6*s*t)*ep^2+num(-405*s^2-162*s*t+16*t^2)*ep^3)*den(-2)*den(t)/ep*denep(2*ep+1)*denep(3*ep-1)
	+ midb1(0,1,1,0,0,1,0,0,0) * numep(+num(18*s^3-4*s^2*t-22*s*t^2)+num(-99*s^3-30*s^2*t+97*s*t^2+36*t^3)*ep+num(-18*s^3+274*s^2*t+238*s*t^2-58*t^3)*ep^2+num(801*s^3-206*s^2*t-1317*s*t^2-370*t^3)*ep^3+num(-702*s^3-1902*s^2*t-716*s*t^2+524*t^3)*ep^4+num(-1620*s^3+4454*s^2*t+7318*s*t^2+1356*t^3)*ep^5+num(1944*s^3-2820*s^2*t-6612*s*t^2-1944*t^3)*ep^6)*den(4)*den(t)*den(s+t)*denep(2*ep-1)*den(s)^2*denep(2*ep+1)^2/ep^3
	+ midb1(0,1,1,0,1,1,1,0,0) * numep(+num(-9*s^3-25*s^2*t-23*s*t^2-5*t^3)+num(54*s^3+156*s^2*t+150*s*t^2+42*t^3)*ep+num(-81*s^3-243*s^2*t-247*s*t^2-81*t^3)*ep^2)*den(2)*den(t)*den(s+t)*denep(2*ep-1)*denep(3*ep-1)
	+ midb1(1,0,0,1,0,1,0,0,0) * numep(+num(18*s^3-4*s^2*t-22*s*t^2)+num(-99*s^3-30*s^2*t+97*s*t^2+36*t^3)*ep+num(-18*s^3+274*s^2*t+238*s*t^2-58*t^3)*ep^2+num(801*s^3-206*s^2*t-1317*s*t^2-370*t^3)*ep^3+num(-702*s^3-1902*s^2*t-716*s*t^2+524*t^3)*ep^4+num(-1620*s^3+4454*s^2*t+7318*s*t^2+1356*t^3)*ep^5+num(1944*s^3-2820*s^2*t-6612*s*t^2-1944*t^3)*ep^6)*den(4)*den(t)*den(s+t)*denep(2*ep-1)*den(s)^2*denep(2*ep+1)^2/ep^3
	+ midb1(1,0,0,1,1,1,1,0,0) * numep(+num(-9*s^3-25*s^2*t-23*s*t^2-5*t^3)+num(54*s^3+156*s^2*t+150*s*t^2+42*t^3)*ep+num(-81*s^3-243*s^2*t-247*s*t^2-81*t^3)*ep^2)*den(2)*den(t)*den(s+t)*denep(2*ep-1)*denep(3*ep-1)
	+ midb1(1,1,0,0,0,1,1,0,0) * numep(+num(13*s*t)+num(-18*s^2+5*s*t)*ep+num(36*s^2-184*s*t-12*t^2)*ep^2+num(198*s^2-218*s*t-18*t^2)*ep^3+num(-216*s^2+771*s*t+108*t^2)*ep^4+num(-648*s^2+1053*s*t+162*t^2)*ep^5)*den(-4)*den(t)*den(s)*denep(ep+1)/ep^2*denep(2*ep+1)^2
	+ midb1(1,1,0,0,1,1,1,0,0) * numep(+num(-2*s*t)+num(9*s^2+10*s*t-2*t^2)*ep+num(-54*s^2-12*s*t+2*t^2)*ep^2+num(81*s^2+4*t^2)*ep^3)*den(-1)*den(t)/ep*denep(ep+1)*denep(3*ep-1)
	+ midb1(1,1,1,1,0,0,0,0,0) * numep(+num(6*s^2-2*t^2)+num(-11*s^2-8*s*t)*ep+num(-54*s^2+8*t^2)*ep^2+num(104*s^2+48*s*t)*ep^3)*den(-2)*denep(2*ep+1)*den(s)^2/ep^2
	+ midb1(1,1,1,1,1,1,1,0,0) * numep(+num(-3*s^3)+num(27*s^3+12*s^2*t)*ep^2)*den(4)/ep*denep(2*ep-1)
	+ midb1(1,1,1,1,1,1,2,0,0) * numep(+num(3*s^3*t)+num(-6*s^3*t-2*s^2*t^2)*ep+num(-9*s^3*t-2*s^2*t^2)*ep^2)*den(-4)/ep*denep(2*ep-1)*denep(2*ep+1)
	;

Fill db1(1,1,1,1,1,1,1,-2,-1) =
	+ midb1(0,0,0,0,1,1,1,0,0) * numep(+num(18*s^2+36*s*t+18*t^2)+num(-135*s^2-282*s*t-139*t^2)*ep+num(324*s^2+702*s*t+358*t^2)*ep^2+num(-243*s^2-540*s*t-285*t^2)*ep^3)*den(-2)*den(s+t)*den(t)^2/ep^3
	+ midb1(0,0,1,1,1,1,0,0,0) * numep(+num(18*s+13*t)+num(-63*s-64*t)*ep+num(-108*s-33*t)*ep^2+num(405*s+324*t)*ep^3)*den(-4)*den(t)*denep(2*ep+1)/ep^2
	+ midb1(0,0,1,1,1,1,1,0,0) * numep(+num(-18*s^2-4*s*t)+num(63*s^2+28*s*t-4*t^2)*ep+num(108*s^2+6*s*t)*ep^2+num(-405*s^2-162*s*t+16*t^2)*ep^3)*den(-2)*den(t)/ep*denep(2*ep+1)*denep(3*ep-1)
	+ midb1(0,1,1,0,0,1,0,0,0) * numep(+num(18*s^3-4*s^2*t-22*s*t^2)+num(-99*s^3-30*s^2*t+97*s*t^2+36*t^3)*ep+num(-18*s^3+274*s^2*t+238*s*t^2-58*t^3)*ep^2+num(801*s^3-206*s^2*t-1317*s*t^2-370*t^3)*ep^3+num(-702*s^3-1902*s^2*t-716*s*t^2+524*t^3)*ep^4+num(-1620*s^3+4454*s^2*t+7318*s*t^2+1356*t^3)*ep^5+num(1944*s^3-2820*s^2*t-6612*s*t^2-1944*t^3)*ep^6)*den(4)*den(t)*den(s+t)*denep(2*ep-1)*den(s)^2*denep(2*ep+1)^2/ep^3
	+ midb1(0,1,1,0,1,1,1,0,0) * numep(+num(-9*s^3-25*s^2*t-23*s*t^2-5*t^3)+num(54*s^3+156*s^2*t+150*s*t^2+42*t^3)*ep+num(-81*s^3-243*s^2*t-247*s*t^2-81*t^3)*ep^2)*den(2)*den(t)*den(s+t)*denep(2*ep-1)*denep(3*ep-1)
	+ midb1(1,0,0,1,0,1,0,0,0) * numep(+num(18*s^3-4*s^2*t-22*s*t^2)+num(-99*s^3-30*s^2*t+97*s*t^2+36*t^3)*ep+num(-18*s^3+274*s^2*t+238*s*t^2-58*t^3)*ep^2+num(801*s^3-206*s^2*t-1317*s*t^2-370*t^3)*ep^3+num(-702*s^3-1902*s^2*t-716*s*t^2+524*t^3)*ep^4+num(-1620*s^3+4454*s^2*t+7318*s*t^2+1356*t^3)*ep^5+num(1944*s^3-2820*s^2*t-6612*s*t^2-1944*t^3)*ep^6)*den(4)*den(t)*den(s+t)*denep(2*ep-1)*den(s)^2*denep(2*ep+1)^2/ep^3
	+ midb1(1,0,0,1,1,1,1,0,0) * numep(+num(-9*s^3-25*s^2*t-23*s*t^2-5*t^3)+num(54*s^3+156*s^2*t+150*s*t^2+42*t^3)*ep+num(-81*s^3-243*s^2*t-247*s*t^2-81*t^3)*ep^2)*den(2)*den(t)*den(s+t)*denep(2*ep-1)*denep(3*ep-1)
	+ midb1(1,1,0,0,0,1,1,0,0) * numep(+num(13*s*t)+num(-18*s^2+5*s*t)*ep+num(36*s^2-184*s*t-20*t^2)*ep^2+num(198*s^2-218*s*t-58*t^2)*ep^3+num(-216*s^2+771*s*t+44*t^2)*ep^4+num(-648*s^2+1053*s*t+130*t^2)*ep^5)*den(-4)*den(t)*den(s)*denep(ep+1)/ep^2*denep(2*ep+1)^2
	+ midb1(1,1,0,0,1,1,1,0,0) * numep(+num(-2*s*t)+num(9*s^2+10*s*t-2*t^2)*ep+num(-54*s^2-12*s*t+2*t^2)*ep^2+num(81*s^2+4*t^2)*ep^3)*den(-1)*den(t)/ep*denep(ep+1)*denep(3*ep-1)
	+ midb1(1,1,1,1,0,0,0,0,0) * numep(+num(6*s^2-2*t^2)+num(-11*s^2-8*s*t)*ep+num(-54*s^2+8*t^2)*ep^2+num(104*s^2+48*s*t)*ep^3)*den(-2)*denep(2*ep+1)*den(s)^2/ep^2
	+ midb1(1,1,1,1,1,1,1,0,0) * numep(+num(-3*s^3)+num(27*s^3+12*s^2*t)*ep^2)*den(4)/ep*denep(2*ep-1)
	+ midb1(1,1,1,1,1,1,2,0,0) * numep(+num(3*s^3*t)+num(-6*s^3*t-2*s^2*t^2)*ep+num(-9*s^3*t-2*s^2*t^2)*ep^2)*den(-4)/ep*denep(2*ep-1)*denep(2*ep+1)
	;

Fill db1(1,1,1,1,1,1,1,-1,-1) =
	+ midb1(0,0,0,0,1,1,1,0,0) * numep(+num(18*s+18*t)+num(-117*s-117*t)*ep+num(243*s+243*t)*ep^2+num(-162*s-162*t)*ep^3)*den(-2)*den(s)*den(t)^2/ep^3
	+ midb1(0,0,1,1,1,1,0,0,0) * numep(+num(18*s+13*t)+num(-45*s-39*t)*ep+num(-117*s-52*t)*ep^2+num(270*s+156*t)*ep^3)*den(-4)*den(t)*den(s)*denep(2*ep+1)/ep^2
	+ midb1(0,0,1,1,1,1,1,0,0) * numep(+num(-18*s-4*t)+num(-9*s)*ep+num(90*s+16*t)*ep^2)*den(2)*den(t)/ep*denep(2*ep+1)
	+ midb1(0,1,1,0,0,1,0,0,0) * numep(+num(18*s-22*t)+num(-45*s+11*t)*ep+num(-153*s+317*t)*ep^2+num(342*s-126*t)*ep^3+num(324*s-1530*t)*ep^4+num(-648*s+1620*t)*ep^5)*den(-4)*den(t)*den(s)^2*denep(2*ep+1)^2/ep^3
	+ midb1(0,1,1,0,1,1,1,0,0) * numep(+num(-9*s^2-16*s*t-9*t^2))*den(2)*den(t)*den(s)
	+ midb1(1,0,0,1,0,1,0,0,0) * numep(+num(18*s-22*t)+num(-45*s+11*t)*ep+num(-153*s+317*t)*ep^2+num(342*s-126*t)*ep^3+num(324*s-1530*t)*ep^4+num(-648*s+1620*t)*ep^5)*den(-4)*den(t)*den(s)^2*denep(2*ep+1)^2/ep^3
	+ midb1(1,0,0,1,1,1,1,0,0) * numep(+num(-9*s^2-16*s*t-9*t^2))*den(2)*den(t)*den(s)
	+ midb1(1,1,0,0,0,1,1,0,0) * numep(+num(13*t)+num(-18*s+18*t)*ep+num(18*s-152*t)*ep^2+num(180*s-294*t)*ep^3+num(-72*s+445*t)*ep^4+num(-432*s+798*t)*ep^5)*den(-4)*den(t)*den(s)*denep(ep+1)/ep^2*denep(2*ep+1)^2
	+ midb1(1,1,0,0,1,1,1,0,0) * numep(+num(-2*t)+num(9*s+2*t)*ep+num(-18*s+4*t)*ep^2)*den(t)/ep*denep(ep+1)
	+ midb1(1,1,1,1,0,0,0,0,0) * numep(+num(3*s+t)+num(-2*s-2*t)*ep+num(-24*s-4*t)*ep^2+num(32*s+8*t)*ep^3)*den(-1)*denep(2*ep+1)*den(s)^2/ep^2
	+ midb1(1,1,1,1,1,1,1,0,0) * numep(+num(-3*s^2)+num(-9*s^2-2*s*t)*ep)*den(-4)/ep
	+ midb1(1,1,1,1,1,1,2,0,0) * numep(+num(3*s^2*t)+num(3*s^2*t)*ep)*den(4)/ep*denep(2*ep+1)
	;

Fill db1(1,1,1,1,1,1,2,0,0) =
	+ midb1(1,1,1,1,1,1,2,0,0) * 1/1
	;

Fill db1(1,1,1,1,1,1,1,0,0) =
	+ midb1(1,1,1,1,1,1,1,0,0) * 1/1
	;

Fill db1(1,1,1,1,0,0,0,0,0) =
	+ midb1(1,1,1,1,0,0,0,0,0) * 1/1
	;

Fill db1(1,1,0,0,1,1,1,0,0) =
	+ midb1(1,1,0,0,1,1,1,0,0) * 1/1
	;

Fill db1(1,1,0,0,0,1,1,0,0) =
	+ midb1(1,1,0,0,0,1,1,0,0) * 1/1
	;

Fill db1(1,0,0,1,1,1,1,0,0) =
	+ midb1(1,0,0,1,1,1,1,0,0) * 1/1
	;

Fill db1(1,0,0,1,0,1,0,0,0) =
	+ midb1(1,0,0,1,0,1,0,0,0) * 1/1
	;

Fill db1(0,1,1,0,1,1,1,0,0) =
	+ midb1(0,1,1,0,1,1,1,0,0) * 1/1
	;

Fill db1(0,1,1,0,0,1,0,0,0) =
	+ midb1(0,1,1,0,0,1,0,0,0) * 1/1
	;

Fill db1(0,0,1,1,1,1,1,0,0) =
	+ midb1(0,0,1,1,1,1,1,0,0) * 1/1
	;

Fill db1(0,0,1,1,1,1,0,0,0) =
	+ midb1(0,0,1,1,1,1,0,0,0) * 1/1
	;

Fill db1(0,0,0,0,1,1,1,0,0) =
	+ midb1(0,0,0,0,1,1,1,0,0) * 1/1
	;

