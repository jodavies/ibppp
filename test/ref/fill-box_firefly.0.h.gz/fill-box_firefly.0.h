Fill box(0,1,0,0) =
	0
	;

Fill box(0,1,0,-1) =
	0
	;

Fill box(0,1,-1,0) =
	0
	;

Fill box(-1,1,0,0) =
	0
	;

Fill box(0,1,0,-2) =
	0
	;

Fill box(0,1,-1,-1) =
	0
	;

Fill box(0,1,-2,0) =
	0
	;

Fill box(-1,1,0,-1) =
	0
	;

Fill box(-1,1,-1,0) =
	0
	;

Fill box(-2,1,0,0) =
	0
	;

Fill box(0,2,0,0) =
	0
	;

Fill box(0,2,0,-1) =
	0
	;

Fill box(0,2,-1,0) =
	0
	;

Fill box(-1,2,0,0) =
	0
	;

Fill box(0,2,0,-2) =
	0
	;

Fill box(0,2,-1,-1) =
	0
	;

Fill box(0,2,-2,0) =
	0
	;

Fill box(-1,2,0,-1) =
	0
	;

Fill box(-1,2,-1,0) =
	0
	;

Fill box(-2,2,0,0) =
	0
	;

Fill box(0,3,0,0) =
	0
	;

Fill box(0,3,0,-1) =
	0
	;

Fill box(0,3,-1,0) =
	0
	;

Fill box(-1,3,0,0) =
	0
	;

Fill box(0,3,0,-2) =
	0
	;

Fill box(0,3,-1,-1) =
	0
	;

Fill box(0,3,-2,0) =
	0
	;

Fill box(-1,3,0,-1) =
	0
	;

Fill box(-1,3,-1,0) =
	0
	;

Fill box(-2,3,0,0) =
	0
	;

Fill box(0,0,0,1) =
	0
	;

Fill box(0,0,-1,1) =
	0
	;

Fill box(0,-1,0,1) =
	0
	;

Fill box(-1,0,0,1) =
	0
	;

Fill box(0,0,-2,1) =
	0
	;

Fill box(0,-1,-1,1) =
	0
	;

Fill box(0,-2,0,1) =
	0
	;

Fill box(-1,0,-1,1) =
	0
	;

Fill box(-1,-1,0,1) =
	0
	;

Fill box(-2,0,0,1) =
	0
	;

Fill box(0,0,0,2) =
	0
	;

Fill box(0,0,-1,2) =
	0
	;

Fill box(0,-1,0,2) =
	0
	;

Fill box(-1,0,0,2) =
	0
	;

Fill box(0,0,-2,2) =
	0
	;

Fill box(0,-1,-1,2) =
	0
	;

Fill box(0,-2,0,2) =
	0
	;

Fill box(-1,0,-1,2) =
	0
	;

Fill box(-1,-1,0,2) =
	0
	;

Fill box(-2,0,0,2) =
	0
	;

Fill box(0,0,0,3) =
	0
	;

Fill box(0,0,-1,3) =
	0
	;

Fill box(0,-1,0,3) =
	0
	;

Fill box(-1,0,0,3) =
	0
	;

Fill box(0,0,-2,3) =
	0
	;

Fill box(0,-1,-1,3) =
	0
	;

Fill box(0,-2,0,3) =
	0
	;

Fill box(-1,0,-1,3) =
	0
	;

Fill box(-1,-1,0,3) =
	0
	;

Fill box(-2,0,0,3) =
	0
	;

Fill box(1,0,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(2))/1
	;

Fill box(1,0,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(s))/1
	;

Fill box(1,-1,0,0) =
	+ mibox(1,0,0,0) * numep(+num(2))/1
	;

Fill box(1,0,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)*den(-1)*denep(ep-2)
	;

Fill box(1,0,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(5*s)+num(-2*s)*ep)*den(-1)*denep(ep-2)
	;

Fill box(1,0,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(2*s^2+2*s)+num(-s^2)*ep)*den(-1)*denep(ep-2)
	;

Fill box(1,-1,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t+6)+num(-4)*ep)*den(-1)*denep(ep-2)
	;

Fill box(1,-1,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(5*s)+num(-2*s)*ep)*den(-1)*denep(ep-2)
	;

Fill box(1,-2,0,0) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)*den(-1)*denep(ep-2)
	;

Fill box(2,0,0,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(2,0,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(3)+num(-2)*ep)/1
	;

Fill box(2,0,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(s+1)+num(-s)*ep)/1
	;

Fill box(2,-1,0,0) =
	+ mibox(1,0,0,0) * numep(+num(3)+num(-2)*ep)/1
	;

Fill box(2,0,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)/1
	;

Fill box(2,0,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(4*s+2)+num(-2*s)*ep)/1
	;

Fill box(2,0,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(s^2+4*s)+num(-s^2)*ep)/1
	;

Fill box(2,-1,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t+6)+num(-4)*ep)/1
	;

Fill box(2,-1,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(4*s+2)+num(-2*s)*ep)/1
	;

Fill box(2,-2,0,0) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)/1
	;

Fill box(3,0,0,0) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(2)
	;

Fill box(3,0,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)/1
	;

Fill box(3,0,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s-2)*ep+num(s)*ep^2)*den(2)
	;

Fill box(3,-1,0,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)/1
	;

Fill box(3,0,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(6)+num(-7)*ep+num(2)*ep^2)/1
	;

Fill box(3,0,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(3*s+6)+num(-5*s-4)*ep+num(2*s)*ep^2)*den(2)
	;

Fill box(3,0,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(6*s+2)+num(-s^2-6*s)*ep+num(s^2)*ep^2)*den(2)
	;

Fill box(3,-1,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t+8)+num(-s-t-10)*ep+num(4)*ep^2)*den(2)
	;

Fill box(3,-1,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(3*s+6)+num(-5*s-4)*ep+num(2*s)*ep^2)*den(2)
	;

Fill box(3,-2,0,0) =
	+ mibox(1,0,0,0) * numep(+num(6)+num(-7)*ep+num(2)*ep^2)/1
	;

Fill box(1,1,0,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-1)*denep(2*ep-1)
	;

Fill box(1,1,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(-4)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(1,1,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(s))*den(2)
	;

Fill box(1,1,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*denep(2*ep-3)*denep(2*ep-1)
	;

Fill box(1,1,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+10*s)+num(-4*s)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(1,1,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s)+num(-s^2)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(2,1,0,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(2)
	;

Fill box(1,2,0,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-2)*denep(2*ep+1)
	;

Fill box(2,1,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(s+t-10)*ep+num(4)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,2,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(2,1,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-s-1)*ep+num(s)*ep^2)*den(-1)*denep(2*ep-1)
	;

Fill box(1,2,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(2,1,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,2,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(8*s+8*t-32)*ep+num(8)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(2,1,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(s-t+6)+num(s^2+s*t-10*s-4)*ep+num(4*s)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,2,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+5*s)+num(-2*s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(2,1,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(4*s)+num(-s^2)*ep)*den(2)
	;

Fill box(1,2,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(2*s)+num(-s^2)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(3,1,0,0) =
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^3)*den(-2)*denep(2*ep+1)
	;

Fill box(2,2,0,0) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(1,3,0,0) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(2)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(3,1,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t-4)+num(2)*ep+num(-s-t+6)*ep^2+num(-4)*ep^3)*den(-4)*denep(2*ep+1)
	;

Fill box(2,2,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(1,3,0,-1) =
	+ mibox(1,0,0,0) * numep(+num(-3*s-3*t+6)+num(3*s+3*t-10)*ep+num(4)*ep^2)*den(4)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(3,1,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(-s+2)+num(-2)*ep+num(s)*ep^2)*den(4)
	;

Fill box(2,2,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(-s+1)+num(-1)*ep+num(s)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(1,3,-1,0) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-4)*denep(2*ep+1)
	;

Fill box(3,1,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-2*s*t+8*s-t^2+8*t-18)+num(-2*s-2*t+12)*ep+num(s^2+2*s*t-10*s+t^2-10*t+30)*ep^2+num(4*s+4*t-32)*ep^3+num(8)*ep^4)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(2,2,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(-3*s^2-6*s*t+28*s-3*t^2+28*t-62)*ep+num(-8*s-8*t+40)*ep^2+num(-8)*ep^3)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(1,3,0,-2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-15*s+3*t^2-15*t+15)+num(-3*s^2-6*s*t+21*s-3*t^2+21*t-31)*ep+num(-6*s-6*t+20)*ep^2+num(-4)*ep^3)*den(-1)*denep(2*ep-1)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(3,1,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-6*s-2*t+12)+num(2*t-20)*ep+num(-s^2-s*t+10*s+8)*ep^2+num(-4*s)*ep^3)*den(-4)*denep(2*ep-1)
	;

Fill box(2,2,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-5*s-t+3)+num(2*s+t-5)*ep+num(-s^2-s*t+5*s+2)*ep^2+num(-2*s)*ep^3)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(1,3,-1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-3*s^2-3*s*t+10*s)+num(3*s^2+3*s*t-14*s)*ep+num(4*s)*ep^2)*den(4)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(3,1,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(2)+num(s^2-6*s-2)*ep+num(6*s)*ep^2+num(-s^2)*ep^3)*den(-2)*denep(2*ep-1)
	;

Fill box(2,2,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+4*s)+num(-4*s)*ep+num(s^2)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,3,-2,0) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+2*s)+num(-2*s)*ep+num(s^2)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(0,0,1,0) =
	+ mibox(1,0,0,0) * 1/1
	;

Fill box(0,0,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(2))/1
	;

Fill box(0,-1,1,0) =
	+ mibox(1,0,0,0) * numep(+num(2))/1
	;

Fill box(-1,0,1,0) =
	+ mibox(1,0,0,0) * numep(+num(s))/1
	;

Fill box(0,0,1,-2) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)*den(-1)*denep(ep-2)
	;

Fill box(0,-1,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t+6)+num(-4)*ep)*den(-1)*denep(ep-2)
	;

Fill box(0,-2,1,0) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)*den(-1)*denep(ep-2)
	;

Fill box(-1,0,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(5*s)+num(-2*s)*ep)*den(-1)*denep(ep-2)
	;

Fill box(-1,-1,1,0) =
	+ mibox(1,0,0,0) * numep(+num(5*s)+num(-2*s)*ep)*den(-1)*denep(ep-2)
	;

Fill box(-2,0,1,0) =
	+ mibox(1,0,0,0) * numep(+num(2*s^2+2*s)+num(-s^2)*ep)*den(-1)*denep(ep-2)
	;

Fill box(0,0,2,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(0,0,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(3)+num(-2)*ep)/1
	;

Fill box(0,-1,2,0) =
	+ mibox(1,0,0,0) * numep(+num(3)+num(-2)*ep)/1
	;

Fill box(-1,0,2,0) =
	+ mibox(1,0,0,0) * numep(+num(s+1)+num(-s)*ep)/1
	;

Fill box(0,0,2,-2) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)/1
	;

Fill box(0,-1,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t+6)+num(-4)*ep)/1
	;

Fill box(0,-2,2,0) =
	+ mibox(1,0,0,0) * numep(+num(10)+num(-4)*ep)/1
	;

Fill box(-1,0,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(4*s+2)+num(-2*s)*ep)/1
	;

Fill box(-1,-1,2,0) =
	+ mibox(1,0,0,0) * numep(+num(4*s+2)+num(-2*s)*ep)/1
	;

Fill box(-2,0,2,0) =
	+ mibox(1,0,0,0) * numep(+num(s^2+4*s)+num(-s^2)*ep)/1
	;

Fill box(0,0,3,0) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(2)
	;

Fill box(0,0,3,-1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)/1
	;

Fill box(0,-1,3,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)/1
	;

Fill box(-1,0,3,0) =
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s-2)*ep+num(s)*ep^2)*den(2)
	;

Fill box(0,0,3,-2) =
	+ mibox(1,0,0,0) * numep(+num(6)+num(-7)*ep+num(2)*ep^2)/1
	;

Fill box(0,-1,3,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t+8)+num(-s-t-10)*ep+num(4)*ep^2)*den(2)
	;

Fill box(0,-2,3,0) =
	+ mibox(1,0,0,0) * numep(+num(6)+num(-7)*ep+num(2)*ep^2)/1
	;

Fill box(-1,0,3,-1) =
	+ mibox(1,0,0,0) * numep(+num(3*s+6)+num(-5*s-4)*ep+num(2*s)*ep^2)*den(2)
	;

Fill box(-1,-1,3,0) =
	+ mibox(1,0,0,0) * numep(+num(3*s+6)+num(-5*s-4)*ep+num(2*s)*ep^2)*den(2)
	;

Fill box(-2,0,3,0) =
	+ mibox(1,0,0,0) * numep(+num(6*s+2)+num(-s^2-6*s)*ep+num(s^2)*ep^2)*den(2)
	;

Fill box(1,0,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s+4))*den(2)
	+ mibox(1,0,0,0) * 1/1
	;

Fill box(1,-1,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-s+4))*den(2)
	+ mibox(1,0,0,0) * 1/1
	;

Fill box(1,0,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2-16*s+32)+num(-s^2+8*s-16)*ep)*den(-2)*denep(2*ep-3)
	+ mibox(1,0,0,0) * numep(+num(-2*s+14)+num(s-8)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(1,-1,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(s^2-s*t-8*s+4*t+16)+num(-s^2+8*s-16)*ep)*den(-2)*denep(2*ep-3)
	+ mibox(1,0,0,0) * numep(+num(-s+t+10)+num(s-8)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(1,-2,1,0) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2-16*s+32)+num(-s^2+8*s-16)*ep)*den(-2)*denep(2*ep-3)
	+ mibox(1,0,0,0) * numep(+num(-2*s+14)+num(s-8)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(2,0,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-1)+num(2)*ep)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(s-4)
	;

Fill box(1,0,2,0) =
	+ mibox(1,0,1,0) * numep(+num(-1)+num(2)*ep)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(s-4)
	;

Fill box(2,0,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(1,0,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(2,-1,1,0) =
	+ mibox(1,0,1,0) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(1,-1,2,0) =
	+ mibox(1,0,1,0) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(2,0,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s+8)+num(s-4)*ep)*den(2)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-1)*ep)/1
	;

Fill box(1,0,2,-2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s+8)+num(s-4)*ep)*den(2)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-1)*ep)/1
	;

Fill box(2,-1,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s+t+4)+num(s-4)*ep)*den(2)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-1)*ep)/1
	;

Fill box(1,-1,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s+t+4)+num(s-4)*ep)*den(2)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-1)*ep)/1
	;

Fill box(2,-2,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-2*s+8)+num(s-4)*ep)*den(2)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-1)*ep)/1
	;

Fill box(1,-2,2,0) =
	+ mibox(1,0,1,0) * numep(+num(-2*s+8)+num(s-4)*ep)*den(2)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-1)*ep)/1
	;

Fill box(3,0,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-2)+num(-s+4)*ep+num(2*s)*ep^2)*den(s)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(4)+num(-s^2+8*s-12)*ep+num(s^2-8*s+8)*ep^2)*den(2)*den(s)*den(s-4)^2
	;

Fill box(2,0,2,0) =
	+ mibox(1,0,1,0) * numep(+num(-2*s+4)+num(2*s-8)*ep+num(4*s)*ep^2)*den(s)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s-4)+num(-2*s+12)*ep+num(-8)*ep^2)*den(s)*den(s-4)^2
	;

Fill box(1,0,3,0) =
	+ mibox(1,0,1,0) * numep(+num(-2)+num(-s+4)*ep+num(2*s)*ep^2)*den(s)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(4)+num(-s^2+8*s-12)*ep+num(s^2-8*s+8)*ep^2)*den(2)*den(s)*den(s-4)^2
	;

Fill box(3,0,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s+2)+num(3*s-4)*ep+num(-2*s)*ep^2)*den(2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(s-2)+num(-3*s+6)*ep+num(2*s-4)*ep^2)*den(2)*den(s)*den(s-4)
	;

Fill box(2,0,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(-2)+num(s+4)*ep+num(-2*s)*ep^2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-6)*ep+num(4)*ep^2)*den(s)*den(s-4)
	;

Fill box(1,0,3,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s+2)+num(3*s-4)*ep+num(-2*s)*ep^2)*den(2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(s-2)+num(-3*s+6)*ep+num(2*s-4)*ep^2)*den(2)*den(s)*den(s-4)
	;

Fill box(3,-1,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-s+2)+num(3*s-4)*ep+num(-2*s)*ep^2)*den(2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(s-2)+num(-3*s+6)*ep+num(2*s-4)*ep^2)*den(2)*den(s)*den(s-4)
	;

Fill box(2,-1,2,0) =
	+ mibox(1,0,1,0) * numep(+num(-2)+num(s+4)*ep+num(-2*s)*ep^2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(2)+num(-6)*ep+num(4)*ep^2)*den(s)*den(s-4)
	;

Fill box(1,-1,3,0) =
	+ mibox(1,0,1,0) * numep(+num(-s+2)+num(3*s-4)*ep+num(-2*s)*ep^2)*den(2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(s-2)+num(-3*s+6)*ep+num(2*s-4)*ep^2)*den(2)*den(s)*den(s-4)
	;

Fill box(3,0,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s-2)+num(-3*s+2)*ep+num(s)*ep^2)*den(2)*den(s)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)*den(s)
	;

Fill box(2,0,2,-2) =
	+ mibox(1,0,1,0) * numep(+num(s+2)+num(-2*s-2)*ep+num(s)*ep^2)*den(s)
	+ mibox(1,0,0,0) * numep(+num(-2)+num(4)*ep+num(-2)*ep^2)*den(s)
	;

Fill box(1,0,3,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s-2)+num(-3*s+2)*ep+num(s)*ep^2)*den(2)*den(s)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)*den(s)
	;

Fill box(3,-1,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(s^2-s*t-4*s+2*t)+num(-2*s^2+s*t+10*s-8)*ep+num(s^2-4*s)*ep^2)*den(2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-4*s-2*t)+num(-s^2-s*t+2*s+2*t+8)*ep+num(2*s-8)*ep^2)*den(2)*den(s)*den(s-4)
	;

Fill box(2,-1,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(s^2-4*s-2*t)+num(-s^2+s*t+2*s+8)*ep+num(s^2-4*s)*ep^2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(2*t)+num(2*s-2*t-8)*ep+num(-2*s+8)*ep^2)*den(s)*den(s-4)
	;

Fill box(1,-1,3,-1) =
	+ mibox(1,0,1,0) * numep(+num(s^2-s*t-4*s+2*t)+num(-2*s^2+s*t+10*s-8)*ep+num(s^2-4*s)*ep^2)*den(2)*den(s)*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-4*s-2*t)+num(-s^2-s*t+2*s+2*t+8)*ep+num(2*s-8)*ep^2)*den(2)*den(s)*den(s-4)
	;

Fill box(3,-2,1,0) =
	+ mibox(1,0,1,0) * numep(+num(2*s-2)+num(-3*s+2)*ep+num(s)*ep^2)*den(2)*den(s)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)*den(s)
	;

Fill box(2,-2,2,0) =
	+ mibox(1,0,1,0) * numep(+num(s+2)+num(-2*s-2)*ep+num(s)*ep^2)*den(s)
	+ mibox(1,0,0,0) * numep(+num(-2)+num(4)*ep+num(-2)*ep^2)*den(s)
	;

Fill box(1,-2,3,0) =
	+ mibox(1,0,1,0) * numep(+num(2*s-2)+num(-3*s+2)*ep+num(s)*ep^2)*den(2)*den(s)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-2)*ep+num(1)*ep^2)*den(s)
	;

Fill box(0,1,1,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-1)*denep(2*ep-1)
	;

Fill box(0,1,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(-4)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,1,1,0) =
	+ mibox(1,0,0,0) * numep(+num(s))*den(2)
	;

Fill box(0,1,1,-2) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*denep(2*ep-3)*denep(2*ep-1)
	;

Fill box(-1,1,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+10*s)+num(-4*s)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(-2,1,1,0) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s)+num(-s^2)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(0,2,1,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-2)*denep(2*ep+1)
	;

Fill box(0,1,2,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(2)
	;

Fill box(0,2,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(0,1,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(s+t-10)*ep+num(4)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,2,1,0) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,1,2,0) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-s-1)*ep+num(s)*ep^2)*den(-1)*denep(2*ep-1)
	;

Fill box(0,2,1,-2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(8*s+8*t-32)*ep+num(8)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(0,1,2,-2) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,2,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+5*s)+num(-2*s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,1,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(s-t+6)+num(s^2+s*t-10*s-4)*ep+num(4*s)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(-2,2,1,0) =
	+ mibox(1,0,0,0) * numep(+num(2*s)+num(-s^2)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(-2,1,2,0) =
	+ mibox(1,0,0,0) * numep(+num(4*s)+num(-s^2)*ep)*den(2)
	;

Fill box(0,3,1,0) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(2)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(0,2,2,0) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(0,1,3,0) =
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^3)*den(-2)*denep(2*ep+1)
	;

Fill box(0,3,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-3*s-3*t+6)+num(3*s+3*t-10)*ep+num(4)*ep^2)*den(4)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(0,2,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(0,1,3,-1) =
	+ mibox(1,0,0,0) * numep(+num(s+t-4)+num(2)*ep+num(-s-t+6)*ep^2+num(-4)*ep^3)*den(-4)*denep(2*ep+1)
	;

Fill box(-1,3,1,0) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-4)*denep(2*ep+1)
	;

Fill box(-1,2,2,0) =
	+ mibox(1,0,0,0) * numep(+num(-s+1)+num(-1)*ep+num(s)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(-1,1,3,0) =
	+ mibox(1,0,0,0) * numep(+num(-s+2)+num(-2)*ep+num(s)*ep^2)*den(4)
	;

Fill box(0,3,1,-2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-15*s+3*t^2-15*t+15)+num(-3*s^2-6*s*t+21*s-3*t^2+21*t-31)*ep+num(-6*s-6*t+20)*ep^2+num(-4)*ep^3)*den(-1)*denep(2*ep-1)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(0,2,2,-2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(-3*s^2-6*s*t+28*s-3*t^2+28*t-62)*ep+num(-8*s-8*t+40)*ep^2+num(-8)*ep^3)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(0,1,3,-2) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-2*s*t+8*s-t^2+8*t-18)+num(-2*s-2*t+12)*ep+num(s^2+2*s*t-10*s+t^2-10*t+30)*ep^2+num(4*s+4*t-32)*ep^3+num(8)*ep^4)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-1,3,1,-1) =
	+ mibox(1,0,0,0) * numep(+num(-3*s^2-3*s*t+10*s)+num(3*s^2+3*s*t-14*s)*ep+num(4*s)*ep^2)*den(4)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-1,2,2,-1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-5*s-t+3)+num(2*s+t-5)*ep+num(-s^2-s*t+5*s+2)*ep^2+num(-2*s)*ep^3)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-1,1,3,-1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-6*s-2*t+12)+num(2*t-20)*ep+num(-s^2-s*t+10*s+8)*ep^2+num(-4*s)*ep^3)*den(-4)*denep(2*ep-1)
	;

Fill box(-2,3,1,0) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+2*s)+num(-2*s)*ep+num(s^2)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-2,2,2,0) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+4*s)+num(-4*s)*ep+num(s^2)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(-2,1,3,0) =
	+ mibox(1,0,0,0) * numep(+num(2)+num(s^2-6*s-2)*ep+num(6*s)*ep^2+num(-s^2)*ep^3)*den(-2)*denep(2*ep-1)
	;

Fill box(1,1,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-1)+num(2)*ep)*den(-1)/ep*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-1)/ep*den(s-4)
	;

Fill box(1,1,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(s+t-4)+num(-s+4)*ep)*den(-1)/ep*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(-s-t+4)+num(s+t-4)*ep)/ep*den(s-4)*denep(2*ep-1)
	;

Fill box(1,1,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)+num(3*s^2+2*s*t-24*s-8*t+48)*ep+num(-s^2+8*s-16)*ep^2)*den(2)/ep*den(s-4)*denep(ep-1)
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-8*s+t^2-8*t+16)+num(-s+4)*ep+num(2*s-8)*ep^2)/ep*den(s-4)*denep(2*ep-1)
	;

Fill box(2,1,1,0) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-4)*ep)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s+6)*ep+num(s-8)*ep^2)*den(-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,2,1,0) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-4)*ep)*den(-1)*denep(ep+1)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s+6)*ep+num(s-8)*ep^2)*denep(ep+1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,1,2,0) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-4)*ep)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s+6)*ep+num(s-8)*ep^2)*den(-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(2,1,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s-t+4)+num(3*s+2*t-12)*ep+num(-2*s+8)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-2*s-2*t+8)+num(s^2+s*t-8*s-6*t+16)*ep+num(-s^2-s*t+14*s+8*t-40)*ep^2+num(-4*s+16)*ep^3)*den(2)/ep*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,2,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s-2*t+4)+num(3*s+4*t-12)*ep+num(-2*s+8)*ep^2)/ep*denep(ep+1)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-s-2*t+4)+num(s^2+s*t-8*s-6*t+16)*ep+num(-s^2-s*t+11*s+8*t-28)*ep^2+num(-2*s+8)*ep^3)*den(-1)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,1,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s-t+4)+num(3*s+2*t-12)*ep+num(-2*s+8)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-2*s-2*t+8)+num(s^2+s*t-8*s-6*t+16)*ep+num(-s^2-s*t+14*s+8*t-40)*ep^2+num(-4*s+16)*ep^3)*den(2)/ep*denep(2*ep+1)*den(s-4)^2
	;

Fill box(2,1,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-3*s^2-2*s*t+24*s+8*t-48)*ep+num(s^2-8*s+16)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*ep+num(s^3+2*s^2*t-18*s^2+s*t^2-26*s*t+96*s-8*t^2+72*t-160)*ep^2+num(4*s^2+4*s*t-32*s-16*t+64)*ep^3)*den(-1)/ep*denep(2*ep-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,2,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)+num(-3*s^2-4*s*t+24*s+16*t-48)*ep+num(s^2-8*s+16)*ep^2)/ep*denep(ep+1)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)+num(-3*s^3-6*s^2*t+34*s^2-3*s*t^2+52*s*t-128*s+18*t^2-112*t+160)*ep+num(3*s^3+6*s^2*t-44*s^2+3*s*t^2-68*s*t+208*s-24*t^2+176*t-320)*ep^2+num(8*s^2+8*s*t-64*s-32*t+128)*ep^3)/ep*denep(ep+1)*denep(2*ep-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,1,2,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-3*s^2-2*s*t+24*s+8*t-48)*ep+num(s^2-8*s+16)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*ep+num(s^3+2*s^2*t-18*s^2+s*t^2-26*s*t+96*s-8*t^2+72*t-160)*ep^2+num(4*s^2+4*s*t-32*s-16*t+64)*ep^3)*den(-1)/ep*denep(2*ep-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(3,1,1,0) =
	+ mibox(1,0,1,0) * numep(+num(-s-2)+num(-s)*ep+num(4*s+8)*ep^2+num(4*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s+8)+num(s^3-12*s^2+44*s-8)*ep+num(-32)*ep^2+num(-s^3+12*s^2-48*s+32)*ep^3)*den(-4)*den(s)*denep(ep+1)*den(s-4)^3
	;

Fill box(2,2,1,0) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12)+num(s^2-14*s+60)*ep+num(2*s-24)*ep^2+num(-s^2+12*s-48)*ep^3)*den(2)*denep(ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(2,1,2,0) =
	+ mibox(1,0,1,0) * numep(+num(-4*s+4)+num(-2*s)*ep+num(16*s-16)*ep^2+num(8*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s-4)+num(-s^2+8*s+4)*ep+num(s^2-12*s+16)*ep^2+num(-16)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	;

Fill box(1,3,1,0) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*denep(ep+1)*denep(ep+2)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12)+num(s^2-14*s+60)*ep+num(2*s-24)*ep^2+num(-s^2+12*s-48)*ep^3)*den(-2)*denep(ep+1)*denep(ep+2)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,2,2,0) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12)+num(s^2-14*s+60)*ep+num(2*s-24)*ep^2+num(-s^2+12*s-48)*ep^3)*den(2)*denep(ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,1,3,0) =
	+ mibox(1,0,1,0) * numep(+num(-s-2)+num(-s)*ep+num(4*s+8)*ep^2+num(4*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s+8)+num(s^3-12*s^2+44*s-8)*ep+num(-32)*ep^2+num(-s^3+12*s^2-48*s+32)*ep^3)*den(-4)*den(s)*denep(ep+1)*den(s-4)^3
	;

Fill box(3,1,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s^2-s*t+4*s-2*t)+num(2*s^2+s*t-6*s+4*t-8)*ep+num(s^2+2*s*t-8*s+16)*ep^2+num(-2*s^2+8*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-4*s^2-4*s*t+16*s-8*t)+num(-s^4-s^3*t+14*s^3+12*s^2*t-68*s^2-44*s*t+120*s+8*t-32)*ep+num(-4*s^3+48*s^2-136*s+32*t+32)*ep^2+num(s^4+s^3*t-14*s^3-12*s^2*t+72*s^2+48*s*t-160*s-32*t+128)*ep^3+num(4*s^3-48*s^2+160*s-128)*ep^4)*den(4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(2,2,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(2*s+4*t-8)+num(-6*s-8*t+24)*ep+num(4*s-16)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-6*s-12*t+24)+num(-s^3-s^2*t+15*s^2+14*s*t-76*s-60*t+128)*ep+num(-4*s^2-2*s*t+50*s+24*t-136)*ep^2+num(s^3+s^2*t-13*s^2-12*s*t+56*s+48*t-80)*ep^3+num(2*s^2-24*s+64)*ep^4)*den(-1)*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(2,1,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-4*s*t+8*s+4*t)+num(6*s^2+6*s*t-28*s-8*t+16)*ep+num(-2*s^2+4*s*t+16*s-32)*ep^2+num(-4*s^2+16*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-2*s^2-4*s*t+8*s+4*t)+num(s^3+s^2*t-8*s^2-8*s*t+12*s-4*t+16)*ep+num(-s^3-s^2*t+14*s^2+12*s*t-36*s-16*t-16)*ep^2+num(-4*s^2+32*s+16*t-64)*ep^3+num(-16*s+64)*ep^4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(1,3,1,-1) =
	+ mibox(1,0,1,0) * numep(+num(2*s+6*t-8)+num(-6*s-12*t+24)*ep+num(4*s-16)*ep^2)*denep(ep+1)*denep(ep+2)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-12*s-36*t+48)+num(-3*s^3-3*s^2*t+42*s^2+42*s*t-200*s-180*t+320)*ep+num(-8*s^2-6*s*t+100*s+72*t-272)*ep^2+num(3*s^3+3*s^2*t-38*s^2-36*s*t+160*s+144*t-224)*ep^3+num(4*s^2-48*s+128)*ep^4)*den(2)*denep(ep+1)*denep(ep+2)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,2,2,-1) =
	+ mibox(1,0,1,0) * numep(+num(2*s+4*t-8)+num(-6*s-8*t+24)*ep+num(4*s-16)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-6*s-12*t+24)+num(-s^3-s^2*t+15*s^2+14*s*t-76*s-60*t+128)*ep+num(-4*s^2-2*s*t+50*s+24*t-136)*ep^2+num(s^3+s^2*t-13*s^2-12*s*t+56*s+48*t-80)*ep^3+num(2*s^2-24*s+64)*ep^4)*den(-1)*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,1,3,-1) =
	+ mibox(1,0,1,0) * numep(+num(-s^2-s*t+4*s-2*t)+num(2*s^2+s*t-6*s+4*t-8)*ep+num(s^2+2*s*t-8*s+16)*ep^2+num(-2*s^2+8*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-4*s^2-4*s*t+16*s-8*t)+num(-s^4-s^3*t+14*s^3+12*s^2*t-68*s^2-44*s*t+120*s+8*t-32)*ep+num(-4*s^3+48*s^2-136*s+32*t+32)*ep^2+num(s^4+s^3*t-14*s^3-12*s^2*t+72*s^2+48*s*t-160*s-32*t+128)*ep^3+num(4*s^3-48*s^2+160*s-128)*ep^4)*den(4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(3,1,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^3+4*s^2*t-16*s^2+2*s*t^2-12*s*t+32*s+4*t^2-16*t)+num(-5*s^3-6*s^2*t+38*s^2-2*s*t^2+12*s*t-64*s-8*t^2+48*t-32)*ep+num(-6*s^2*t+6*s^2-4*s*t^2+32*s*t-48*s-32*t+96)*ep^2+num(5*s^3+4*s^2*t-44*s^2-16*s*t+112*s-64)*ep^3+num(-2*s^3+16*s^2-32*s)*ep^4)*den(2)*den(s)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s^3+8*s^2*t-32*s^2+4*s*t^2-24*s*t+64*s+8*t^2-32*t)+num(s^5+2*s^4*t-18*s^4+s^3*t^2-30*s^3*t+122*s^3-12*s^2*t^2+160*s^2*t-372*s^2+44*s*t^2-304*s*t+448*s-8*t^2+64*t-64)*ep+num(4*s^4+4*s^3*t-64*s^3-48*s^2*t+328*s^2+104*s*t-576*s-32*t^2+96*t+128)*ep^2+num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-118*s^3+12*s^2*t^2-168*s^2*t+348*s^2-48*s*t^2+384*s*t-448*s+32*t^2-256*t+192)*ep^3+num(-4*s^4-4*s^3*t+64*s^3+48*s^2*t-352*s^2-160*s*t+768*s+128*t-512)*ep^4+num(-8*s^3+80*s^2-256*s+256)*ep^5)*den(-4)*den(s)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(2,2,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)+num(7*s^2+20*s*t-56*s+12*t^2-80*t+112)*ep+num(-7*s^2-8*s*t+56*s+32*t-112)*ep^2+num(2*s^2-16*s+32)*ep^3)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s^2+48*s*t-96*s+36*t^2-192*t+192)+num(3*s^4+6*s^3*t-54*s^3+3*s^2*t^2-96*s^2*t+362*s^2-42*s*t^2+536*s*t-1072*s+180*t^2-992*t+1184)*ep+num(14*s^3+20*s^2*t-208*s^2+6*s*t^2-264*s*t+992*s-72*t^2+736*t-1536)*ep^2+num(-3*s^4-6*s^3*t+48*s^3-3*s^2*t^2+84*s^2*t-270*s^2+36*s*t^2-416*s*t+624*s-144*t^2+704*t-480)*ep^3+num(-8*s^3-8*s^2*t+112*s^2+96*s*t-512*s-256*t+768)*ep^4+num(-8*s^2+64*s-128)*ep^5)*den(2)/ep*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(2,1,2,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)+num(-6*s^3-12*s^2*t+50*s^2-6*s*t^2+60*s*t-112*s+8*t^2-48*t+32)*ep+num(3*s^3-2*s^2*t-30*s^2-4*s*t^2+96*s+32*t-96)*ep^2+num(3*s^3+4*s^2*t-20*s^2-16*s*t+16*s+64)*ep^3+num(-2*s^3+16*s^2-32*s)*ep^4)*den(s)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)+num(-s^4-2*s^3*t+12*s^3-s^2*t^2+20*s^2*t-46*s^2+8*s*t^2-40*s*t+48*s+4*t^2-32*t+32)*ep+num(s^4+2*s^3*t-18*s^3+s^2*t^2-30*s^2*t+92*s^2-12*s*t^2+100*s*t-128*s+16*t^2-48*t-64)*ep^2+num(4*s^3+4*s^2*t-38*s^2-48*s*t+112*s-16*t^2+128*t-96)*ep^3+num(16*s^2+16*s*t-128*s-64*t+256)*ep^4+num(-8*s^2+64*s-128)*ep^5)*den(-1)*den(s)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(1,3,1,-2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-12*s*t+16*s-12*t^2+48*t-32)+num(7*s^2+30*s*t-56*s+24*t^2-120*t+112)*ep+num(-7*s^2-12*s*t+56*s+48*t-112)*ep^2+num(2*s^2-16*s+32)*ep^3)*den(-1)/ep*denep(ep+1)*denep(ep+2)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(6*s^2+36*s*t-48*s+36*t^2-144*t+96)+num(3*s^4+6*s^3*t-48*s^3+3*s^2*t^2-90*s^2*t+289*s^2-42*s*t^2+474*s*t-776*s+180*t^2-840*t+784)*ep+num(9*s^3+15*s^2*t-128*s^2+6*s*t^2-198*s*t+592*s-72*t^2+552*t-896)*ep^2+num(-3*s^4-6*s^3*t+45*s^3-3*s^2*t^2+81*s^2*t-243*s^2+36*s*t^2-384*s*t+552*s-144*t^2+624*t-432)*ep^3+num(-6*s^3-6*s^2*t+80*s^2+72*s*t-352*s-192*t+512)*ep^4+num(-4*s^2+32*s-64)*ep^5)*den(-1)/ep*denep(ep+1)*denep(ep+2)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,2,2,-2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)+num(7*s^2+20*s*t-56*s+12*t^2-80*t+112)*ep+num(-7*s^2-8*s*t+56*s+32*t-112)*ep^2+num(2*s^2-16*s+32)*ep^3)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s^2+48*s*t-96*s+36*t^2-192*t+192)+num(3*s^4+6*s^3*t-54*s^3+3*s^2*t^2-96*s^2*t+362*s^2-42*s*t^2+536*s*t-1072*s+180*t^2-992*t+1184)*ep+num(14*s^3+20*s^2*t-208*s^2+6*s*t^2-264*s*t+992*s-72*t^2+736*t-1536)*ep^2+num(-3*s^4-6*s^3*t+48*s^3-3*s^2*t^2+84*s^2*t-270*s^2+36*s*t^2-416*s*t+624*s-144*t^2+704*t-480)*ep^3+num(-8*s^3-8*s^2*t+112*s^2+96*s*t-512*s-256*t+768)*ep^4+num(-8*s^2+64*s-128)*ep^5)*den(2)/ep*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,1,3,-2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^3+4*s^2*t-16*s^2+2*s*t^2-12*s*t+32*s+4*t^2-16*t)+num(-5*s^3-6*s^2*t+38*s^2-2*s*t^2+12*s*t-64*s-8*t^2+48*t-32)*ep+num(-6*s^2*t+6*s^2-4*s*t^2+32*s*t-48*s-32*t+96)*ep^2+num(5*s^3+4*s^2*t-44*s^2-16*s*t+112*s-64)*ep^3+num(-2*s^3+16*s^2-32*s)*ep^4)*den(2)*den(s)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s^3+8*s^2*t-32*s^2+4*s*t^2-24*s*t+64*s+8*t^2-32*t)+num(s^5+2*s^4*t-18*s^4+s^3*t^2-30*s^3*t+122*s^3-12*s^2*t^2+160*s^2*t-372*s^2+44*s*t^2-304*s*t+448*s-8*t^2+64*t-64)*ep+num(4*s^4+4*s^3*t-64*s^3-48*s^2*t+328*s^2+104*s*t-576*s-32*t^2+96*t+128)*ep^2+num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-118*s^3+12*s^2*t^2-168*s^2*t+348*s^2-48*s*t^2+384*s*t-448*s+32*t^2-256*t+192)*ep^3+num(-4*s^4-4*s^3*t+64*s^3+48*s^2*t-352*s^2-160*s*t+768*s+128*t-512)*ep^4+num(-8*s^3+80*s^2-256*s+256)*ep^5)*den(-4)*den(s)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(1,0,0,1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-1)*denep(2*ep-1)
	;

Fill box(1,0,-1,1) =
	+ mibox(1,0,0,0) * numep(+num(s))*den(2)
	;

Fill box(1,-1,0,1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(-4)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(1,0,-2,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s)+num(-s^2)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(1,-1,-1,1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+10*s)+num(-4*s)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(1,-2,0,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*denep(2*ep-3)*denep(2*ep-1)
	;

Fill box(2,0,0,1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(2)
	;

Fill box(1,0,0,2) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-2)*denep(2*ep+1)
	;

Fill box(2,0,-1,1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-s-1)*ep+num(s)*ep^2)*den(-1)*denep(2*ep-1)
	;

Fill box(1,0,-1,2) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(2,-1,0,1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(s+t-10)*ep+num(4)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,-1,0,2) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(2,0,-2,1) =
	+ mibox(1,0,0,0) * numep(+num(4*s)+num(-s^2)*ep)*den(2)
	;

Fill box(1,0,-2,2) =
	+ mibox(1,0,0,0) * numep(+num(2*s)+num(-s^2)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(2,-1,-1,1) =
	+ mibox(1,0,0,0) * numep(+num(s-t+6)+num(s^2+s*t-10*s-4)*ep+num(4*s)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,-1,-1,2) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+5*s)+num(-2*s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(2,-2,0,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,-2,0,2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(8*s+8*t-32)*ep+num(8)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(3,0,0,1) =
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^3)*den(-2)*denep(2*ep+1)
	;

Fill box(2,0,0,2) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(1,0,0,3) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(2)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(3,0,-1,1) =
	+ mibox(1,0,0,0) * numep(+num(-s+2)+num(-2)*ep+num(s)*ep^2)*den(4)
	;

Fill box(2,0,-1,2) =
	+ mibox(1,0,0,0) * numep(+num(-s+1)+num(-1)*ep+num(s)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(1,0,-1,3) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-4)*denep(2*ep+1)
	;

Fill box(3,-1,0,1) =
	+ mibox(1,0,0,0) * numep(+num(s+t-4)+num(2)*ep+num(-s-t+6)*ep^2+num(-4)*ep^3)*den(-4)*denep(2*ep+1)
	;

Fill box(2,-1,0,2) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(1,-1,0,3) =
	+ mibox(1,0,0,0) * numep(+num(-3*s-3*t+6)+num(3*s+3*t-10)*ep+num(4)*ep^2)*den(4)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(3,0,-2,1) =
	+ mibox(1,0,0,0) * numep(+num(2)+num(s^2-6*s-2)*ep+num(6*s)*ep^2+num(-s^2)*ep^3)*den(-2)*denep(2*ep-1)
	;

Fill box(2,0,-2,2) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+4*s)+num(-4*s)*ep+num(s^2)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(1,0,-2,3) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+2*s)+num(-2*s)*ep+num(s^2)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(3,-1,-1,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-6*s-2*t+12)+num(2*t-20)*ep+num(-s^2-s*t+10*s+8)*ep^2+num(-4*s)*ep^3)*den(-4)*denep(2*ep-1)
	;

Fill box(2,-1,-1,2) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-5*s-t+3)+num(2*s+t-5)*ep+num(-s^2-s*t+5*s+2)*ep^2+num(-2*s)*ep^3)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(1,-1,-1,3) =
	+ mibox(1,0,0,0) * numep(+num(-3*s^2-3*s*t+10*s)+num(3*s^2+3*s*t-14*s)*ep+num(4*s)*ep^2)*den(4)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(3,-2,0,1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-2*s*t+8*s-t^2+8*t-18)+num(-2*s-2*t+12)*ep+num(s^2+2*s*t-10*s+t^2-10*t+30)*ep^2+num(4*s+4*t-32)*ep^3+num(8)*ep^4)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(2,-2,0,2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(-3*s^2-6*s*t+28*s-3*t^2+28*t-62)*ep+num(-8*s-8*t+40)*ep^2+num(-8)*ep^3)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(1,-2,0,3) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-15*s+3*t^2-15*t+15)+num(-3*s^2-6*s*t+21*s-3*t^2+21*t-31)*ep+num(-6*s-6*t+20)*ep^2+num(-4)*ep^3)*den(-1)*denep(2*ep-1)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(0,1,-1,1) =
	+ mibox(0,1,0,1) * numep(+num(s+t-4))*den(2)
	;

Fill box(-1,1,0,1) =
	+ mibox(0,1,0,1) * numep(+num(s+t-4))*den(2)
	;

Fill box(0,1,-2,1) =
	+ mibox(0,1,0,1) * numep(+num(2*s^2+4*s*t-14*s+2*t^2-14*t+24)+num(-s^2-2*s*t+8*s-t^2+8*t-16)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(-1,1,-1,1) =
	+ mibox(0,1,0,1) * numep(+num(s^2+3*s*t-10*s+2*t^2-14*t+24)+num(-s^2-2*s*t+8*s-t^2+8*t-16)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(-2,1,0,1) =
	+ mibox(0,1,0,1) * numep(+num(2*s^2+4*s*t-14*s+2*t^2-14*t+24)+num(-s^2-2*s*t+8*s-t^2+8*t-16)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(0,2,0,1) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-2)*ep)*den(s+t-4)
	;

Fill box(0,1,0,2) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-2)*ep)*den(s+t-4)
	;

Fill box(0,2,-1,1) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(0,1,-1,2) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(-1,2,0,1) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(-1,1,0,2) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-1)*ep)/1
	;

Fill box(0,2,-2,1) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-s-t+4)*ep)*den(2)
	;

Fill box(0,1,-2,2) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-s-t+4)*ep)*den(2)
	;

Fill box(-1,2,-1,1) =
	+ mibox(0,1,0,1) * numep(+num(s+2*t-6)+num(-s-t+4)*ep)*den(2)
	;

Fill box(-1,1,-1,2) =
	+ mibox(0,1,0,1) * numep(+num(s+2*t-6)+num(-s-t+4)*ep)*den(2)
	;

Fill box(-2,2,0,1) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-s-t+4)*ep)*den(2)
	;

Fill box(-2,1,0,2) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-s-t+4)*ep)*den(2)
	;

Fill box(0,3,0,1) =
	+ mibox(0,1,0,1) * numep(+num(-1)*ep+num(2)*ep^2)*den(s+t-4)^2
	;

Fill box(0,2,0,2) =
	+ mibox(0,1,0,1) * numep(+num(-2)+num(2)*ep+num(4)*ep^2)*den(s+t-4)^2
	;

Fill box(0,1,0,3) =
	+ mibox(0,1,0,1) * numep(+num(-1)*ep+num(2)*ep^2)*den(s+t-4)^2
	;

Fill box(0,3,-1,1) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-3)*ep+num(2)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(0,2,-1,2) =
	+ mibox(0,1,0,1) * numep(+num(-1)*ep+num(2)*ep^2)*den(s+t-4)
	;

Fill box(0,1,-1,3) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-3)*ep+num(2)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(-1,3,0,1) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-3)*ep+num(2)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(-1,2,0,2) =
	+ mibox(0,1,0,1) * numep(+num(-1)*ep+num(2)*ep^2)*den(s+t-4)
	;

Fill box(-1,1,0,3) =
	+ mibox(0,1,0,1) * numep(+num(1)+num(-3)*ep+num(2)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(0,3,-2,1) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-3*s-3*t+10)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(0,2,-2,2) =
	+ mibox(0,1,0,1) * numep(+num(s+t-4)+num(-2*s-2*t+6)*ep+num(s+t-4)*ep^2)*den(s+t-4)
	;

Fill box(0,1,-2,3) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-3*s-3*t+10)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(-1,3,-1,1) =
	+ mibox(0,1,0,1) * numep(+num(s+2*t-6)+num(-2*s-3*t+10)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(-1,2,-1,2) =
	+ mibox(0,1,0,1) * numep(+num(s+t-4)+num(-s-2*t+6)*ep+num(s+t-4)*ep^2)*den(s+t-4)
	;

Fill box(-1,1,-1,3) =
	+ mibox(0,1,0,1) * numep(+num(s+2*t-6)+num(-2*s-3*t+10)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(-2,3,0,1) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-3*s-3*t+10)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(-2,2,0,2) =
	+ mibox(0,1,0,1) * numep(+num(s+t-4)+num(-2*s-2*t+6)*ep+num(s+t-4)*ep^2)*den(s+t-4)
	;

Fill box(-2,1,0,3) =
	+ mibox(0,1,0,1) * numep(+num(2*s+2*t-6)+num(-3*s-3*t+10)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(1,1,-1,1) =
	+ mibox(1,1,0,1) * numep(+num(s^2+s*t-4*s))*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s+t))*den(s+t)
	+ mibox(1,0,0,0) * numep(+num(2*s)+num(-2*s)*ep)*den(-1)*den(s+t)*denep(2*ep-1)
	;

Fill box(1,1,-2,1) =
	+ mibox(1,1,0,1) * numep(+num(s^4+2*s^3*t-8*s^3+s^2*t^2-6*s^2*t+16*s^2+2*s*t^2-8*s*t)+num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*ep)*den(-1)*denep(ep-1)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^3+s^2*t+12*s^2+5*s*t^2-16*s*t+t^3-4*t^2)+num(3*s^3+s^2*t-12*s^2-3*s*t^2+8*s*t-t^3+4*t^2)*ep)*den(-2)*denep(ep-1)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(3*s^3+3*s^2*t-8*s^2+4*s*t)+num(-4*s^3-4*s^2*t+8*s^2)*ep)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(2,1,0,1) =
	+ mibox(1,1,0,1) * numep(+num(-1)*ep)/1
	+ mibox(0,1,0,1) * numep(+num(-1)+num(2)*ep)*den(s+t-4)
	;

Fill box(1,2,0,1) =
	+ mibox(1,1,0,1) * numep(+num(-2)*ep)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(-1)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(1,1,0,2) =
	+ mibox(1,1,0,1) * numep(+num(-2)*ep)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(-1)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(2,1,-1,1) =
	+ mibox(1,1,0,1) * numep(+num(-s+t)+num(-s^2-s*t+4*s)*ep)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s)+num(2*s)*ep)*den(s+t)
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(s+t)
	;

Fill box(1,2,-1,1) =
	+ mibox(1,1,0,1) * numep(+num(s)+num(-2*s)*ep)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s+t)+num(2*s-2*t)*ep)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s)+num(s)*ep)*den(2)*den(s+t)
	;

Fill box(1,1,-1,2) =
	+ mibox(1,1,0,1) * numep(+num(s)+num(-2*s)*ep)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s+t)+num(2*s-2*t)*ep)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s)+num(s)*ep)*den(2)*den(s+t)
	;

Fill box(2,1,-2,1) =
	+ mibox(1,1,0,1) * numep(+num(-2*s^3+2*s^2*t+8*s^2+4*s*t^2-16*s*t)+num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*ep)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-s^3-s^2*t+5*s^2-6*s*t+t^2)+num(2*s^3+2*s^2*t-8*s^2)*ep)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^3+s^2*t-4*s^2+8*s*t)+num(-5*s^3-5*s^2*t+12*s^2-8*s*t)*ep+num(4*s^3+4*s^2*t-8*s^2)*ep^2)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(1,2,-2,1) =
	+ mibox(1,1,0,1) * numep(+num(2*s^3+2*s^2*t-8*s^2+4*s*t)+num(-2*s^3-2*s^2*t+8*s^2)*ep)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(3*s^2-2*s*t-t^2)*ep)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(4*s^2-2*s*t)+num(s^3+s^2*t-8*s^2+2*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(1,1,-2,2) =
	+ mibox(1,1,0,1) * numep(+num(2*s^3+2*s^2*t-8*s^2+4*s*t)+num(-2*s^3-2*s^2*t+8*s^2)*ep)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(3*s^2-2*s*t-t^2)*ep)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(4*s^2-2*s*t)+num(s^3+s^2*t-8*s^2+2*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(3,1,0,1) =
	+ mibox(1,1,0,1) * numep(+num(s+t-2)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(1)+num(-1)*ep+num(-2)*ep^2)*den(2)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(-2)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(2,2,0,1) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(1)+num(-4)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(2,1,0,2) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(1)+num(-4)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(1,3,0,1) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s+t-10)*ep+num(-s-t+6)*ep^2+num(4)*ep^3)*den(-4)*denep(2*ep+3)*den(s+t-4)^2
	;

Fill box(1,2,0,2) =
	+ mibox(1,1,0,1) * numep(+num(s+t+2)*ep+num(4)*ep^2)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(1)+num(-2)*ep)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(-3)*ep+num(1)*ep^2+num(2)*ep^3)*den(-1)*denep(2*ep+1)*den(s+t-4)^2
	;

Fill box(1,1,0,3) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s+t-10)*ep+num(-s-t+6)*ep^2+num(4)*ep^3)*den(-4)*denep(2*ep+3)*den(s+t-4)^2
	;

Fill box(3,1,-1,1) =
	+ mibox(1,1,0,1) * numep(+num(s^2+s*t-2*t)*ep+num(s^2+s*t-4*s)*ep^2)*den(2)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(s^2+s*t-2*s-2*t)+num(-s^2-s*t+4*t)*ep+num(-2*s^2-2*s*t+8*s)*ep^2)*den(2)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s)*ep+num(s)*ep^2)*den(2)*den(s+t)
	;

Fill box(2,2,-1,1) =
	+ mibox(1,1,0,1) * numep(+num(2*s-2*t)*ep+num(2*s^2+2*s*t-8*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(2*s)*ep+num(-4*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+3*s+t)*ep+num(s-t)*ep^2+num(s^2+s*t-4*s)*ep^3)*den(-1)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(2,1,-1,2) =
	+ mibox(1,1,0,1) * numep(+num(2*s-2*t)*ep+num(2*s^2+2*s*t-8*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(2*s)*ep+num(-4*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+3*s+t)*ep+num(s-t)*ep^2+num(s^2+s*t-4*s)*ep^3)*den(-1)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(1,3,-1,1) =
	+ mibox(1,1,0,1) * numep(+num(-s)*ep+num(2*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(s-t)*ep+num(-2*s+2*t)*ep^2)*den(s+t)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-2*s)*ep+num(-s^2-s*t-2*s)*ep^2+num(4*s)*ep^3)*den(-4)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(1,2,-1,2) =
	+ mibox(1,1,0,1) * numep(+num(s^2+s*t-2*s)*ep+num(4*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(s^2+s*t-2*s-2*t)+num(-2*s^2-2*s*t+6*s+2*t)*ep+num(-4*s+4*t)*ep^2)*den(s+t)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s)*ep+num(-s)*ep^2)*den(s+t)*den(s+t-4)
	;

Fill box(1,1,-1,3) =
	+ mibox(1,1,0,1) * numep(+num(-s)*ep+num(2*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(s-t)*ep+num(-2*s+2*t)*ep^2)*den(s+t)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-2*s)*ep+num(-s^2-s*t-2*s)*ep^2+num(4*s)*ep^3)*den(-4)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(3,1,-2,1) =
	+ mibox(1,1,0,1) * numep(+num(2*s^2-8*s*t+2*t^2)+num(s^4+2*s^3*t-2*s^3+s^2*t^2-8*s^2*t-8*s^2-6*s*t^2+24*s*t)*ep+num(s^4+2*s^3*t-8*s^3+s^2*t^2-8*s^2*t+16*s^2)*ep^2)*den(2)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(s^3+s^2*t-6*s*t)+num(-s^3-s^2*t-4*s^2+12*s*t)*ep+num(-2*s^3-2*s^2*t+8*s^2)*ep^2)*den(2)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(-s^3-s^2*t+6*s*t)+num(-s^3-s^2*t+4*s^2-6*s*t)*ep+num(2*s^3+2*s^2*t-4*s^2)*ep^2)*den(2)*den(s+t)^2
	;

Fill box(2,2,-2,1) =
	+ mibox(1,1,0,1) * numep(+num(-2*s^2+4*s*t)+num(-s^3-s^2*t+8*s^2-8*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-s^3-s^2*t+5*s^2-6*s*t+t^2)+num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*ep+num(-4*s^3-4*s^2*t+16*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^3+s^2*t+2*s^2-4*s*t)+num(-6*s^2+4*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(2)*den(s+t)^2
	;

Fill box(2,1,-2,2) =
	+ mibox(1,1,0,1) * numep(+num(-2*s^2+4*s*t)+num(-s^3-s^2*t+8*s^2-8*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-s^3-s^2*t+5*s^2-6*s*t+t^2)+num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*ep+num(-4*s^3-4*s^2*t+16*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^3+s^2*t+2*s^2-4*s*t)+num(-6*s^2+4*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(2)*den(s+t)^2
	;

Fill box(1,3,-2,1) =
	+ mibox(1,1,0,1) * numep(+num(s^3+s^2*t-4*s^2+2*s*t)+num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(9*s^2-10*s*t-3*t^2)*ep+num(-6*s^2+4*s*t+2*t^2)*ep^2)*den(2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^4+2*s^3*t-2*s^3+s^2*t^2-4*s^2*t-8*s^2-2*s*t^2+4*s*t)+num(2*s^2*t+2*s*t^2+4*s*t)*ep+num(-s^4-2*s^3*t-2*s^3-s^2*t^2-2*s^2*t+24*s^2-8*s*t)*ep^2+num(4*s^3+4*s^2*t-16*s^2)*ep^3)*den(-4)*denep(2*ep+1)*den(s+t-4)*den(s+t)^2
	;

Fill box(1,2,-2,2) =
	+ mibox(1,1,0,1) * numep(+num(2*s^3-8*s^2-2*s*t^2+4*s*t)+num(s^4+2*s^3*t-10*s^3+s^2*t^2-10*s^2*t+24*s^2-8*s*t)*ep+num(4*s^3+4*s^2*t-16*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(s^3+s^2*t-4*s^2+2*s*t)+num(-2*s^3-2*s^2*t+11*s^2-6*s*t-t^2)*ep+num(-6*s^2+4*s*t+2*t^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(-s^3-s^2*t+4*s^2-2*s*t)+num(2*s^3+2*s^2*t-8*s^2+2*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	;

Fill box(1,1,-2,3) =
	+ mibox(1,1,0,1) * numep(+num(s^3+s^2*t-4*s^2+2*s*t)+num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(9*s^2-10*s*t-3*t^2)*ep+num(-6*s^2+4*s*t+2*t^2)*ep^2)*den(2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^4+2*s^3*t-2*s^3+s^2*t^2-4*s^2*t-8*s^2-2*s*t^2+4*s*t)+num(2*s^2*t+2*s*t^2+4*s*t)*ep+num(-s^4-2*s^3*t-2*s^3-s^2*t^2-2*s^2*t+24*s^2-8*s*t)*ep^2+num(4*s^3+4*s^2*t-16*s^2)*ep^3)*den(-4)*denep(2*ep+1)*den(s+t-4)*den(s+t)^2
	;

Fill box(0,0,1,1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-1)*denep(2*ep-1)
	;

Fill box(0,-1,1,1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(-4)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,0,1,1) =
	+ mibox(1,0,0,0) * numep(+num(s))*den(2)
	;

Fill box(0,-2,1,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*denep(2*ep-3)*denep(2*ep-1)
	;

Fill box(-1,-1,1,1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+10*s)+num(-4*s)*ep)*den(-2)*denep(2*ep-3)
	;

Fill box(-2,0,1,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s)+num(-s^2)*ep)*den(-1)*denep(2*ep-3)
	;

Fill box(0,0,2,1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(2)
	;

Fill box(0,0,1,2) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-2)*denep(2*ep+1)
	;

Fill box(0,-1,2,1) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+6)+num(s+t-10)*ep+num(4)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(0,-1,1,2) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-1,0,2,1) =
	+ mibox(1,0,0,0) * numep(+num(1)+num(-s-1)*ep+num(s)*ep^2)*den(-1)*denep(2*ep-1)
	;

Fill box(-1,0,1,2) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(0,-2,2,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-10*s+t^2-10*t+30)+num(4*s+4*t-32)*ep+num(8)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(0,-2,1,2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(8*s+8*t-32)*ep+num(8)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-1,-1,2,1) =
	+ mibox(1,0,0,0) * numep(+num(s-t+6)+num(s^2+s*t-10*s-4)*ep+num(4*s)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(-1,-1,1,2) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+5*s)+num(-2*s)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(-2,0,2,1) =
	+ mibox(1,0,0,0) * numep(+num(4*s)+num(-s^2)*ep)*den(2)
	;

Fill box(-2,0,1,2) =
	+ mibox(1,0,0,0) * numep(+num(2*s)+num(-s^2)*ep)*den(-2)*denep(2*ep-1)
	;

Fill box(0,0,3,1) =
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^3)*den(-2)*denep(2*ep+1)
	;

Fill box(0,0,2,2) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(0,0,1,3) =
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(2)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(0,-1,3,1) =
	+ mibox(1,0,0,0) * numep(+num(s+t-4)+num(2)*ep+num(-s-t+6)*ep^2+num(-4)*ep^3)*den(-4)*denep(2*ep+1)
	;

Fill box(0,-1,2,2) =
	+ mibox(1,0,0,0) * numep(+num(-s-t+3)+num(s+t-5)*ep+num(2)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(0,-1,1,3) =
	+ mibox(1,0,0,0) * numep(+num(-3*s-3*t+6)+num(3*s+3*t-10)*ep+num(4)*ep^2)*den(4)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(-1,0,3,1) =
	+ mibox(1,0,0,0) * numep(+num(-s+2)+num(-2)*ep+num(s)*ep^2)*den(4)
	;

Fill box(-1,0,2,2) =
	+ mibox(1,0,0,0) * numep(+num(-s+1)+num(-1)*ep+num(s)*ep^2)*den(-2)*denep(2*ep+1)
	;

Fill box(-1,0,1,3) =
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(-4)*denep(2*ep+1)
	;

Fill box(0,-2,3,1) =
	+ mibox(1,0,0,0) * numep(+num(-s^2-2*s*t+8*s-t^2+8*t-18)+num(-2*s-2*t+12)*ep+num(s^2+2*s*t-10*s+t^2-10*t+30)*ep^2+num(4*s+4*t-32)*ep^3+num(8)*ep^4)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(0,-2,2,2) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-20*s+3*t^2-20*t+30)+num(-3*s^2-6*s*t+28*s-3*t^2+28*t-62)*ep+num(-8*s-8*t+40)*ep^2+num(-8)*ep^3)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(0,-2,1,3) =
	+ mibox(1,0,0,0) * numep(+num(3*s^2+6*s*t-15*s+3*t^2-15*t+15)+num(-3*s^2-6*s*t+21*s-3*t^2+21*t-31)*ep+num(-6*s-6*t+20)*ep^2+num(-4)*ep^3)*den(-1)*denep(2*ep-1)*denep(2*ep+1)*denep(2*ep+3)
	;

Fill box(-1,-1,3,1) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-6*s-2*t+12)+num(2*t-20)*ep+num(-s^2-s*t+10*s+8)*ep^2+num(-4*s)*ep^3)*den(-4)*denep(2*ep-1)
	;

Fill box(-1,-1,2,2) =
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-5*s-t+3)+num(2*s+t-5)*ep+num(-s^2-s*t+5*s+2)*ep^2+num(-2*s)*ep^3)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-1,-1,1,3) =
	+ mibox(1,0,0,0) * numep(+num(-3*s^2-3*s*t+10*s)+num(3*s^2+3*s*t-14*s)*ep+num(4*s)*ep^2)*den(4)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(-2,0,3,1) =
	+ mibox(1,0,0,0) * numep(+num(2)+num(s^2-6*s-2)*ep+num(6*s)*ep^2+num(-s^2)*ep^3)*den(-2)*denep(2*ep-1)
	;

Fill box(-2,0,2,2) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+4*s)+num(-4*s)*ep+num(s^2)*ep^2)*den(-2)*denep(2*ep-1)
	;

Fill box(-2,0,1,3) =
	+ mibox(1,0,0,0) * numep(+num(-s^2+2*s)+num(-2*s)*ep+num(s^2)*ep^2)*den(2)*denep(2*ep-1)*denep(2*ep+1)
	;

Fill box(1,0,1,1) =
	+ mibox(1,0,1,0) * numep(+num(-1)+num(2)*ep)*den(-1)/ep*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(1)+num(-1)*ep)*den(-1)/ep*den(s-4)
	;

Fill box(1,-1,1,1) =
	+ mibox(1,0,1,0) * numep(+num(s+t-4)+num(-s+4)*ep)*den(-1)/ep*den(s-4)
	+ mibox(1,0,0,0) * numep(+num(-s-t+4)+num(s+t-4)*ep)/ep*den(s-4)*denep(2*ep-1)
	;

Fill box(1,-2,1,1) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)+num(3*s^2+2*s*t-24*s-8*t+48)*ep+num(-s^2+8*s-16)*ep^2)*den(2)/ep*den(s-4)*denep(ep-1)
	+ mibox(1,0,0,0) * numep(+num(s^2+2*s*t-8*s+t^2-8*t+16)+num(-s+4)*ep+num(2*s-8)*ep^2)/ep*den(s-4)*denep(2*ep-1)
	;

Fill box(2,0,1,1) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-4)*ep)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s+6)*ep+num(s-8)*ep^2)*den(-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,0,2,1) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-4)*ep)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s+6)*ep+num(s-8)*ep^2)*den(-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,0,1,2) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-4)*ep)*den(-1)*denep(ep+1)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2)+num(-s+6)*ep+num(s-8)*ep^2)*denep(ep+1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(2,-1,1,1) =
	+ mibox(1,0,1,0) * numep(+num(-s-t+4)+num(3*s+2*t-12)*ep+num(-2*s+8)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-2*s-2*t+8)+num(s^2+s*t-8*s-6*t+16)*ep+num(-s^2-s*t+14*s+8*t-40)*ep^2+num(-4*s+16)*ep^3)*den(2)/ep*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,-1,2,1) =
	+ mibox(1,0,1,0) * numep(+num(-s-t+4)+num(3*s+2*t-12)*ep+num(-2*s+8)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-2*s-2*t+8)+num(s^2+s*t-8*s-6*t+16)*ep+num(-s^2-s*t+14*s+8*t-40)*ep^2+num(-4*s+16)*ep^3)*den(2)/ep*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,-1,1,2) =
	+ mibox(1,0,1,0) * numep(+num(-s-2*t+4)+num(3*s+4*t-12)*ep+num(-2*s+8)*ep^2)/ep*denep(ep+1)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-s-2*t+4)+num(s^2+s*t-8*s-6*t+16)*ep+num(-s^2-s*t+11*s+8*t-28)*ep^2+num(-2*s+8)*ep^3)*den(-1)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(2,-2,1,1) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-3*s^2-2*s*t+24*s+8*t-48)*ep+num(s^2-8*s+16)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*ep+num(s^3+2*s^2*t-18*s^2+s*t^2-26*s*t+96*s-8*t^2+72*t-160)*ep^2+num(4*s^2+4*s*t-32*s-16*t+64)*ep^3)*den(-1)/ep*denep(2*ep-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,-2,2,1) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-3*s^2-2*s*t+24*s+8*t-48)*ep+num(s^2-8*s+16)*ep^2)*den(-1)/ep*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)+num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*ep+num(s^3+2*s^2*t-18*s^2+s*t^2-26*s*t+96*s-8*t^2+72*t-160)*ep^2+num(4*s^2+4*s*t-32*s-16*t+64)*ep^3)*den(-1)/ep*denep(2*ep-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(1,-2,1,2) =
	+ mibox(1,0,1,0) * numep(+num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)+num(-3*s^2-4*s*t+24*s+16*t-48)*ep+num(s^2-8*s+16)*ep^2)/ep*denep(ep+1)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)+num(-3*s^3-6*s^2*t+34*s^2-3*s*t^2+52*s*t-128*s+18*t^2-112*t+160)*ep+num(3*s^3+6*s^2*t-44*s^2+3*s*t^2-68*s*t+208*s-24*t^2+176*t-320)*ep^2+num(8*s^2+8*s*t-64*s-32*t+128)*ep^3)/ep*denep(ep+1)*denep(2*ep-1)*denep(2*ep+1)*den(s-4)^2
	;

Fill box(3,0,1,1) =
	+ mibox(1,0,1,0) * numep(+num(-s-2)+num(-s)*ep+num(4*s+8)*ep^2+num(4*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s+8)+num(s^3-12*s^2+44*s-8)*ep+num(-32)*ep^2+num(-s^3+12*s^2-48*s+32)*ep^3)*den(-4)*den(s)*denep(ep+1)*den(s-4)^3
	;

Fill box(2,0,2,1) =
	+ mibox(1,0,1,0) * numep(+num(-4*s+4)+num(-2*s)*ep+num(16*s-16)*ep^2+num(8*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s-4)+num(-s^2+8*s+4)*ep+num(s^2-12*s+16)*ep^2+num(-16)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	;

Fill box(2,0,1,2) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12)+num(s^2-14*s+60)*ep+num(2*s-24)*ep^2+num(-s^2+12*s-48)*ep^3)*den(2)*denep(ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,0,3,1) =
	+ mibox(1,0,1,0) * numep(+num(-s-2)+num(-s)*ep+num(4*s+8)*ep^2+num(4*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s+8)+num(s^3-12*s^2+44*s-8)*ep+num(-32)*ep^2+num(-s^3+12*s^2-48*s+32)*ep^3)*den(-4)*den(s)*denep(ep+1)*den(s-4)^3
	;

Fill box(1,0,2,2) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12)+num(s^2-14*s+60)*ep+num(2*s-24)*ep^2+num(-s^2+12*s-48)*ep^3)*den(2)*denep(ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,0,1,3) =
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*denep(ep+1)*denep(ep+2)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12)+num(s^2-14*s+60)*ep+num(2*s-24)*ep^2+num(-s^2+12*s-48)*ep^3)*den(-2)*denep(ep+1)*denep(ep+2)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(3,-1,1,1) =
	+ mibox(1,0,1,0) * numep(+num(-s^2-s*t+4*s-2*t)+num(2*s^2+s*t-6*s+4*t-8)*ep+num(s^2+2*s*t-8*s+16)*ep^2+num(-2*s^2+8*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-4*s^2-4*s*t+16*s-8*t)+num(-s^4-s^3*t+14*s^3+12*s^2*t-68*s^2-44*s*t+120*s+8*t-32)*ep+num(-4*s^3+48*s^2-136*s+32*t+32)*ep^2+num(s^4+s^3*t-14*s^3-12*s^2*t+72*s^2+48*s*t-160*s-32*t+128)*ep^3+num(4*s^3-48*s^2+160*s-128)*ep^4)*den(4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(2,-1,2,1) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-4*s*t+8*s+4*t)+num(6*s^2+6*s*t-28*s-8*t+16)*ep+num(-2*s^2+4*s*t+16*s-32)*ep^2+num(-4*s^2+16*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-2*s^2-4*s*t+8*s+4*t)+num(s^3+s^2*t-8*s^2-8*s*t+12*s-4*t+16)*ep+num(-s^3-s^2*t+14*s^2+12*s*t-36*s-16*t-16)*ep^2+num(-4*s^2+32*s+16*t-64)*ep^3+num(-16*s+64)*ep^4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(2,-1,1,2) =
	+ mibox(1,0,1,0) * numep(+num(2*s+4*t-8)+num(-6*s-8*t+24)*ep+num(4*s-16)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-6*s-12*t+24)+num(-s^3-s^2*t+15*s^2+14*s*t-76*s-60*t+128)*ep+num(-4*s^2-2*s*t+50*s+24*t-136)*ep^2+num(s^3+s^2*t-13*s^2-12*s*t+56*s+48*t-80)*ep^3+num(2*s^2-24*s+64)*ep^4)*den(-1)*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,-1,3,1) =
	+ mibox(1,0,1,0) * numep(+num(-s^2-s*t+4*s-2*t)+num(2*s^2+s*t-6*s+4*t-8)*ep+num(s^2+2*s*t-8*s+16)*ep^2+num(-2*s^2+8*s)*ep^3)*den(-1)*den(s)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-4*s^2-4*s*t+16*s-8*t)+num(-s^4-s^3*t+14*s^3+12*s^2*t-68*s^2-44*s*t+120*s+8*t-32)*ep+num(-4*s^3+48*s^2-136*s+32*t+32)*ep^2+num(s^4+s^3*t-14*s^3-12*s^2*t+72*s^2+48*s*t-160*s-32*t+128)*ep^3+num(4*s^3-48*s^2+160*s-128)*ep^4)*den(4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(1,-1,2,2) =
	+ mibox(1,0,1,0) * numep(+num(2*s+4*t-8)+num(-6*s-8*t+24)*ep+num(4*s-16)*ep^2)*den(-1)*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-6*s-12*t+24)+num(-s^3-s^2*t+15*s^2+14*s*t-76*s-60*t+128)*ep+num(-4*s^2-2*s*t+50*s+24*t-136)*ep^2+num(s^3+s^2*t-13*s^2-12*s*t+56*s+48*t-80)*ep^3+num(2*s^2-24*s+64)*ep^4)*den(-1)*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,-1,1,3) =
	+ mibox(1,0,1,0) * numep(+num(2*s+6*t-8)+num(-6*s-12*t+24)*ep+num(4*s-16)*ep^2)*denep(ep+1)*denep(ep+2)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-12*s-36*t+48)+num(-3*s^3-3*s^2*t+42*s^2+42*s*t-200*s-180*t+320)*ep+num(-8*s^2-6*s*t+100*s+72*t-272)*ep^2+num(3*s^3+3*s^2*t-38*s^2-36*s*t+160*s+144*t-224)*ep^3+num(4*s^2-48*s+128)*ep^4)*den(2)*denep(ep+1)*denep(ep+2)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(3,-2,1,1) =
	+ mibox(1,0,1,0) * numep(+num(2*s^3+4*s^2*t-16*s^2+2*s*t^2-12*s*t+32*s+4*t^2-16*t)+num(-5*s^3-6*s^2*t+38*s^2-2*s*t^2+12*s*t-64*s-8*t^2+48*t-32)*ep+num(-6*s^2*t+6*s^2-4*s*t^2+32*s*t-48*s-32*t+96)*ep^2+num(5*s^3+4*s^2*t-44*s^2-16*s*t+112*s-64)*ep^3+num(-2*s^3+16*s^2-32*s)*ep^4)*den(2)*den(s)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s^3+8*s^2*t-32*s^2+4*s*t^2-24*s*t+64*s+8*t^2-32*t)+num(s^5+2*s^4*t-18*s^4+s^3*t^2-30*s^3*t+122*s^3-12*s^2*t^2+160*s^2*t-372*s^2+44*s*t^2-304*s*t+448*s-8*t^2+64*t-64)*ep+num(4*s^4+4*s^3*t-64*s^3-48*s^2*t+328*s^2+104*s*t-576*s-32*t^2+96*t+128)*ep^2+num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-118*s^3+12*s^2*t^2-168*s^2*t+348*s^2-48*s*t^2+384*s*t-448*s+32*t^2-256*t+192)*ep^3+num(-4*s^4-4*s^3*t+64*s^3+48*s^2*t-352*s^2-160*s*t+768*s+128*t-512)*ep^4+num(-8*s^3+80*s^2-256*s+256)*ep^5)*den(-4)*den(s)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(2,-2,2,1) =
	+ mibox(1,0,1,0) * numep(+num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)+num(-6*s^3-12*s^2*t+50*s^2-6*s*t^2+60*s*t-112*s+8*t^2-48*t+32)*ep+num(3*s^3-2*s^2*t-30*s^2-4*s*t^2+96*s+32*t-96)*ep^2+num(3*s^3+4*s^2*t-20*s^2-16*s*t+16*s+64)*ep^3+num(-2*s^3+16*s^2-32*s)*ep^4)*den(s)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)+num(-s^4-2*s^3*t+12*s^3-s^2*t^2+20*s^2*t-46*s^2+8*s*t^2-40*s*t+48*s+4*t^2-32*t+32)*ep+num(s^4+2*s^3*t-18*s^3+s^2*t^2-30*s^2*t+92*s^2-12*s*t^2+100*s*t-128*s+16*t^2-48*t-64)*ep^2+num(4*s^3+4*s^2*t-38*s^2-48*s*t+112*s-16*t^2+128*t-96)*ep^3+num(16*s^2+16*s*t-128*s-64*t+256)*ep^4+num(-8*s^2+64*s-128)*ep^5)*den(-1)*den(s)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(2,-2,1,2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)+num(7*s^2+20*s*t-56*s+12*t^2-80*t+112)*ep+num(-7*s^2-8*s*t+56*s+32*t-112)*ep^2+num(2*s^2-16*s+32)*ep^3)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s^2+48*s*t-96*s+36*t^2-192*t+192)+num(3*s^4+6*s^3*t-54*s^3+3*s^2*t^2-96*s^2*t+362*s^2-42*s*t^2+536*s*t-1072*s+180*t^2-992*t+1184)*ep+num(14*s^3+20*s^2*t-208*s^2+6*s*t^2-264*s*t+992*s-72*t^2+736*t-1536)*ep^2+num(-3*s^4-6*s^3*t+48*s^3-3*s^2*t^2+84*s^2*t-270*s^2+36*s*t^2-416*s*t+624*s-144*t^2+704*t-480)*ep^3+num(-8*s^3-8*s^2*t+112*s^2+96*s*t-512*s-256*t+768)*ep^4+num(-8*s^2+64*s-128)*ep^5)*den(2)/ep*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,-2,3,1) =
	+ mibox(1,0,1,0) * numep(+num(2*s^3+4*s^2*t-16*s^2+2*s*t^2-12*s*t+32*s+4*t^2-16*t)+num(-5*s^3-6*s^2*t+38*s^2-2*s*t^2+12*s*t-64*s-8*t^2+48*t-32)*ep+num(-6*s^2*t+6*s^2-4*s*t^2+32*s*t-48*s-32*t+96)*ep^2+num(5*s^3+4*s^2*t-44*s^2-16*s*t+112*s-64)*ep^3+num(-2*s^3+16*s^2-32*s)*ep^4)*den(2)*den(s)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s^3+8*s^2*t-32*s^2+4*s*t^2-24*s*t+64*s+8*t^2-32*t)+num(s^5+2*s^4*t-18*s^4+s^3*t^2-30*s^3*t+122*s^3-12*s^2*t^2+160*s^2*t-372*s^2+44*s*t^2-304*s*t+448*s-8*t^2+64*t-64)*ep+num(4*s^4+4*s^3*t-64*s^3-48*s^2*t+328*s^2+104*s*t-576*s-32*t^2+96*t+128)*ep^2+num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-118*s^3+12*s^2*t^2-168*s^2*t+348*s^2-48*s*t^2+384*s*t-448*s+32*t^2-256*t+192)*ep^3+num(-4*s^4-4*s^3*t+64*s^3+48*s^2*t-352*s^2-160*s*t+768*s+128*t-512)*ep^4+num(-8*s^3+80*s^2-256*s+256)*ep^5)*den(-4)*den(s)/ep*denep(ep+1)*denep(2*ep+1)*den(s-4)^3
	;

Fill box(1,-2,2,2) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)+num(7*s^2+20*s*t-56*s+12*t^2-80*t+112)*ep+num(-7*s^2-8*s*t+56*s+32*t-112)*ep^2+num(2*s^2-16*s+32)*ep^3)/ep*denep(ep+1)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s^2+48*s*t-96*s+36*t^2-192*t+192)+num(3*s^4+6*s^3*t-54*s^3+3*s^2*t^2-96*s^2*t+362*s^2-42*s*t^2+536*s*t-1072*s+180*t^2-992*t+1184)*ep+num(14*s^3+20*s^2*t-208*s^2+6*s*t^2-264*s*t+992*s-72*t^2+736*t-1536)*ep^2+num(-3*s^4-6*s^3*t+48*s^3-3*s^2*t^2+84*s^2*t-270*s^2+36*s*t^2-416*s*t+624*s-144*t^2+704*t-480)*ep^3+num(-8*s^3-8*s^2*t+112*s^2+96*s*t-512*s-256*t+768)*ep^4+num(-8*s^2+64*s-128)*ep^5)*den(2)/ep*denep(ep+1)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(1,-2,1,3) =
	+ mibox(1,0,1,0) * numep(+num(-2*s^2-12*s*t+16*s-12*t^2+48*t-32)+num(7*s^2+30*s*t-56*s+24*t^2-120*t+112)*ep+num(-7*s^2-12*s*t+56*s+48*t-112)*ep^2+num(2*s^2-16*s+32)*ep^3)*den(-1)/ep*denep(ep+1)*denep(ep+2)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(6*s^2+36*s*t-48*s+36*t^2-144*t+96)+num(3*s^4+6*s^3*t-48*s^3+3*s^2*t^2-90*s^2*t+289*s^2-42*s*t^2+474*s*t-776*s+180*t^2-840*t+784)*ep+num(9*s^3+15*s^2*t-128*s^2+6*s*t^2-198*s*t+592*s-72*t^2+552*t-896)*ep^2+num(-3*s^4-6*s^3*t+45*s^3-3*s^2*t^2+81*s^2*t-243*s^2+36*s*t^2-384*s*t+552*s-144*t^2+624*t-432)*ep^3+num(-6*s^3-6*s^2*t+80*s^2+72*s*t-352*s-192*t+512)*ep^4+num(-4*s^2+32*s-64)*ep^5)*den(-1)/ep*denep(ep+1)*denep(ep+2)*denep(2*ep+1)*denep(2*ep+3)*den(s-4)^3
	;

Fill box(0,1,1,1) =
	+ mibox(1,1,0,1) * 1/1
	;

Fill box(-1,1,1,1) =
	+ mibox(1,1,0,1) * numep(+num(s^2+s*t-4*s))*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s+t))*den(s+t)
	+ mibox(1,0,0,0) * numep(+num(2*s)+num(-2*s)*ep)*den(-1)*den(s+t)*denep(2*ep-1)
	;

Fill box(-2,1,1,1) =
	+ mibox(1,1,0,1) * numep(+num(s^4+2*s^3*t-8*s^3+s^2*t^2-6*s^2*t+16*s^2+2*s*t^2-8*s*t)+num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*ep)*den(-1)*denep(ep-1)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^3+s^2*t+12*s^2+5*s*t^2-16*s*t+t^3-4*t^2)+num(3*s^3+s^2*t-12*s^2-3*s*t^2+8*s*t-t^3+4*t^2)*ep)*den(-2)*denep(ep-1)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(3*s^3+3*s^2*t-8*s^2+4*s*t)+num(-4*s^3-4*s^2*t+8*s^2)*ep)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(0,2,1,1) =
	+ mibox(1,1,0,1) * numep(+num(-2)*ep)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(-1)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(0,1,2,1) =
	+ mibox(1,1,0,1) * numep(+num(-1)*ep)/1
	+ mibox(0,1,0,1) * numep(+num(-1)+num(2)*ep)*den(s+t-4)
	;

Fill box(0,1,1,2) =
	+ mibox(1,1,0,1) * numep(+num(-2)*ep)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(-1)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(-1,2,1,1) =
	+ mibox(1,1,0,1) * numep(+num(s)+num(-2*s)*ep)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s+t)+num(2*s-2*t)*ep)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s)+num(s)*ep)*den(2)*den(s+t)
	;

Fill box(-1,1,2,1) =
	+ mibox(1,1,0,1) * numep(+num(-s+t)+num(-s^2-s*t+4*s)*ep)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s)+num(2*s)*ep)*den(s+t)
	+ mibox(1,0,0,0) * numep(+num(s)+num(-s)*ep)*den(s+t)
	;

Fill box(-1,1,1,2) =
	+ mibox(1,1,0,1) * numep(+num(s)+num(-2*s)*ep)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(-s+t)+num(2*s-2*t)*ep)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s)+num(s)*ep)*den(2)*den(s+t)
	;

Fill box(-2,2,1,1) =
	+ mibox(1,1,0,1) * numep(+num(2*s^3+2*s^2*t-8*s^2+4*s*t)+num(-2*s^3-2*s^2*t+8*s^2)*ep)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(3*s^2-2*s*t-t^2)*ep)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(4*s^2-2*s*t)+num(s^3+s^2*t-8*s^2+2*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(-2,1,2,1) =
	+ mibox(1,1,0,1) * numep(+num(-2*s^3+2*s^2*t+8*s^2+4*s*t^2-16*s*t)+num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*ep)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-s^3-s^2*t+5*s^2-6*s*t+t^2)+num(2*s^3+2*s^2*t-8*s^2)*ep)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^3+s^2*t-4*s^2+8*s*t)+num(-5*s^3-5*s^2*t+12*s^2-8*s*t)*ep+num(4*s^3+4*s^2*t-8*s^2)*ep^2)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(-2,1,1,2) =
	+ mibox(1,1,0,1) * numep(+num(2*s^3+2*s^2*t-8*s^2+4*s*t)+num(-2*s^3-2*s^2*t+8*s^2)*ep)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(3*s^2-2*s*t-t^2)*ep)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(4*s^2-2*s*t)+num(s^3+s^2*t-8*s^2+2*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(-1)*denep(2*ep-1)*den(s+t)^2
	;

Fill box(0,3,1,1) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s+t-10)*ep+num(-s-t+6)*ep^2+num(4)*ep^3)*den(-4)*denep(2*ep+3)*den(s+t-4)^2
	;

Fill box(0,2,2,1) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(1)+num(-4)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(0,2,1,2) =
	+ mibox(1,1,0,1) * numep(+num(s+t+2)*ep+num(4)*ep^2)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(1)+num(-2)*ep)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(-3)*ep+num(1)*ep^2+num(2)*ep^3)*den(-1)*denep(2*ep+1)*den(s+t-4)^2
	;

Fill box(0,1,3,1) =
	+ mibox(1,1,0,1) * numep(+num(s+t-2)*ep+num(s+t-4)*ep^2)*den(2)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(1)+num(-1)*ep+num(-2)*ep^2)*den(2)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-1)*ep+num(1)*ep^2)*den(-2)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(0,1,2,2) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(1)+num(-4)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(1)*ep+num(-1)*ep^2)*den(2)*den(s+t-4)
	;

Fill box(0,1,1,3) =
	+ mibox(1,1,0,1) * numep(+num(1)*ep+num(2)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s+t-10)*ep+num(-s-t+6)*ep^2+num(4)*ep^3)*den(-4)*denep(2*ep+3)*den(s+t-4)^2
	;

Fill box(-1,3,1,1) =
	+ mibox(1,1,0,1) * numep(+num(-s)*ep+num(2*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(s-t)*ep+num(-2*s+2*t)*ep^2)*den(s+t)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-2*s)*ep+num(-s^2-s*t-2*s)*ep^2+num(4*s)*ep^3)*den(-4)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(-1,2,2,1) =
	+ mibox(1,1,0,1) * numep(+num(2*s-2*t)*ep+num(2*s^2+2*s*t-8*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(2*s)*ep+num(-4*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+3*s+t)*ep+num(s-t)*ep^2+num(s^2+s*t-4*s)*ep^3)*den(-1)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(-1,2,1,2) =
	+ mibox(1,1,0,1) * numep(+num(s^2+s*t-2*s)*ep+num(4*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(s^2+s*t-2*s-2*t)+num(-2*s^2-2*s*t+6*s+2*t)*ep+num(-4*s+4*t)*ep^2)*den(s+t)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s)*ep+num(-s)*ep^2)*den(s+t)*den(s+t-4)
	;

Fill box(-1,1,3,1) =
	+ mibox(1,1,0,1) * numep(+num(s^2+s*t-2*t)*ep+num(s^2+s*t-4*s)*ep^2)*den(2)*den(s+t)
	+ mibox(0,1,0,1) * numep(+num(s^2+s*t-2*s-2*t)+num(-s^2-s*t+4*t)*ep+num(-2*s^2-2*s*t+8*s)*ep^2)*den(2)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s)*ep+num(s)*ep^2)*den(2)*den(s+t)
	;

Fill box(-1,1,2,2) =
	+ mibox(1,1,0,1) * numep(+num(2*s-2*t)*ep+num(2*s^2+2*s*t-8*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(2*s)*ep+num(-4*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(-s^2-s*t+3*s+t)*ep+num(s-t)*ep^2+num(s^2+s*t-4*s)*ep^3)*den(-1)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(-1,1,1,3) =
	+ mibox(1,1,0,1) * numep(+num(-s)*ep+num(2*s)*ep^2)*den(s+t)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(s-t)*ep+num(-2*s+2*t)*ep^2)*den(s+t)*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(s^2+s*t-2*s)*ep+num(-s^2-s*t-2*s)*ep^2+num(4*s)*ep^3)*den(-4)*den(s+t)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(-2,3,1,1) =
	+ mibox(1,1,0,1) * numep(+num(s^3+s^2*t-4*s^2+2*s*t)+num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(9*s^2-10*s*t-3*t^2)*ep+num(-6*s^2+4*s*t+2*t^2)*ep^2)*den(2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^4+2*s^3*t-2*s^3+s^2*t^2-4*s^2*t-8*s^2-2*s*t^2+4*s*t)+num(2*s^2*t+2*s*t^2+4*s*t)*ep+num(-s^4-2*s^3*t-2*s^3-s^2*t^2-2*s^2*t+24*s^2-8*s*t)*ep^2+num(4*s^3+4*s^2*t-16*s^2)*ep^3)*den(-4)*denep(2*ep+1)*den(s+t-4)*den(s+t)^2
	;

Fill box(-2,2,2,1) =
	+ mibox(1,1,0,1) * numep(+num(-2*s^2+4*s*t)+num(-s^3-s^2*t+8*s^2-8*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-s^3-s^2*t+5*s^2-6*s*t+t^2)+num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*ep+num(-4*s^3-4*s^2*t+16*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^3+s^2*t+2*s^2-4*s*t)+num(-6*s^2+4*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(2)*den(s+t)^2
	;

Fill box(-2,2,1,2) =
	+ mibox(1,1,0,1) * numep(+num(2*s^3-8*s^2-2*s*t^2+4*s*t)+num(s^4+2*s^3*t-10*s^3+s^2*t^2-10*s^2*t+24*s^2-8*s*t)*ep+num(4*s^3+4*s^2*t-16*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(s^3+s^2*t-4*s^2+2*s*t)+num(-2*s^3-2*s^2*t+11*s^2-6*s*t-t^2)*ep+num(-6*s^2+4*s*t+2*t^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(-s^3-s^2*t+4*s^2-2*s*t)+num(2*s^3+2*s^2*t-8*s^2+2*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	;

Fill box(-2,1,3,1) =
	+ mibox(1,1,0,1) * numep(+num(2*s^2-8*s*t+2*t^2)+num(s^4+2*s^3*t-2*s^3+s^2*t^2-8*s^2*t-8*s^2-6*s*t^2+24*s*t)*ep+num(s^4+2*s^3*t-8*s^3+s^2*t^2-8*s^2*t+16*s^2)*ep^2)*den(2)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(s^3+s^2*t-6*s*t)+num(-s^3-s^2*t-4*s^2+12*s*t)*ep+num(-2*s^3-2*s^2*t+8*s^2)*ep^2)*den(2)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(-s^3-s^2*t+6*s*t)+num(-s^3-s^2*t+4*s^2-6*s*t)*ep+num(2*s^3+2*s^2*t-4*s^2)*ep^2)*den(2)*den(s+t)^2
	;

Fill box(-2,1,2,2) =
	+ mibox(1,1,0,1) * numep(+num(-2*s^2+4*s*t)+num(-s^3-s^2*t+8*s^2-8*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-s^3-s^2*t+5*s^2-6*s*t+t^2)+num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*ep+num(-4*s^3-4*s^2*t+16*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^3+s^2*t+2*s^2-4*s*t)+num(-6*s^2+4*s*t)*ep+num(-s^3-s^2*t+4*s^2)*ep^2)*den(2)*den(s+t)^2
	;

Fill box(-2,1,1,3) =
	+ mibox(1,1,0,1) * numep(+num(s^3+s^2*t-4*s^2+2*s*t)+num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*ep+num(2*s^3+2*s^2*t-8*s^2)*ep^2)*den(s+t-4)*den(s+t)^2
	+ mibox(0,1,0,1) * numep(+num(-3*s^2+4*s*t+t^2)+num(9*s^2-10*s*t-3*t^2)*ep+num(-6*s^2+4*s*t+2*t^2)*ep^2)*den(2)*den(s+t-4)*den(s+t)^2
	+ mibox(1,0,0,0) * numep(+num(s^4+2*s^3*t-2*s^3+s^2*t^2-4*s^2*t-8*s^2-2*s*t^2+4*s*t)+num(2*s^2*t+2*s*t^2+4*s*t)*ep+num(-s^4-2*s^3*t-2*s^3-s^2*t^2-2*s^2*t+24*s^2-8*s*t)*ep^2+num(4*s^3+4*s^2*t-16*s^2)*ep^3)*den(-4)*denep(2*ep+1)*den(s+t-4)*den(s+t)^2
	;

Fill box(2,1,1,1) =
	+ mibox(1,1,1,1) * numep(+num(1)+num(2)*ep)*den(s-4)
	+ mibox(1,1,0,1) * numep(+num(-s-t)*ep)*den(s-4)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(-1)+num(2)*ep)*den(s-4)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(2)*ep+num(-2)*ep^2)*den(-1)*den(s-4)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(1,2,1,1) =
	+ mibox(1,1,1,1) * numep(+num(-1)+num(-2)*ep)*den(s+t-4)
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*den(-1)*denep(ep+1)*den(s+t-4)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-2)+num(s-6)*ep+num(-s+8)*ep^2)*den(-1)*denep(ep+1)*den(s+t-4)*den(s-4)^2
	;

Fill box(1,1,2,1) =
	+ mibox(1,1,1,1) * numep(+num(1)+num(2)*ep)*den(s-4)
	+ mibox(1,1,0,1) * numep(+num(-s-t)*ep)*den(s-4)*den(s+t-4)
	+ mibox(0,1,0,1) * numep(+num(-1)+num(2)*ep)*den(s-4)*den(s+t-4)
	+ mibox(1,0,0,0) * numep(+num(2)*ep+num(-2)*ep^2)*den(-1)*den(s-4)*denep(2*ep+1)*den(s+t-4)
	;

Fill box(1,1,1,2) =
	+ mibox(1,1,1,1) * numep(+num(-1)+num(-2)*ep)*den(s+t-4)
	+ mibox(1,0,1,0) * numep(+num(2)+num(-8)*ep^2)*den(-1)*denep(ep+1)*den(s+t-4)*den(s-4)^2
	+ mibox(1,0,0,0) * numep(+num(-2)+num(s-6)*ep+num(-s+8)*ep^2)*den(-1)*denep(ep+1)*den(s+t-4)*den(s-4)^2
	;

Fill box(3,1,1,1) =
	+ mibox(1,1,1,1) * numep(+num(s^2+s*t-4*s+2*t)+num(3*s^2+3*s*t-12*s+4*t)*ep+num(2*s^2+2*s*t-8*s)*ep^2)*den(s)*den(s+t-4)*den(s-4)^2
	+ mibox(1,1,0,1) * numep(+num(s^3+s^2*t-8*s^2-8*s*t+4*s+4*t)*ep+num(s^3+s^2*t-8*s^2-8*s*t+8*s+8*t)*ep^2)*den(2)*den(s)*den(s+t-4)*den(s-4)^2
	+ mibox(0,1,0,1) * numep(+num(s^3+s^2*t-10*s^2-8*s*t+24*s+4*t)+num(-s^3-s^2*t+12*s^2+8*s*t-32*s)*ep+num(-2*s^3-2*s^2*t+16*s^2+16*s*t-32*s-16*t)*ep^2)*den(2)*den(s)*den(s-4)^2*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(4)+num(-16)*ep^2)*den(-1)*den(s)*denep(ep+1)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4)+num(s^3-12*s^2+34*s+4)*ep+num(s^3-12*s^2+38*s-24)*ep^2+num(-s^3+12*s^2-32*s-16)*ep^3+num(-s^3+12*s^2-40*s+32)*ep^4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s+t-4)*den(s-4)^3
	;

Fill box(2,2,1,1) =
	+ mibox(1,1,1,1) * numep(+num(-2)+num(-6)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)
	+ mibox(1,1,0,1) * numep(+num(2*s+2*t)*ep+num(2*s+2*t)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(2)+num(-2)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-4)+num(16)*ep^2)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s+12*t-48)+num(s^3+s^2*t-6*s^2-14*s*t+44*s+84*t-144)*ep+num(2*s^3+2*s^2*t-26*s^2-26*s*t+136*s+96*t-256)*ep^2+num(-s^3-s^2*t+8*s^2+16*s*t-64*s-96*t+192)*ep^3+num(-2*s^3-2*s^2*t+24*s^2+24*s*t-128*s-96*t+256)*ep^4)*denep(2*ep+1)*denep(2*ep+3)*den(s+t-4)^2*den(s-4)^3
	;

Fill box(2,1,2,1) =
	+ mibox(1,1,1,1) * numep(+num(2*s^2+4*s*t-8*s-4*t)+num(6*s^2+10*s*t-24*s-8*t)*ep+num(4*s^2+4*s*t-16*s)*ep^2)*den(s)*den(s+t-4)*den(s-4)^2
	+ mibox(1,1,0,1) * numep(+num(-2*s^2-2*s*t-4*s-4*t)*ep+num(-8*s-8*t)*ep^2)*den(s)*den(s+t-4)*den(s-4)^2
	+ mibox(0,1,0,1) * numep(+num(-2*s^2-2*s*t+8*s-4*t)+num(4*s^2+4*s*t-16*s)*ep+num(16*t)*ep^2)*den(s)*den(s-4)^2*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(4*s-8)+num(-16*s+32)*ep^2)*den(-1)*den(s)*denep(ep+1)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4*s-8)+num(-6*s^2+32*s-8)*ep+num(-2*s^2-4*s+48)*ep^2+num(8*s^2-48*s+32)*ep^3+num(16*s-64)*ep^4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s+t-4)*den(s-4)^3
	;

Fill box(2,1,1,2) =
	+ mibox(1,1,1,1) * numep(+num(-2)+num(-6)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)
	+ mibox(1,1,0,1) * numep(+num(2*s+2*t)*ep+num(2*s+2*t)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(2)+num(-2)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-4)+num(16)*ep^2)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s+12*t-48)+num(s^3+s^2*t-6*s^2-14*s*t+44*s+84*t-144)*ep+num(2*s^3+2*s^2*t-26*s^2-26*s*t+136*s+96*t-256)*ep^2+num(-s^3-s^2*t+8*s^2+16*s*t-64*s-96*t+192)*ep^3+num(-2*s^3-2*s^2*t+24*s^2+24*s*t-128*s-96*t+256)*ep^4)*denep(2*ep+1)*denep(2*ep+3)*den(s+t-4)^2*den(s-4)^3
	;

Fill box(1,3,1,1) =
	+ mibox(1,1,1,1) * numep(+num(1)+num(3)*ep+num(2)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-6*s-2*t+24)+num(-2*s+8)*ep+num(24*s+8*t-96)*ep^2+num(8*s-32)*ep^3)*den(-1)*denep(ep+2)*den(s+t-4)^2*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-36*s-12*t+144)+num(-s^3-s^2*t+30*s^2+14*s*t-264*s-60*t+640)*ep+num(-2*s*t+28*s+24*t-112)*ep^2+num(s^3+s^2*t-26*s^2-12*s*t+224*s+48*t-544)*ep^3+num(-4*s^2+48*s-128)*ep^4)*den(2)*denep(ep+2)*denep(2*ep+3)*den(s+t-4)^2*den(s-4)^3
	;

Fill box(1,2,2,1) =
	+ mibox(1,1,1,1) * numep(+num(-2)+num(-6)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)
	+ mibox(1,1,0,1) * numep(+num(2*s+2*t)*ep+num(2*s+2*t)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(2)+num(-2)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-4)+num(16)*ep^2)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s+12*t-48)+num(s^3+s^2*t-6*s^2-14*s*t+44*s+84*t-144)*ep+num(2*s^3+2*s^2*t-26*s^2-26*s*t+136*s+96*t-256)*ep^2+num(-s^3-s^2*t+8*s^2+16*s*t-64*s-96*t+192)*ep^3+num(-2*s^3-2*s^2*t+24*s^2+24*s*t-128*s-96*t+256)*ep^4)*denep(2*ep+1)*denep(2*ep+3)*den(s+t-4)^2*den(s-4)^3
	;

Fill box(1,2,1,2) =
	+ mibox(1,1,1,1) * numep(+num(2*s-2*t-8)+num(6*s-4*t-24)*ep+num(4*s-16)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(1,1,0,1) * numep(+num(2*s+2*t)*ep)*den(s-4)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(2)+num(-4)*ep)*den(s-4)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-8)+num(-4)*ep+num(32)*ep^2+num(16)*ep^3)*den(-1)*denep(ep+1)*den(s-4)^2*den(s+t-4)^2
	+ mibox(1,0,0,0) * numep(+num(-8)+num(8*s-60)*ep+num(6*s-36)*ep^2+num(-10*s+72)*ep^3+num(-4*s+32)*ep^4)*denep(ep+1)*denep(2*ep+1)*den(s-4)^2*den(s+t-4)^2
	;

Fill box(1,1,3,1) =
	+ mibox(1,1,1,1) * numep(+num(s^2+s*t-4*s+2*t)+num(3*s^2+3*s*t-12*s+4*t)*ep+num(2*s^2+2*s*t-8*s)*ep^2)*den(s)*den(s+t-4)*den(s-4)^2
	+ mibox(1,1,0,1) * numep(+num(s^3+s^2*t-8*s^2-8*s*t+4*s+4*t)*ep+num(s^3+s^2*t-8*s^2-8*s*t+8*s+8*t)*ep^2)*den(2)*den(s)*den(s+t-4)*den(s-4)^2
	+ mibox(0,1,0,1) * numep(+num(s^3+s^2*t-10*s^2-8*s*t+24*s+4*t)+num(-s^3-s^2*t+12*s^2+8*s*t-32*s)*ep+num(-2*s^3-2*s^2*t+16*s^2+16*s*t-32*s-16*t)*ep^2)*den(2)*den(s)*den(s-4)^2*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(4)+num(-16)*ep^2)*den(-1)*den(s)*denep(ep+1)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(4)+num(s^3-12*s^2+34*s+4)*ep+num(s^3-12*s^2+38*s-24)*ep^2+num(-s^3+12*s^2-32*s-16)*ep^3+num(-s^3+12*s^2-40*s+32)*ep^4)*den(s)*denep(ep+1)*denep(2*ep+1)*den(s+t-4)*den(s-4)^3
	;

Fill box(1,1,2,2) =
	+ mibox(1,1,1,1) * numep(+num(-2)+num(-6)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)
	+ mibox(1,1,0,1) * numep(+num(2*s+2*t)*ep+num(2*s+2*t)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(0,1,0,1) * numep(+num(2)+num(-2)*ep+num(-4)*ep^2)*den(s-4)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-4)+num(16)*ep^2)*den(s+t-4)*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(12*s+12*t-48)+num(s^3+s^2*t-6*s^2-14*s*t+44*s+84*t-144)*ep+num(2*s^3+2*s^2*t-26*s^2-26*s*t+136*s+96*t-256)*ep^2+num(-s^3-s^2*t+8*s^2+16*s*t-64*s-96*t+192)*ep^3+num(-2*s^3-2*s^2*t+24*s^2+24*s*t-128*s-96*t+256)*ep^4)*denep(2*ep+1)*denep(2*ep+3)*den(s+t-4)^2*den(s-4)^3
	;

Fill box(1,1,1,3) =
	+ mibox(1,1,1,1) * numep(+num(1)+num(3)*ep+num(2)*ep^2)*den(s+t-4)^2
	+ mibox(1,0,1,0) * numep(+num(-6*s-2*t+24)+num(-2*s+8)*ep+num(24*s+8*t-96)*ep^2+num(8*s-32)*ep^3)*den(-1)*denep(ep+2)*den(s+t-4)^2*den(s-4)^3
	+ mibox(1,0,0,0) * numep(+num(-36*s-12*t+144)+num(-s^3-s^2*t+30*s^2+14*s*t-264*s-60*t+640)*ep+num(-2*s*t+28*s+24*t-112)*ep^2+num(s^3+s^2*t-26*s^2-12*s*t+224*s+48*t-544)*ep^3+num(-4*s^2+48*s-128)*ep^4)*den(2)*denep(ep+2)*denep(2*ep+3)*den(s+t-4)^2*den(s-4)^3
	;

