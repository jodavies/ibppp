Fill box(0,1,0,0) =
	0
	;

Fill box(0,1,0,-1) =
	0
	;

Fill box(0,1,-1,0) =
	0
	;

Fill box(-1,1,0,0) =
	0
	;

Fill box(0,1,0,-2) =
	0
	;

Fill box(0,1,-1,-1) =
	0
	;

Fill box(0,1,-2,0) =
	0
	;

Fill box(-1,1,0,-1) =
	0
	;

Fill box(-1,1,-1,0) =
	0
	;

Fill box(-2,1,0,0) =
	0
	;

Fill box(0,2,0,0) =
	0
	;

Fill box(0,2,0,-1) =
	0
	;

Fill box(0,2,-1,0) =
	0
	;

Fill box(-1,2,0,0) =
	0
	;

Fill box(0,2,0,-2) =
	0
	;

Fill box(0,2,-1,-1) =
	0
	;

Fill box(0,2,-2,0) =
	0
	;

Fill box(-1,2,0,-1) =
	0
	;

Fill box(-1,2,-1,0) =
	0
	;

Fill box(-2,2,0,0) =
	0
	;

Fill box(0,3,0,0) =
	0
	;

Fill box(0,3,0,-1) =
	0
	;

Fill box(0,3,-1,0) =
	0
	;

Fill box(-1,3,0,0) =
	0
	;

Fill box(0,3,0,-2) =
	0
	;

Fill box(0,3,-1,-1) =
	0
	;

Fill box(0,3,-2,0) =
	0
	;

Fill box(-1,3,0,-1) =
	0
	;

Fill box(-1,3,-1,0) =
	0
	;

Fill box(-2,3,0,0) =
	0
	;

Fill box(0,0,0,1) =
	0
	;

Fill box(0,0,-1,1) =
	0
	;

Fill box(0,-1,0,1) =
	0
	;

Fill box(-1,0,0,1) =
	0
	;

Fill box(0,0,-2,1) =
	0
	;

Fill box(0,-1,-1,1) =
	0
	;

Fill box(0,-2,0,1) =
	0
	;

Fill box(-1,0,-1,1) =
	0
	;

Fill box(-1,-1,0,1) =
	0
	;

Fill box(-2,0,0,1) =
	0
	;

Fill box(0,0,0,2) =
	0
	;

Fill box(0,0,-1,2) =
	0
	;

Fill box(0,-1,0,2) =
	0
	;

Fill box(-1,0,0,2) =
	0
	;

Fill box(0,0,-2,2) =
	0
	;

Fill box(0,-1,-1,2) =
	0
	;

Fill box(0,-2,0,2) =
	0
	;

Fill box(-1,0,-1,2) =
	0
	;

Fill box(-1,-1,0,2) =
	0
	;

Fill box(-2,0,0,2) =
	0
	;

Fill box(0,0,0,3) =
	0
	;

Fill box(0,0,-1,3) =
	0
	;

Fill box(0,-1,0,3) =
	0
	;

Fill box(-1,0,0,3) =
	0
	;

Fill box(0,0,-2,3) =
	0
	;

Fill box(0,-1,-1,3) =
	0
	;

Fill box(0,-2,0,3) =
	0
	;

Fill box(-1,0,-1,3) =
	0
	;

Fill box(-1,-1,0,3) =
	0
	;

Fill box(-2,0,0,3) =
	0
	;

Fill box(1,0,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-2)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,0,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s-2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-6*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+8)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t-10)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,0,0) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,0,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,0,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,0,0) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,0,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,0,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,-1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,0,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,-1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,-2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-2)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5)
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3)
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,2,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+6)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(10)
	+ mibox(1,0,0,0) * ep^1 * num(-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(4*s+2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,3,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,3,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s-2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,3,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t+8)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t-10)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(6)
	+ mibox(1,0,0,0) * ep^1 * num(-7)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s-4)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s+1)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-6*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,1,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-8*s+16)*den(3)
	+ mibox(1,0,1,0) * ep^1 * num(s^2-8*s+16)*den(18)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s+14)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s+4)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-s*t-8*s+4*t+16)*den(6)
	+ mibox(1,0,1,0) * ep^1 * num(-s^2-2*s*t+8*s+8*t-16)*den(18)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s+t+10)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(s+2*t-4)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-8*s+16)*den(3)
	+ mibox(1,0,1,0) * ep^1 * num(s^2-8*s+16)*den(18)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s+14)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s+4)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-1)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	;

Fill box(1,0,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	;

Fill box(2,-1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	;

Fill box(1,-1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	;

Fill box(2,0,1,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,2,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+t+4)*den(2)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+t+4)*den(2)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+4)
	+ mibox(1,0,1,0) * ep^1 * num(s-4)*den(2)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+8*s-12)*den(2*s^3-16*s^2+32*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s+4)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s-4)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+12)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-8*s^2+16*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+8*s-12)*den(2*s^3-16*s^2+32*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^1 * num(s+4)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-6)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,3,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^1 * num(s+4)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^1 * num(-6)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-s+2)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(3*s-4)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s-2)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s+6)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,1,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,2,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s-2)*den(s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(4)*den(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,3,-2) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-s*t-4*s+2*t)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s^2+s*t+10*s-8)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s+2*t+8)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-4*s-2*t)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^1 * num(-s^2+s*t+2*s+8)*den(s^2-4*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*t)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^1 * num(2*s-2*t-8)*den(s^2-4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,3,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2-s*t-4*s+2*t)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s^2+s*t+10*s-8)*den(2*s^2-8*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s+2*t+8)*den(2*s^2-8*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s-2)*den(s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(4)*den(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s-1)*den(s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s+2)*den(2*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * 1*den(s)
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,2,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,2,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,3,1,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,2,0) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,3,0) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,3,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,3,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,3,1,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,2,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,3,-2) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,3,1,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,2,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,3,-1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,3,1,0) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,2,2,0) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,3,0) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,1,0) =
	+ mibox(1,0,1,0) * ep^-1 * 1*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,1,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-t+4)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(2*s+2*t-8)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+2*s*t-8*s+t^2-8*t+16)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-s^2+2*s*t+8*s+2*t^2-8*t-16)*den(2*s-8)
	+ mibox(1,0,1,0) * ep^1 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-2*s*t+8*s-t^2+8*t-16)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+17*s-2*t^2+16*t-36)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^2-8*s*t+32*s-4*t^2+32*t-64)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,1,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,1,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-2*t+4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(4*s+6*t-16)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+2*t-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(4*s^2+4*s*t-28*s-12*t+48)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,2,-1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-12*s*t+40*s-6*t^2+48*t-80)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+6*s*t-20*s+3*t^2-20*t+32)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-6*s^3-12*s^2*t+68*s^2-6*s*t^2+80*s*t-256*s+12*t^2-128*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,2,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,1,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(4*s-4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-4*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-4*s-8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,1,0) =
	+ mibox(1,0,1,0) * ep^0 * 1*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-3)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+14*s-34)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,2,0) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,3,0) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(2*s^2+4*s*t-8*s-4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-8*s^2-10*s*t+36*s+12*t-16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+8*s+4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s^2+4*s*t-12*s-16*t+16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,1,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s+3*t-4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-9*s-21*t+36)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-3*t+4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+14*s^2+14*s*t-50*s-10*t+40)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,2,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,3,-1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,2,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-8*s^3-18*s^2*t+66*s^2-10*s*t^2+88*s*t-144*s+12*t^2-64*t+32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(11*s^3+16*s^2*t-96*s^2+6*s*t^2-88*s*t+240*s-12*t^2+96*t-128)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^3-6*s^2*t+16*s^2-4*s*t^2+28*s*t-32*s+4*t^2-16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-6*s^3+s^2*t^2-2*s^2*t-2*s^2+4*s*t^2-44*s*t+48*s-16*t^2+80*t-32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^4-8*s^3*t+40*s^3-4*s^2*t^2+48*s^2*t-118*s^2+8*s*t^2-24*s*t+48*s+24*t^2-160*t+160)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,1,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+6*s*t-8*s+6*t^2-24*t+16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-24*s*t+40*s-21*t^2+96*t-80)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(21*s^2+78*s*t-168*s+57*t^2-312*t+336)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-6*s*t+8*s-6*t^2+24*t-16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+16*s^3-s^2*t^2+30*s^2*t-88*s^2+14*s*t^2-108*s*t+192*s-10*t^2+80*t-128)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(25*s^4+50*s^3*t-418*s^3+25*s^2*t^2-780*s^2*t+2526*s^2-362*s*t^2+3516*s*t-6544*s+814*t^2-4784*t+6112)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,2,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,3,-2) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,0,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,0,1) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,0,1) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,0,2) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,0,3) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,0,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,-2,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,-2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,-2,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,-1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,-1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,-1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-2,0,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,0,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,0,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,-2,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s^2+2*s*t-7*s+t^2-7*t+12)*den(3)
	+ mibox(0,1,0,1) * ep^1 * num(s^2+2*s*t-4*s+t^2-4*t)*den(18)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s^2+3*s*t-10*s+2*t^2-14*t+24)*den(6)
	+ mibox(0,1,0,1) * ep^1 * num(-s^2+4*s+t^2-4*t)*den(18)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-2,1,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s^2+2*s*t-7*s+t^2-7*t+12)*den(3)
	+ mibox(0,1,0,1) * ep^1 * num(s^2+2*s*t-4*s+t^2-4*t)*den(18)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,2,0,1) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,0,2) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,2,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,-1,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,2,0,1) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,0,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-1)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,2,-2,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,-2,2) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,2,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,-1,2) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-2,2,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-2,1,0,2) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)
	+ mibox(0,1,0,1) * ep^1 * num(-s-t+4)*den(2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,3,0,1) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,2,0,2) =
	+ mibox(0,1,0,1) * ep^0 * num(-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,0,3) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,3,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,2,-1,2) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,-1,3) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,3,0,1) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,2,0,2) =
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,0,3) =
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-3)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,3,-2,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,2,-2,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-2*t+6)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,-2,3) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,3,-1,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,2,-1,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-s-2*t+6)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,-1,3) =
	+ mibox(0,1,0,1) * ep^0 * num(s+2*t-6)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-2,3,0,1) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-2,2,0,2) =
	+ mibox(0,1,0,1) * ep^0 * 1
	+ mibox(0,1,0,1) * ep^1 * num(-2*s-2*t+6)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(-2,1,0,3) =
	+ mibox(0,1,0,1) * ep^0 * num(s+t-3)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(-3*s-3*t+10)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(1,1,-1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2+s*t-4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^4+2*s^3*t-8*s^3+s^2*t^2-6*s^2*t+16*s^2+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^3+s^2*t+12*s^2+5*s*t^2-16*s*t+t^3-4*t^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(3*s^3+3*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,0,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-1)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(1,2,0,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,0,2) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-s^2-s*t+4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s)*den(s+t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s+t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s+t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^3+2*s^2*t+8*s^2+4*s*t^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t-4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^3-3*s^2*t+4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,0,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t-2)*den(2*s+2*t-8)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,0,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,0,2) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,0,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,0,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t+2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,0,3) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,-1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*t)*den(2*s+2*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-s^2-s*t+4*t)*den(2*s^2+4*s*t-8*s+2*t^2-8*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,-1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,-1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^2-2*s*t+6*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-1,3) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2-4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-8*s^2*t-8*s^2-6*s*t^2+24*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-s^3-s^2*t-4*s^2+12*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+4*s^2-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,-2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,-2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,-2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3-8*s^2-2*s*t^2+4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-10*s^3+s^2*t^2-10*s^2*t+24*s^2-8*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+11*s^2-6*s*t-t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+4*s^2-2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,-2,3) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,1,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * 1
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(8*s^2+16*s*t-68*s+8*t^2-68*t+144)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+10*s)*den(6)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,1,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s)*den(3)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(9)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,2,1) =
	+ mibox(1,0,0,0) * ep^0 * 1*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,2,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(-s+1)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-10*s+t^2-10*t+30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+2*s*t-8*s+t^2-8*t+14)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s-t+6)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-8*s-2*t+8)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+4*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,2,1) =
	+ mibox(1,0,0,0) * ep^0 * num(2*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,1,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,3,1) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,2,2) =
	+ mibox(1,0,0,0) * ep^1 * 1*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,0,1,3) =
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+4)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-5)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s+t-3)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+11)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-1,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s-t+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(11*s+11*t-26)*den(12)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(-s+2)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(s-1)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s+3)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,0,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(3*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-8*s+t^2-8*t+18)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s+t-6)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-3*s^2-6*s*t+20*s-3*t^2+20*t-30)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^2+6*s*t-28*s+3*t^2-28*t+62)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,-2,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+2*s*t-5*s+t^2-5*t+5)
	+ mibox(1,0,0,0) * ep^1 * num(-5*s^2-10*s*t+31*s-5*t^2+31*t-41)*den(3)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,3,1) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-6*s-2*t+12)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-6*s-t+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s+t-3)
	+ mibox(1,0,0,0) * ep^1 * num(-2*s-t+5)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,-1,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+3*s*t-10*s)*den(4)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2-3*s*t+14*s)*den(4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,3,1) =
	+ mibox(1,0,0,0) * ep^0 * 1
	+ mibox(1,0,0,0) * ep^1 * num(s^2-6*s+2)*den(2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,2,2) =
	+ mibox(1,0,0,0) * ep^0 * num(-s^2+4*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+2*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,0,1,3) =
	+ mibox(1,0,0,0) * ep^0 * num(s^2-2*s)*den(2)
	+ mibox(1,0,0,0) * ep^1 * num(s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * 1*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-1)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * 1*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-t+4)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * 1
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(s+t-4)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(2*s+2*t-8)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+2*s*t-8*s+t^2-8*t+16)*den(s-4)
	+ mibox(1,0,1,0) * ep^0 * num(-s^2+2*s*t+8*s+2*t^2-8*t-16)*den(2*s-8)
	+ mibox(1,0,1,0) * ep^1 * num(s*t+t^2-4*t)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-2*s*t+8*s-t^2+8*t-16)*den(s-4)
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+17*s-2*t^2+16*t-36)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^2-8*s*t+32*s-4*t^2+32*t-64)*den(s-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,1,1) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,2,1) =
	+ mibox(1,0,1,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s-2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,1,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,2,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s+t-4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-3*s-2*t+12)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s-4)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s-t+4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(s^2+s*t-4*s-2*t)*den(2*s^2-16*s+32)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s-3*t+10)*den(2*s-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,1,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-s-2*t+4)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(4*s+6*t-16)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(-6*s-6*t+24)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(s+2*t-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+5*s-4)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(4*s^2+4*s*t-28*s-12*t+48)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,2,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-4*s*t+16*s-2*t^2+16*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(3*s+2*t-12)*den(s-4)
	+ mibox(1,0,1,0) * ep^1 * num(-1)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+4*s*t-16*s+2*t^2-16*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-2*s^2*t+12*s^2-s*t^2+18*s*t-48*s+6*t^2-40*t+64)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+2*s^2*t-10*s^2+s*t^2-10*s*t+32*s+8*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,1,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-12*s*t+40*s-6*t^2+48*t-80)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^1 * num(6*s^2+12*s*t-48*s+6*t^2-48*t+96)*den(s^2-8*s+16)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^0 * num(3*s^2+6*s*t-20*s+3*t^2-20*t+32)*den(s-4)
	+ mibox(1,0,0,0) * ep^1 * num(-6*s^3-12*s^2*t+68*s^2-6*s*t^2+80*s*t-256*s+12*t^2-128*t+320)*den(s^2-8*s+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,0,1,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,2,1) =
	+ mibox(1,0,1,0) * ep^0 * num(4*s-4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-4*s+4)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-4*s-8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,0,1,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,3,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s+2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-2)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3+12*s^2-40*s+16)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,2,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s-10)*den(6*s^2-48*s+96)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,0,1,3) =
	+ mibox(1,0,1,0) * ep^0 * 1*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-3)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-1)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^2+14*s-34)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-1,1,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,2,1) =
	+ mibox(1,0,1,0) * ep^0 * num(2*s^2+4*s*t-8*s-4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-8*s^2-10*s*t+36*s+12*t-16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-2*s^2-4*s*t+8*s+4*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s^2+4*s*t-12*s-16*t+16)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-1,1,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,3,1) =
	+ mibox(1,0,1,0) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(-3*s^2-2*s*t+10*s-6*t+8)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^2-s*t+4*s-2*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-s^4-s^3*t+14*s^3+12*s^2*t-56*s^2-32*s*t+72*s+32*t-32)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,2,2) =
	+ mibox(1,0,1,0) * ep^0 * num(-2*s-4*t+8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(8*s+12*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s+4*t-8)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-15*s^2-14*s*t+54*s+16*t-40)*den(3*s^3-36*s^2+144*s-192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-1,1,3) =
	+ mibox(1,0,1,0) * ep^0 * num(s+3*t-4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-9*s-21*t+36)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s-3*t+4)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+14*s^2+14*s*t-50*s-10*t+40)*den(4*s^3-48*s^2+192*s-256)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,-2,1,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,2,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(2*s^3+6*s^2*t-16*s^2+4*s*t^2-28*s*t+32*s-4*t^2+16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-8*s^3-18*s^2*t+66*s^2-10*s*t^2+88*s*t-144*s+12*t^2-64*t+32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^1 * num(11*s^3+16*s^2*t-96*s^2+6*s*t^2-88*s*t+240*s-12*t^2+96*t-128)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-2*s^3-6*s^2*t+16*s^2-4*s*t^2+28*s*t-32*s+4*t^2-16*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-6*s^3+s^2*t^2-2*s^2*t-2*s^2+4*s*t^2-44*s*t+48*s-16*t^2+80*t-32)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^1 * num(-4*s^4-8*s^3*t+40*s^3-4*s^2*t^2+48*s^2*t-118*s^2+8*s*t^2-24*s*t+48*s+24*t^2-160*t+160)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,-2,1,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,3,1) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^3+2*s^2*t-8*s^2+s*t^2-6*s*t+16*s+2*t^2-8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,1,0) * ep^0 * num(-7*s^3-10*s^2*t+54*s^2-4*s*t^2+24*s*t-96*s-12*t^2+64*t-32)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^1 * num(7*s^3+4*s^2*t-48*s^2+8*s*t+48*s+12*t^2-96*t+128)*den(2*s^4-24*s^3+96*s^2-128*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^3-2*s^2*t+8*s^2-s*t^2+6*s*t-16*s-2*t^2+8*t)*den(s^4-12*s^3+48*s^2-64*s)
	+ mibox(1,0,0,0) * ep^0 * num(-s^5-2*s^4*t+18*s^4-s^3*t^2+30*s^3*t-110*s^3+12*s^2*t^2-136*s^2*t+276*s^2-32*s*t^2+232*s*t-256*s+32*t^2-160*t+64)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^1 * num(3*s^5+6*s^4*t-58*s^4+3*s^3*t^2-94*s^3*t+402*s^3-36*s^2*t^2+472*s^2*t-1220*s^2+104*s*t^2-848*s*t+1472*s-48*t^2+320*t-320)*den(4*s^4-48*s^3+192*s^2-256*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,2,2) =
	+ mibox(1,0,1,0) * ep^-1 * num(-2*s^2-8*s*t+16*s-6*t^2+32*t-32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(9*s^2+28*s*t-72*s+18*t^2-112*t+144)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(-16*s^2-36*s*t+128*s-18*t^2+144*t-256)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(2*s^2+8*s*t-16*s+6*t^2-32*t+32)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(s^4+2*s^3*t-18*s^3+s^2*t^2-32*s^2*t+106*s^2-14*s*t^2+120*s*t-240*s+16*t^2-96*t+160)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(-11*s^4-22*s^3*t+212*s^3-11*s^2*t^2+372*s^2*t-1422*s^2+160*s*t^2-1776*s*t+4016*s-392*t^2+2560*t-4064)*den(6*s^3-72*s^2+288*s-384)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,-2,1,3) =
	+ mibox(1,0,1,0) * ep^-1 * num(s^2+6*s*t-8*s+6*t^2-24*t+16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^0 * num(-5*s^2-24*s*t+40*s-21*t^2+96*t-80)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,1,0) * ep^1 * num(21*s^2+78*s*t-168*s+57*t^2-312*t+336)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^-1 * num(-s^2-6*s*t+8*s-6*t^2+24*t-16)*den(s^3-12*s^2+48*s-64)
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+16*s^3-s^2*t^2+30*s^2*t-88*s^2+14*s*t^2-108*s*t+192*s-10*t^2+80*t-128)*den(2*s^3-24*s^2+96*s-128)
	+ mibox(1,0,0,0) * ep^1 * num(25*s^4+50*s^3*t-418*s^3+25*s^2*t^2-780*s^2*t+2526*s^2-362*s*t^2+3516*s*t-6544*s+814*t^2-4784*t+6112)*den(12*s^3-144*s^2+576*s-768)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,1,1) =
	+ mibox(1,1,0,1) * ep^0 * 1
	+ mibox(1,1,0,1) * ep^2 * warnep
	;

Fill box(-1,1,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2+s*t-4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(2*s)*den(s+t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^4+2*s^3*t-8*s^3+s^2*t^2-6*s^2*t+16*s^2+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(2*s^2*t+2*s*t^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^3+s^2*t+12*s^2+5*s*t^2-16*s*t+t^3-4*t^2)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(s^2*t+s*t^2-4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(3*s^3+3*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,2,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-1)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s+t-4)
	+ mibox(0,1,0,1) * ep^2 * warnep
	;

Fill box(0,1,1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s+t-4)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-s+t)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-s^2-s*t+4*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s)*den(s+t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s+t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s)*den(s+t)
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(s+t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(s)*den(s+t)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s)*den(s+t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s+t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,2,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^3+2*s^2*t+8*s^2+4*s*t^2-16*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^4-2*s^3*t+8*s^3-s^2*t^2+8*s^2*t-16*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(2*s^3+2*s^2*t-8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t-4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^3-3*s^2*t+4*s^2+8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3+2*s^2*t-8*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+8*s^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^1 * num(3*s^2-2*s*t-t^2)*den(s^2+2*s*t+t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s^2-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,3,1,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,2,1) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,2,1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t+2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,3,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s+t-2)*den(2*s+2*t-8)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-1)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,2,2) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s+t-4)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * 1*den(2*s+2*t-8)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(0,1,1,3) =
	+ mibox(1,1,0,1) * ep^1 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s-t+10)*den(12*s^2+24*s*t-96*s+12*t^2-96*t+192)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,3,1,1) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,2,1) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,2,1,2) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^2-2*s*t+6*s+2*t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,3,1) =
	+ mibox(1,1,0,1) * ep^1 * num(s^2+s*t-2*t)*den(2*s+2*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s-2)*den(2*s+2*t-8)
	+ mibox(0,1,0,1) * ep^1 * num(-s^2-s*t+4*t)*den(2*s^2+4*s*t-8*s+2*t^2-8*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s)*den(2*s+2*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,2,2) =
	+ mibox(1,1,0,1) * ep^1 * num(2*s-2*t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(2*s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(s^2+s*t-3*s-t)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-1,1,1,3) =
	+ mibox(1,1,0,1) * ep^1 * num(-s)*den(s^2+2*s*t-4*s+t^2-4*t)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^1 * num(s-t)*den(s^3+3*s^2*t-8*s^2+3*s*t^2-16*s*t+16*s+t^3-8*t^2+16*t)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-s^2-s*t+2*s)*den(4*s^2+8*s*t-16*s+4*t^2-16*t)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,3,1,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,2,2,1) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,2,1,2) =
	+ mibox(1,1,0,1) * ep^0 * num(2*s^3-8*s^2-2*s*t^2+4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-10*s^3+s^2*t^2-10*s^2*t+24*s^2-8*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-2*s^3-2*s^2*t+11*s^2-6*s*t-t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+4*s^2-2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(2*s^3+2*s^2*t-8*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,3,1) =
	+ mibox(1,1,0,1) * ep^0 * num(s^2-4*s*t+t^2)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-8*s^2*t-8*s^2-6*s*t^2+24*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(-s^3-s^2*t-4*s^2+12*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^3-s^2*t+6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+4*s^2-6*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,2,2) =
	+ mibox(1,1,0,1) * ep^0 * num(-2*s^2+4*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-s^3-s^2*t+8*s^2-8*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-s^3-s^2*t+5*s^2-6*s*t+t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(4*s^3+4*s^2*t-18*s^2+12*s*t-2*t^2)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(s^3+s^2*t+2*s^2-4*s*t)*den(2*s^2+4*s*t+2*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(-3*s^2+2*s*t)*den(s^2+2*s*t+t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(-2,1,1,3) =
	+ mibox(1,1,0,1) * ep^0 * num(s^3+s^2*t-4*s^2+2*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^1 * num(-3*s^3-3*s^2*t+12*s^2-4*s*t)*den(s^3+3*s^2*t-4*s^2+3*s*t^2-8*s*t+t^3-4*t^2)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-3*s^2+4*s*t+t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^1 * num(9*s^2-10*s*t-3*t^2)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-s^4-2*s^3*t+2*s^3-s^2*t^2+4*s^2*t+8*s^2+2*s*t^2-4*s*t)*den(4*s^3+12*s^2*t-16*s^2+12*s*t^2-32*s*t+4*t^3-16*t^2)
	+ mibox(1,0,0,0) * ep^1 * num(s^4+2*s^3*t-2*s^3+s^2*t^2-5*s^2*t-8*s^2-3*s*t^2+2*s*t)*den(2*s^3+6*s^2*t-8*s^2+6*s*t^2-16*s*t+2*t^3-8*t^2)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,1,1) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s-4)
	+ mibox(1,1,1,1) * ep^1 * num(2)*den(s-4)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(-s-t)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,1,1) =
	+ mibox(1,1,1,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,2,1) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s-4)
	+ mibox(1,1,1,1) * ep^1 * num(2)*den(s-4)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(-s-t)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^1 * num(2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^1 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,1,2) =
	+ mibox(1,1,1,1) * ep^0 * num(-1)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^1 * num(-2)*den(s+t-4)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^1 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(2)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(1,0,0,0) * ep^1 * num(-1)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(3,1,1,1) =
	+ mibox(1,1,1,1) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^1 * num(3*s^2+3*s*t-12*s+4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(s^3+s^2*t-8*s^2-8*s*t+4*s+4*t)*den(2*s^4+2*s^3*t-24*s^3-16*s^2*t+96*s^2+32*s*t-128*s)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-10*s^2-8*s*t+24*s+4*t)*den(2*s^5+4*s^4*t-32*s^4+2*s^3*t^2-48*s^3*t+192*s^3-16*s^2*t^2+192*s^2*t-512*s^2+32*s*t^2-256*s*t+512*s)
	+ mibox(0,1,0,1) * ep^1 * num(-s+8)*den(2*s^3+2*s^2*t-24*s^2-16*s*t+96*s+32*t-128)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^1 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-8*s+2)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,2,1,1) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,2,1) =
	+ mibox(1,1,1,1) * ep^0 * num(2*s^2+4*s*t-8*s-4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^1 * num(6*s^2+10*s*t-24*s-8*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(-2*s^2-2*s*t-4*s-4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(-2*s^2-2*s*t+8*s-4*t)*den(s^5+2*s^4*t-16*s^4+s^3*t^2-24*s^3*t+96*s^3-8*s^2*t^2+96*s^2*t-256*s^2+16*s*t^2-128*s*t+256*s)
	+ mibox(0,1,0,1) * ep^1 * num(4)*den(s^3+s^2*t-12*s^2-8*s*t+48*s+16*t-64)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4*s+8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^1 * num(4*s-8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4*s-8)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^1 * num(-6*s-4)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(2,1,1,2) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,3,1,1) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(3*s+t-12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(2*s^4+2*s^3*t-32*s^3-24*s^2*t+192*s^2+96*s*t-512*s-128*t+512)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-3*s-t+12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+30*s^2+14*s*t-222*s-46*t+472)*den(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1920*s^3-144*s^2*t^2+2304*s^2*t-7680*s^2+576*s*t^2-6144*s*t+15360*s-768*t^2+6144*t-12288)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,2,1) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,2,1,2) =
	+ mibox(1,1,1,1) * ep^0 * num(2*s-2*t-8)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,1,1) * ep^1 * num(6*s-4*t-24)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-4)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(8)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^1 * num(-4)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-8)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(8*s-36)*den(s^4+2*s^3*t-16*s^3+s^2*t^2-24*s^2*t+96*s^2-8*s*t^2+96*s*t-256*s+16*t^2-128*t+256)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,3,1) =
	+ mibox(1,1,1,1) * ep^0 * num(s^2+s*t-4*s+2*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^1 * num(3*s^2+3*s*t-12*s+4*t)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(s^3+s^2*t-8*s^2-8*s*t+4*s+4*t)*den(2*s^4+2*s^3*t-24*s^3-16*s^2*t+96*s^2+32*s*t-128*s)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(s^3+s^2*t-10*s^2-8*s*t+24*s+4*t)*den(2*s^5+4*s^4*t-32*s^4+2*s^3*t^2-48*s^3*t+192*s^3-16*s^2*t^2+192*s^2*t-512*s^2+32*s*t^2-256*s*t+512*s)
	+ mibox(0,1,0,1) * ep^1 * num(-s+8)*den(2*s^3+2*s^2*t-24*s^2-16*s*t+96*s+32*t-128)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^1 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^5+s^4*t-16*s^4-12*s^3*t+96*s^3+48*s^2*t-256*s^2-64*s*t+256*s)
	+ mibox(1,0,0,0) * ep^1 * num(s^2-8*s+2)*den(s^4+s^3*t-12*s^3-8*s^2*t+48*s^2+16*s*t-64*s)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,2,2) =
	+ mibox(1,1,1,1) * ep^0 * num(-2)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(-6)*den(s^2+s*t-8*s-4*t+16)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,1,0,1) * ep^1 * num(2*s+2*t)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(1,1,0,1) * ep^2 * warnep
	+ mibox(0,1,0,1) * ep^0 * num(2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^1 * num(-2)*den(s^3+2*s^2*t-12*s^2+s*t^2-16*s*t+48*s-4*t^2+32*t-64)
	+ mibox(0,1,0,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(-4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(4)*den(s^4+s^3*t-16*s^3-12*s^2*t+96*s^2+48*s*t-256*s-64*t+256)
	+ mibox(1,0,0,0) * ep^1 * num(s^3+s^2*t-6*s^2-14*s*t+12*s+52*t-16)*den(3*s^5+6*s^4*t-60*s^4+3*s^3*t^2-96*s^3*t+480*s^3-36*s^2*t^2+576*s^2*t-1920*s^2+144*s*t^2-1536*s*t+3840*s-192*t^2+1536*t-3072)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

Fill box(1,1,1,3) =
	+ mibox(1,1,1,1) * ep^0 * 1*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^1 * num(3)*den(s^2+2*s*t-8*s+t^2-8*t+16)
	+ mibox(1,1,1,1) * ep^2 * warnep
	+ mibox(1,0,1,0) * ep^0 * num(3*s+t-12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,1,0) * ep^1 * num(-1)*den(2*s^4+2*s^3*t-32*s^3-24*s^2*t+192*s^2+96*s*t-512*s-128*t+512)
	+ mibox(1,0,1,0) * ep^2 * warnep
	+ mibox(1,0,0,0) * ep^0 * num(-3*s-t+12)*den(s^5+2*s^4*t-20*s^4+s^3*t^2-32*s^3*t+160*s^3-12*s^2*t^2+192*s^2*t-640*s^2+48*s*t^2-512*s*t+1280*s-64*t^2+512*t-1024)
	+ mibox(1,0,0,0) * ep^1 * num(-s^3-s^2*t+30*s^2+14*s*t-222*s-46*t+472)*den(12*s^5+24*s^4*t-240*s^4+12*s^3*t^2-384*s^3*t+1920*s^3-144*s^2*t^2+2304*s^2*t-7680*s^2+576*s*t^2-6144*s*t+15360*s-768*t^2+6144*t-12288)
	+ mibox(1,0,0,0) * ep^2 * warnep
	;

