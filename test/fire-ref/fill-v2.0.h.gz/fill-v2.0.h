Fill v2(-3,2,2,1,1,1,1) =
	+ miv2(0,0,0,1,1,1,1) * numep(+num(6)+num(-28)*ep+num(10)*ep^2+num(88)*ep^3+num(-76)*ep^4+num(-24)*ep^5)*den(-1)/ep*denep(ep+1)*denep(2*ep+1)
	+ miv2(0,0,1,1,0,0,1) * numep(+num(-2)+num(-9)*ep+num(62)*ep^2+num(-82)*ep^3+num(198)*ep^4+num(-137)*ep^5+num(-834)*ep^6+num(828)*ep^7+num(216)*ep^8)/ep^3*denep(2*ep+1)*denep(ep+1)^2
	+ miv2(0,1,1,1,1,1,1) * numep(+num(-1)+num(-7)*ep+num(-2)*ep^2)/1
	;

Fill v2(-2,2,2,1,1,1,1) =
	+ miv2(0,0,0,1,1,1,1) * numep(+num(-24)+num(72)*ep+num(84)*ep^2+num(-228)*ep^3+num(-72)*ep^4)*denep(ep+1)*denep(2*ep+1)
	+ miv2(0,0,1,1,0,0,1) * numep(+num(24)+num(36)*ep+num(-660)*ep^2+num(708)*ep^3+num(1524)*ep^4+num(-1728)*ep^5+num(-432)*ep^6)/ep*denep(2*ep+1)*denep(ep+1)^2
	+ miv2(0,1,1,1,1,1,1) * numep(+num(4)+num(14)*ep+num(4)*ep^2)/1
	;

Fill v2(-3,1,1,1,1,1,1) =
	+ miv2(0,0,0,1,1,1,1) * numep(+num(3)+num(-3)*ep+num(-6)*ep^2)*den(2)/ep*denep(4*ep-1)
	+ miv2(0,0,1,1,0,0,1) * numep(+num(2)+num(-19)*ep+num(90)*ep^2+num(-207)*ep^3+num(216)*ep^4+num(-76)*ep^5)*den(-2)/ep^3*denep(4*ep-1)*denep(2*ep-1)
	+ miv2(0,1,1,1,1,1,1) * numep(+num(-1)+num(1)*ep)*den(-2)*denep(4*ep-1)
	;

Fill v2(-1,2,2,1,1,1,1) =
	+ miv2(0,0,0,1,1,1,1) * numep(+num(54)+num(-162)*ep+num(-186)*ep^2+num(498)*ep^3+num(180)*ep^4)*denep(ep+1)*denep(2*ep+1)
	+ miv2(0,0,1,1,0,0,1) * numep(+num(336)+num(-1656)*ep+num(1200)*ep^2+num(3480)*ep^3+num(-3456)*ep^4+num(-864)*ep^5)*den(-1)*denep(2*ep+1)*denep(ep+1)^2
	+ miv2(0,1,1,1,1,1,1) * numep(+num(-6)+num(-26)*ep+num(-8)*ep^2)/1
	;

Fill v2(-2,1,1,1,1,1,1) =
	+ miv2(0,0,0,1,1,1,1) * numep(+num(-1)+num(1)*ep+num(2)*ep^2)/ep*denep(4*ep-1)
	+ miv2(0,0,1,1,0,0,1) * numep(+num(-2)+num(17)*ep+num(-69)*ep^2+num(112)*ep^3+num(-60)*ep^4)*den(2)/ep^3*denep(4*ep-1)
	+ miv2(0,1,1,1,1,1,1) * numep(+num(1)+num(-2)*ep)*den(-2)*denep(4*ep-1)
	;

Fill v2(-1,1,1,1,1,1,1) =
	+ miv2(0,0,1,1,0,0,1) * numep(+num(2)+num(-13)*ep+num(27)*ep^2+num(-18)*ep^3)*den(-2)/ep^3
	+ miv2(0,1,1,1,1,1,1) * numep(+num(-1))*den(2)
	;

Fill v2(0,1,1,1,1,1,1) =
	+ miv2(0,1,1,1,1,1,1) * 1/1
	;

Fill v2(0,0,1,1,0,0,1) =
	+ miv2(0,0,1,1,0,0,1) * 1/1
	;

Fill v2(0,0,0,1,1,1,1) =
	+ miv2(0,0,0,1,1,1,1) * 1/1
	;

